/** @preserve  object.js
 *
 *  Views and models for the object page,
 *
 *  Version 1.0
 *
 * The MIT License (MIT)
 * 
 * Copyright (c) 2013 BiZZdesign B.V.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

var RelationsModel = Backbone.Model.extend({
});

var ViewsModel = Backbone.Model.extend({
});

var ObjectInfoModel = Backbone.Model.extend({
});

var ObjectInfoView = Backbone.View.extend({

    template: Handlebars.templates.objectInfo,

    render: function() {
        // prepare the data for the template
        var modelData = this.model.toJSON();
        var templateData = {};
        templateData.name = modelData.name;
        templateData.categories = [];
        for (var i in modelData.categories) {
            var category = modelData.categories[i];
            // Create a unique id for each category that can be assigned to the HTML element where we will
            // append the content of the category.
            var categoryId = "category" + i;
            var categoryObject = {};
            categoryObject.id = categoryId;
            categoryObject.type = category.type;
            if(category.title.localeCompare("__is_translate_properties_title__") == 0)
            {
                var translatedTitle = i18n.t('properties_message');
                categoryObject.title = translatedTitle.charAt(0).toUpperCase() + translatedTitle.substr(1);
            } else
            {
                categoryObject.title = category.title.charAt(0).toUpperCase() + category.title.substr(1);
            }            
            categoryObject.content = this.createContent(category);
            templateData.categories.push(categoryObject);
        }

        // Render the template with the template data
        this.$el.html(this.template(templateData));

        // Render the content of each category
        for (var i in templateData.categories) {
            var category = templateData.categories[i];
            if (category.type == "documentation") {
                this.$("#" + category.id).append(category.content);
            }
            if (category.type == "table") {
                this.renderTable(category);
            }
        }

        return this;
    },

    createContent: function(category) {
        if (category.type == "documentation") {
            return this.createValue(category.content).rtfValue;
        }
        if (category.type == "table") {
            var content = { groups: [] };
            for (var modelGroup in category.content) {
                var group = { name: modelGroup, properties: [] };
                content.groups.push(group);
                var groupAttributes = category.content[modelGroup];
                for (var propertyName in groupAttributes) {
                    var item = {};
                    item.name = propertyName;
                    item.value = this.createValue(groupAttributes[propertyName]);
                    group.properties.push(item);
                }
            }
            return content;
        }
    },

    createValue: function(modelValue) {
        var value = {};
        if (_.isObject(modelValue)) {
            if (modelValue.type == "collection") {
                value.isCollection = true;
                value.collection = [];
                for (var i = 0; i < modelValue.value.length; i++) {
                    var item = modelValue.value[i];
                    var property = {};
                    property.value = this.createValue(item);
                    value.collection.push(property);
                }
            }
            else if (modelValue.type == "structure" || modelValue.type == "pair") {
                value.isStruct = true;
                value.struct = [];
                for (var attrName in modelValue.value) {
                    var item = {};
                    item.name = attrName;
                    item.value = this.createValue(modelValue.value[attrName]);
                    value.struct.push(item);
                }
            }
            else if (modelValue.type == "link") {
                value.isLink = true;
                value.title = modelValue.value.title;
                value.location = modelValue.value.location;
            }
            else if (modelValue.type == "object") {
                value.isObject = true;
                value.objectId = modelValue.value.id;
                value.objectUrl = ObjectUtils.createUrl(modelValue.value.id);
                value.objectIconUrl = InsiteUtils.createUrl(modelValue.value.typeIconPath);
                value.objectName = modelValue.value.name;
            }
            else if (modelValue.type == "time") {
                value.isTime = true;
                value.number = modelValue.value.number;
                value.unit = modelValue.value.unit;
            }
            else if (modelValue.type == "rtf") {
                value.isRtf = true;
                value.rtfValue = modelValue.value.replace(/_INSITE_ROOT_FOLDER_/g, InsiteUtils.getUrlToInsiteRoot());
            }
        }
        else if (_.isBoolean(modelValue)) {
            value.isBoolean = true;
            value.booleanValue = modelValue;
        }
        else {
            value.isString = true;
            value.stringValue = modelValue;
        }
        return value;
    },

    renderTable: function (category) {
        this.$("#" + category.id).append(Handlebars.templates.propertyTable(category.content));
    }
});

var RelationsView = Backbone.View.extend({

	template: Handlebars.templates.objectRelations,

	render: function() {
		this.$el.html(this.template(this.model.toJSON()));
		return this;
	}

});


var ViewsListView = Backbone.View.extend({

	template: Handlebars.templates.relatedViews,

	render: function() {
		var modelData = this.model.toJSON();
		for (var i in modelData.views) {
			var viewData = modelData.views[i];
			viewData.thumbnailUrl = InsiteUtils.createUrl("png/view_" + viewData.id + ".png");
			viewData.viewUrl = InsiteUtils.createUrl("views/view_" + viewData.id + ".html");
		}
		this.$el.html(this.template(modelData));
		return this;
	}
});

var InsiteObjectLayout = Backbone.Marionette.Layout.extend({
	template: Handlebars.compile($("#layout-template").html()),

	regions: {
		info: "#info",
		views: "#views",
		relations: "#relations"
	}
});

function ModelFactory(language) {
	this.language = language;
};

ModelFactory.prototype = {

	getIconUrl: function(objectId) {
		var selectedObjectData = objectData[objectId];
		if (selectedObjectData) {
			return InsiteUtils.createUrl(selectedObjectData.typeIconPath);
		}
		return null;
	},

	createInfoModel: function(objectId) {
		var languageData = InsiteUtils.getLanguageData(objectId);
		var model = new ObjectInfoModel({name:languageData.name, categories:languageData.categories});
		return model;
	},

	createViewsModel: function(objectId) {
		var languageData = InsiteUtils.getLanguageData(objectId);
		var name = languageData.name;
		var viewIds = objectsOnViews[objectId];
		var views = [];
		for (var i = 0; i < viewIds.length; i++) {
			var viewId = viewIds[i];
			var view = insiteViews[viewId];
			views.push(view);
		}
		var model = new ViewsModel({name:name, views:views});
		return model;
	},

	createRelationsModel: function(objectId) {
		var relations = {};
		var relationsData = objectRelations[objectId];
		if (relationsData) {
			for (var i = 0; i < relationsData.length; i++) {
				var via = relationsData[i].via;
				relations[via] = [];
    			for (var j = 0; j < relationsData[i].to.length; j++) {
				    var toId = relationsData[i].to[j];
				    var toData = InsiteUtils.getLanguageData(toId);
				    var toIconUrl = this.getIconUrl(toId);
				    var toObjectUrl = ObjectUtils.createUrl(toId);
				    var to = {id:toId, name: toData.name, iconUrl:toIconUrl, objectUrl: toObjectUrl};
				    relations[via].push(to);
				}
			}
		}

		var model = new RelationsModel({relations:relations});
		return model;
	}

};

InSite.addInitializer(function(insiteState) {

	var objectId = insiteState.get("objectId");
    var language = availableLanguages[0];
    var modelFactory = new ModelFactory(language.id);

	// Only show object details if we have an objectId
    if (objectId) {
	    // Add the layout to the main region, where all views will be added 
	    // Reuse the header model for displaying the name.
	    var layout = new InsiteObjectLayout();
	    InSite.objectDetails.show(layout);

        if (InsiteUtils.hasInfo(objectId)) {
	        var infoModel = modelFactory.createInfoModel(objectId);
	        var infoView = new ObjectInfoView({model:infoModel});
	        layout.info.show(infoView);
        }

        if (InsiteUtils.hasRelations(objectId)) {
	        var relationsModel = modelFactory.createRelationsModel(objectId);
	        var relationsView = new RelationsView({model: relationsModel});
	        layout.relations.show(relationsView);
        }

        if (InsiteUtils.hasViews(objectId)) {
	        var viewsModel = modelFactory.createViewsModel(objectId);
	        var viewsListView = new ViewsListView({model:viewsModel});
	        layout.views.show(viewsListView);
        }
	}
});

function ObjectUtils() {}

ObjectUtils.createUrl = function(objectId) {
	var view = insiteViews[objectId];
	if (view) {
    	return InsiteUtils.createUrl("views/view_" + objectId + ".html");
    }
    else {
        var dataFile = objectDataMapping[objectId];
        if (dataFile) {
            return InsiteUtils.createUrl("object_" + dataFile + ".html?object=" + objectId);
        }
    }
};
