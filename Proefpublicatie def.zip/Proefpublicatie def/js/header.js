/**
 * @preserve  header.js
 * Version 1.0
 *
 * The MIT License (MIT)
 * 
 * Copyright (c) 2013 BiZZdesign B.V.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
 
var HeaderModel = Backbone.Model.extend({
});

var HeaderView = Backbone.View.extend({

	tagName: "ul",

	className: "nav nav-pills",

	template: Handlebars.templates.header,

	events: {
		"click #backButton" : "backButtonSelected",
		"click #forwardButton" : "forwardButtonSelected"
	},

	render: function() {
		this.$el.html(this.template(this.model.toJSON()));
		this.delegateEvents();
		return this;
	},

	backButtonSelected: function(e) {
		window.history.back();
	  	e.preventDefault();
	},

	forwardButtonSelected: function(e) {
		window.history.forward();
	  	e.preventDefault();
	}
});

InSite.addInitializer(function(insiteState) {
// The code below could be used when adding the navigation sidebar
    // Attach the navigation view to the already rendered navigation buttons.
    //    var objectId = insiteState.get("objectId");
    //    var navigationModel;
    //    if (objectId) {
    //        var languageData = InsiteUtils.getLanguageData(objectId);
    //        var name = languageData.name;
    //        var hasInfo = InsiteUtils.hasInfo(objectId);
    //        var hasViews = InsiteUtils.hasViews(objectId);
    //        var hasRelations = InsiteUtils.hasRelations(objectId);
    //        navigationModel = new NavigationModel({ name: name, hasInfo: hasInfo, hasViews: hasViews, hasRelations: hasRelations });
    //    }
    //    else {
    //        navigationModel = new NavigationModel();
    //    }

    var headerModel = new HeaderModel({ insiteRootUrl: InsiteUtils.getUrlToInsiteRoot() });
    var headerView = new HeaderView({ model: headerModel });
    InSite.header.show(headerView);
});
