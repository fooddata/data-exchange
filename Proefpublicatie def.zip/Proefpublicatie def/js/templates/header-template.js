(function() {
  var template = Handlebars.template, templates = Handlebars.templates = Handlebars.templates || {};
templates['header'] = template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<li onmouseover=\"brandMouseOver('back_button')\" onmouseout=\"brandMouseOut()\">\r\n  <a href=\"#\" id=\"backButton\">\r\n    <i class=\"fa fa-chevron-left fa-lg fa-fw\"></i>\r\n  </a>\r\n</li>\r\n<li onmouseover=\"brandMouseOver('forward_button')\" onmouseout=\"brandMouseOut()\">\r\n  <a href=\"#\" id=\"forwardButton\">\r\n    <i class=\"fa fa-chevron-right fa-lg fa-fw\"></i>\r\n  </a>\r\n</li>\r\n<li onmouseover=\"brandMouseOver('home_button')\" onmouseout=\"brandMouseOut()\">\r\n  <a href=\"";
  if (helper = helpers.insiteRootUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.insiteRootUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "index.html\">\r\n    <i class=\"fa fa-home fa-lg fa-fw\"></i>\r\n  </a>\r\n</li>\r\n<li onmouseover=\"brandMouseOver('all_views_button')\" onmouseout=\"brandMouseOut()\">\r\n  <a href=\"";
  if (helper = helpers.insiteRootUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.insiteRootUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "views.html\">\r\n    <i class=\"fa fa-th fa-lg fa-fw\"></i>\r\n  </a>\r\n</li>\r\n<li onmouseover=\"brandMouseOver('help_button')\" onmouseout=\"brandMouseOut()\">\r\n  <a href=\"";
  if (helper = helpers.insiteRootUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.insiteRootUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "help.html\">\r\n    <i class=\"fa fa-question fa-lg fa-fw\"></i>\r\n  </a>\r\n</li>\r\n<li>\r\n  <span id=\"navbar-location\" class=\"navbar-brand\"></span>\r\n</li>\r\n";
  return buffer;
  });
})();