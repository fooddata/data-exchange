/**
 * @preserve insite-translations.js
 * Version 1.0 
 * 
 * The MIT License (MIT)
 * 
 * Copyright (c) 2013 BiZZdesign B.V.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

var resources = {
	"en" : {
		translation : {
			"back_button" : "Back",
			"forward_button" : "Forward",
			"home_button" : "Home",
			"all_views_button" : "Diagrams",
			"help_button": "Help",
			"properties_message" : "Properties",
			"property_name_message" : "Property",
			"property_value_message" : "Value",
			"on_screen_guidance_title" : "On-screen guidance",
			"osg_type" : "Type",
			"feature_under_development" : "This feature is under development",
			"osg_feature_under_development_details": "Here you will see information to help you understand what the object means, what the object type means and which concepts are relevant in relation to this object.",
			"view" : "Diagram",
			"viewpoint_legend_no_info" : "No viewpoint legend information available for this diagram",
			"object_information" : "Details",
			"object_views" : "Appears on",
			"object_relations" : "Relations",
			"relation_via_message" : "Role",
			"relation_to_message" : "To",
			"filter_inputfield_text": "Search diagrams",
			"filter_clear_text": "Click here to clear the search text",
			"filter_result": "Result",
			"filter_1_diagram" : "diagram",
			"filter_x_diagrams" : "diagrams",
			"index-page-section-up": "Return to the top of the page",
			"error_title" : "Error",
			"error_notfound": "Object with id '__id__' is not found.",

			"help_general": "General",
			"help_general_content" : "<p>Welcome to the help page of the InSite Lite report. On this page you will find information regarding the structure of the report and how to navigate through the pages of the report. </p>",

			"help_components" : "Components",
			"help_components_contents" : "<p>The InSite Lite report consists of multiple components; a start page, an overview page, one or more diagram pages, one or more object pages, and this help page.</p>",

			"help_startpage" : "Start page",
			"help_startpage_contents" : "<p>The start page (<i class=\"fa fa-home fa-lg fa-fw link-color\"></i>) is the entry point of the report. This page contains the diagram that was selected as the starting diagram when the report was created. Therefore the contents of the start page can differ for each report. The diagram on the start page can also be found on the overview page.</p>",

			"help_diagramspage" : "Overview page",
			"help_diagramspage_contents" : "<p>The overview page (<i class=\"fa fa-th fa-lg fa-fw link-color\"></i>) provides an overview of all models and their diagrams available in the report. The menu shows the names of all models in alphabetical order. On the page, the diagrams are graphically displayed grouped by model.</p> <p>When clicking a model in the menu, the page jumps directly to the model and its diagrams on the overview page. By clicking on a diagram you will immediately be redirected to the corresponding diagram page.</p>",

			"help_diagrampage" : "Diagram page",
			"help_diagrampage_contents" : "The diagram page contains the graphical representation of a model diagram and the relevant information regarding the diagram. You can access the diagram page by clicking on a diagram on the overview page. You can also access the diagram page from other diagram pages or from object pages by clicking on a diagram in the 'Appears On' section of that page.</p>"+
			"<p>By clicking on an object shown in the diagram you will immediately navigate towards the object page or diagram page associated with that object. The menu on the diagram page shows the available sections and allows for immediate navigation towards that section on the diagram page.</p>",
				
			"help_viewpoints" : "Viewpoints",
			"help_viewpoints_contents" : "<p>For each available viewpoint on a diagram a button with the name of the viewpoint next to it is shown to control the state of the viewpoint. You can enable, pin or disable the viewpoint with this button.</p>"+
			"<p>InSite Lite supports the following two types of viewpoints:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-adjust fa-fw\"></i></td>"+
					"<td valign=\"top\"> color viewpoint</td>"+
				"</tr>"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-tag fa-fw\"></i></td>"+
					"<td valign=\"top\"> label viewpoint</td>"+
				"</tr>"+
			"</table></p>"+
			"<p>A color viewpoint changes the color scheme used in the diagram, and a label viewpoint adds textual information to the objects in the diagram. Only one color viewpoint and one label viewpoint can be active at the same time. The button to control a viewpoint has three possible states. Each time you click the button, its state changes:</p>"+
			"<p><table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-off\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">The viewpoint is disabled and has no effect on the diagram.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">The viewpoint is enabled and has changed the color scheme of the diagram, or it has added textual information to the objects on the diagram. A legend is shown underneath the diagram specific to the active viewpoint.</td>"+
				"</tr>"+
			
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i><span class=\"btn-viewpoint-on-right-section\"></span><i class=\"fa fa-thumb-tack fa-fw\"></i></a></td>"+
					"<td valign=\"top\">The viewpoint is enabled and pinned. When you navigate to another diagram page, the viewpoint will remain enabled and will automatically be applied to any relevant diagram. Even if the viewpoint is not available for a particular diagram, it will remain enabled. However it will not have any effect on that diagram.</td>"+ 
				"</tr>"+
			"</table></p>",

			"help_objectpage" : "Object page",
			"help_objectpage_contents" : "<p>The object page shows information regarding a specific object. You can reach the object page from a diagram page or from another object page.</p>"+
			"<p>The object page has the same structure as the diagram page; it contains information about the object divided into multiple sections. The object page does not have a graphical representation of the object nor does it contains any viewpoint buttons.</p>",
				
			"help_helppage" : "Help page",
			"help_helppage_contents" : "<p>The help page (<i class=\"fa fa-question fa-lg fa-fw link-color\"></i>) is the page you are currently reading.</p>",

			"help_navigation" : "Navigation",
			"help_navigation_contents" : "<p>The InSite Lite report has multiple ways of navigation. The most important one is the navigation bar on the top of each page, which controls the navigation through the entire report. For navigation within a page a menu and an arrow (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) to the right of the title of each section are available on the page.</p>",

			"help_navbar" : "Navigation bar",
			"help_navbar_contents" : "<p>The navigation bar is available on each page en contains the following controls for navigating through the report:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-left fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Go back to the previous page.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-right fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Go to the next page.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-home fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Go to the start page of the InSite Lite report. This page is the entry point of the report.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-th fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Go to the overview page of the InSite Lite report. This page contains all models and their diagrams available in the report.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-question fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Go to this help page.</td>"+
				"</tr>"+
			"</table></p>",

			"help_context_menu" : "Menu",
			"help_context_menu_contents" : "<p>The menu is present on various pages and offers an overview of the available sections on the page. This menu is located on the left side of the page or at the top of the page, depending on the available space on your screen or browser window. The contents of this menu is dynamically customized for each page. By clicking on an item in the menu, you will directly navigate to that section on the page.</p>",
			
			"help_onpage_navigation" : "Navigation on the page",
			"help_onpage_navigation_contents" : "<p>On pages with multiple sections there will be an arrow on the right side of each section title (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>). When you click on this arrow button you will return to the top of the page.</p>",
				
			"help_search" : "Searching",
			"help_search_contents" : "<p>You can search in two places in the report:</p>"+
			"<p>The overview page of InSite Lite offers the ability to search for diagrams. You can search for a diagram by entering a search query in the search box. You can only search for (parts of) names of the diagrams, not for names of underlying items such as objects, object properties, or viewpoints. The contents of the overview page will be updated with search results as you type. The results are grouped per model, and only diagrams that match your search query will be shown for a model. The search results are ordered by model with the most matching diagrams.</p>"+
			"<p>In addition, a search box is present in the upper right corner of each page of the report. It allows you to search for elements through the entire report. Enter a search term and press Enter. The results are presented in a list. The list contains all elements that contain the search term. When clicking on an element, the page of the report where the element is located, is presented. If the search delivers no results, the list remains empty.</p>",

			"help_search_remove" : "Clearing search results",
			"help_search_remove_contents" : "<p>To clear the search results simply click on the remove button (<i class=\"fa fa-times\"></i>) next to the search box and all diagrams will be shown again.</p>",
			
			"name" : "Name",
			"info" : "Showing _START_ to _END_ of _TOTAL_ entries",
			"zeroRecords": "Nothing found - sorry",
			"infoEmpty": "No records available",
			"infoFiltered": "(filtered from _MAX_ total records)"
			
		}
	},
	"nl" : {
		translation : {
			"back_button" : "Terug",
			"forward_button" : "Vooruit",
			"home_button" : "Start",
			"all_views_button" : "Diagrammen",
			"help_button": "Help",
			"properties_message" : "Eigenschappen",
			"property_name_message" : "Eigenschap",			
			"property_value_message" : "Waarde",
			"on_screen_guidance_title" : "Begeleiding op het scherm",
			"osg_type" : "Type",
			"feature_under_development" : "Deze functie is in ontwikkeling",			
			"osg_feature_under_development_details": "Hier ziet u informatie die u helpt te begrijpen wat het object betekent, wat het objecttype betekent en welke concepten relevant zijn in relatie tot dit object.",
			"view" : "Diagram",
			"viewpoint_legend_no_info" : "Geen viewpointlegenda-informatie beschikbaar voor dit diagram",
			"object_information" : "Details",
			"object_views" : "Komt voor op",
			"object_relations" : "Relaties",
			"relation_via_message": "Rol",
			"relation_to_message": "Naar",
			"filter_inputfield_text": "Diagrammen zoeken",
			"filter_clear_text": "Klik hier om de zoektekst te wissen",
			"filter_result": "Resultaat",
			"filter_1_diagram" : "diagram",
			"filter_x_diagrams" : "diagrammen",
			"index-page-section-up": "Terug naar boven",
			"error_title" : "Fout",
			"error_notfound" : "Het object met id '__id__' is niet gevonden.",

			"help_general": "Algemeen",
			"help_general_content" : "<p>Welkom op de helppagina van de InSite Lite-rapportage. Op deze pagina vindt u informatie over de structuur van de rapportage en de navigatie door de pagina's van de rapportage.</p>",
			
			"help_components" : "Onderdelen",
			"help_components_contents" : "<p>De InSite Lite-rapportage bestaat uit een aantal vaste onderdelen, een startpagina, overzichtspagina, een of meer diagram- en objectpagina's en deze helppagina.</p>",
			
			"help_startpage" : "Startpagina",
			"help_startpage_contents" : "<p>De startpagina (<i class=\"fa fa-home fa-lg fa-fw link-color\"></i>) vormt de ingang van de rapportage. De pagina bevat het diagram dat als startdiagram is ingesteld door degene die het rapport heeft gegenereerd. De inhoud van deze pagina kan dus verschillen van rapportage tot rapportage. Het startdiagram kunt u ook terugvinden op de overzichtspagina.</p>",

			"help_diagramspage" : "Overzichtspagina",
			"help_diagramspage_contents" : "<p>De overzichtspagina (<i class=\"fa fa-th fa-lg fa-fw link-color\"></i>) biedt een overzicht van alle modellen en hun diagrammen die in de rapportage zijn opgenomen. In het menu staan de namen van de modellen alfabetisch gesorteerd. Op de pagina worden alle diagrammen gegroepeerd per model grafisch weergegeven.</p> <p>Wanneer u in het menu op een model klikt, gaat de pagina direct naar het model en de bijbehorende diagrammen op de overzichtspagina. Klikt u op een diagram, dan wordt de diagrampagina van dit diagram geopend.</p>",
			
			"help_diagrampage" : "Diagrampagina",
			"help_diagrampage_contents" : "<p>De diagrampagina bevat de grafische weergave van een modeldiagram met aanvullende informatie over dat diagram. U kunt de diagrampagina bereiken vanuit de overzichtspagina door daar op een diagram te klikken. U kunt er ook vanuit een andere diagram- of objectpagina komen door daar in het onderdeel 'Komt voor op' op een diagram te klikken.</p>"+
			"<p>Binnen het diagram kunt u op een object klikken om door te gaan naar de objectpagina met informatie over het object, of een andere diagrampagina die aan het object gekoppeld is. In het menu vindt u de onderdelen van het diagram. Wanneer u op een onderdeel klikt, springt de pagina direct naar het betreffende onderdeel.</p>",

			"help_viewpoints" : "Viewpoints",
			"help_viewpoints_contents" : "<p>Als er bij een diagram viewpoints beschikbaar zijn, worden direct onder het diagram een of meer knoppen weergegeven met daarachter de naam van het viewpoint. Met deze knoppen kunt u de viewpoints in- en uitschakelen en vastzetten.</p>"+
			"<p>InSite Lite kent de volgende twee soorten viewpoints: "+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-adjust fa-fw\"></i></td>"+
					"<td valign=\"top\"> kleurenviewpoint</td>"+
				"</tr>"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-tag fa-fw\"></i></td>"+
					"<td valign=\"top\"> labelviewpoint</td>"+
				"</tr>"+
			"</table></p>"+
			"<p>Een kleurenviewpoint verandert het kleurenschema dat in het diagram gebruikt wordt, bij een labelviewpoint wordt tekstuele informatie bij de objecten in het diagram geplaatst. Er kunnen maar &#233;&#233;n kleurenviewpoint en &#233;&#233;n labelviewpoint tegelijkertijd actief zijn. De knop waarmee u de viewpoints in- en uitschakelt, kan drie standen hebben. Door steeds op de knop te klikken verandert u de situatie:</p>"+
			"<p><table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-off\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Het viewpoint is niet ingeschakeld en heeft geen effect op het diagram.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Het viewpoint is ingeschakeld en heeft het kleurenschema van het diagram gewijzigd dan wel tekstlabels bij objecten geplaatst. Onder het diagram wordt een legenda weergegeven die specifiek voor dit viewpoint is.</td>"+
				"</tr>"+
				
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i><span class=\"btn-viewpoint-on-right-section\"></span><i class=\"fa fa-thumb-tack fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Het viewpoint is actief en vastgezet. Wanneer u naar een andere diagrampagina gaat, blijft het viewpoint ingeschakeld en wordt deze toegepast op elk diagram dat u benadert, mits van toepassing. Ook als een viewpoint niet voor een bepaald diagram beschikbaar is, blijft het ingeschakeld. Het heeft alleen geen effect op dit diagram.</td>"+
				"</tr>"+
			"</table></p>",
			
			"help_objectpage" : "Objectpagina",
			"help_objectpage_contents" : "<p>De objectpagina toont informatie over een specifiek object. De objectpagina kunt u bereiken vanuit een diagrampagina of vanuit een andere objectpagina.</p>"+
			"<p>De objectpagina lijkt wat betreft opbouw op een diagrampagina; de pagina bevat informatie over het object, ondergebracht in verschillende onderdelen. De objectpagina heeft echter geen afbeelding van het object en bevat geen knoppen voor viewpoints.</p>",
			
			"help_helppage" : "Helppagina",
			"help_helppage_contents" : "<p>De helppagina (<i class=\"fa fa-question fa-lg fa-fw link-color\"></i>) is de pagina waarop u zich op dit moment bevindt.</p>",

			"help_navigation" : "Navigatie",
			"help_navigation_contents" : "<p>De InSite Lite-rapportage heeft verschillende navigatiemogelijkheden. De belangrijkste hiervan is de navigatiebalk boven aan iedere pagina voor navigatie door de hele rapportage. Voor navigatie op de pagina zijn er een menu en een pijl (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) rechts naast de titel van ieder onderdeel beschikbaar op de pagina.</p>",

			"help_navbar" : "Navigatiebalk",
			"help_navbar_contents" : "<p>De navigatiebalk boven aan de pagina is op iedere pagina aanwezig en bevat de volgende besturingselementen om door de rapportagetool te navigeren:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-left fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Ga terug naar de vorige pagina.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-right fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Ga naar de volgende pagina.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-home fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Ga naar de startpagina van de InSite Lite-rapportage. Deze pagina is het startpunt van de rapportage.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-th fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Ga naar de overzichtspagina van de InSite Lite-rapportage. Deze pagina bevat alle modellen en bijbehorende diagrammen die in de rapportage zijn opgenomen.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-question fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Ga naar deze helppagina.</td>"+
				"</tr>"+
			"</table></p>",

			"help_context_menu" : "Menu",
			"help_context_menu_contents" : "<p>Het menu is op verschillende pagina's aanwezig en biedt een overzicht van de beschikbare onderdelen op de pagina. Dit menu bevindt zich aan de linkerkant van de pagina of boven aan de pagina, afhankelijk van de beschikbare ruimte op uw scherm of het venster van de webbrowser. De inhoud van dit menu is afhankelijk van de pagina waarop u zich bevindt. Wanneer u op een onderdeel in het menu klikt, springt de pagina er direct naartoe.</p>",

			"help_onpage_navigation" : "Navigatie op de pagina",
			"help_onpage_navigation_contents" : "<p>Op pagina's met meerdere onderdelen staat naast de titel van het onderdeel aan de rechterkant een pijl (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>). Als u hierop klikt, gaat u terug naar het begin van de pagina.</p>",

			"help_search" : "Zoeken",
			"help_search_contents" : "<p>U kunt op twee plaatsen in de rapportage zoeken:</p>"+
			"<p>Op de overzichtspagina van InSite Lite kunt u zoeken naar diagrammen. Hiervoor voert u in het zoekvak boven het menu een zoekterm in. U kunt alleen zoeken op (delen van) namen van diagrammen, niet op namen van onderliggende zaken zoals objecten, objecteigenschappen of viewpoints. De overzichtspagina wordt direct aangepast op basis van de zoekterm. Per model wordt het resultaat van uw zoekactie getoond. Alleen diagrammen die overeenkomen met de zoekterm worden bij het model getoond. Het model met de meeste overeenkomende diagrammen staat bovenaan.</p>"+
			"<p>Daarnaast is op iedere pagina van de rapportage in de rechterbovenhoek een zoekvak aanwezig. Hiermee kunt u door de gehele rapportage zoeken naar elementen. Voer een zoekterm in en druk op Enter. De resultaten worden gepresenteerd in een lijst. De lijst bevat alle elementen waarin de zoekterm voorkomt. Wanneer u op een element klikt, springt u naar de locatie van het element in de rapportage. Levert de zoekactie geen resultaten op, dan blijft de lijst leeg.</p>",

			"help_search_remove" : "Zoekactie verwijderen",
			"help_search_remove_contents" : "<p>Om een zoekactie te verwijderen klikt u op het kruisje (<i class=\"fa fa-times\"></i>) achter het zoekvak. Vervolgens worden alle diagrammen van alle aanwezige modellen weer getoond.</p>",
			
			"name" : "Naam",
			"zeroRecords": "Niets gevonden - sorry",
			"info" : "Resulaten _START_ tot _END_ van _TOTAL_ weergegeven",
			"infoEmpty": "Geen data om weer te geven",
			"infoFiltered": " (gefilterd uit _MAX_ regels)"	
		}
	},
	"de" : {
			translation : {
			"back_button" : "Zurück",
			"forward_button" : "Weiter",
			"home_button" : "Start",
			"all_views_button" : "Diagramme",
			"help_button": "Hilfe",
			"properties_message" : "Eigenschaften",
			"property_name_message" : "Eigenschaft",			
			"property_value_message" : "Wert",
			"on_screen_guidance_title" : "Anweisungen auf dem Bildschirm",
			"osg_type" : "Typ",
			"feature_under_development" : "Diese Funktion wird gerade entwickelt",			
			"osg_feature_under_development_details": "Hier werden Sie Informationen sehen die beim Verständniss des Objektes und Objekttyps Hilfestellung bieten und welche konzepten in Verbindung mit diesem Objekt von Bedeutung sind.",
			"view" : "Diagramm",
			"viewpoint_legend_no_info" : "Informationen zum Perspektivenlegende steht für dieses Diagramm nicht zur Verfügung",
			"object_information" : "Details",
			"object_views" : "Erscheint auf",
			"object_relations" : "Beziehungen",
			"relation_via_message": "Rolle",
			"relation_to_message": "An",
			"filter_inputfield_text": "Diagramme suchen",
			"filter_clear_text": "Klicken Sie hier, um den Suchtext zu löschen",
			"filter_result": "Resultat",
			"filter_1_diagram" : "Diagramm",
			"filter_x_diagrams" : "Diagramme",
			"index-page-section-up": "Zurück nach oben",
			"error_title" : "Fehler",
			"error_notfound" : "Das Objekt mit der ID '__id__' konnte nicht gefunden werden.",

			"help_general": "Allgemein",
			"help_general_content" : "<p>Willkommen auf der Hilfeseite des InSite Lite Berichts. Hier finden Sie Informationen in Bezug auf die Struktur des Berichts und wie Sie durch die Seiten des Berichts navigieren können.</p>",
			
			"help_components" : "Komponenten",
			"help_components_contents" : "<p>Das InSite Lite Bericht besteht aus mehreren Komponenten; Eine Startseite, eine Übersichtsseite, eine oder mehrere Diagrammseiten, eine oder mehrere Objektseiten und diese Hilfeseite.</p>",
			
			"help_startpage" : "Startseite",
			"help_startpage_contents" : "<p>Die Startseite (<i class=\"fa fa-home fa-lg fa-fw link-color\"></i>) ist der Anfang des Berichts. Diese Seite beinhaltet das Diagramm, dass als Startdiagramm bei der Erstellung des Berichtes festgelegt wurde. Deshalb kann der Inhalt der Startseite für jedes Bericht anders sein. Das Diagramm auf der Startseite ist ebenfalls auf der Übersichtseite.</p>",

			"help_diagramspage" : "Übersichtsseite",
			"help_diagramspage_contents" : "<p>Die Übersichtsseite (<i class=\"fa fa-th fa-lg fa-fw link-color\"></i>) zeigt alle im Bericht zur Verfügung stehende Modelle und Diagramme. Das Menü zeigt alle Modelle in alfabetische Reihe. Auf der Seite werden die Diagramme grafisch dargestellt und sortiert nach Modell.</p> <p>Beim Klicken auf ein Modell in dem Menü, springt die Seite direkt auf das Modell und seine Diagramme auf der Übersichtsseite. Klicken Sie auf einem Diagramm um auf der entsprechenden Diagrammseite zu gelangen.</p>",
			
			"help_diagrampage" : "Diagrammseite",
			"help_diagrampage_contents" : "<p>Die Diagrammseite enthält die grafische Darstellung eines Modelldiagramms sowie die entsprechenden Informationen dazu. Sie gelangen zur Diagrammseite, wenn Sie auf ein Diagramm auf der Übersichtsseite klicken. Sie können zu der Diagrammseite auch von einer anderen Diagrammseite oder Objektseite gelangen. Klicken Sie dafür auf ein Diagram in dem 'Erscheint auf' Abschnitt von der Seite.</p>"+
			"<p>Das Klicken eines Objekts im Diagramm führt Sie direkt zur entsprechenden Objekt- oder Diagrammseite von diesem Objekt. Das Menü der Diagrammseite zeigt die zur Verfügung stehenden Sektionen des Diagramms an und ermöglicht die direkte Navigation zu einer Sektion.</p>",

			"help_viewpoints" : "Perspektiven",
			"help_viewpoints_contents" : "<p>Für jede verfügbare Perspektive eines Diagramms wird eine Schaltfläche mit daneben dem Namen der Perspektive angezeigt und ermöglicht die Statusanzeige der Perspektive. Mit dieser Schaltfläche können Sie die Perspektive einschalten, ausschalten oder anheften.</p>"+
			"<p>InSite Lite unterstützt folgenden Perspektivetypen: "+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-adjust fa-fw\"></i></td>"+
					"<td valign=\"top\"> Farbperspektive</td>"+
				"</tr>"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-tag fa-fw\"></i></td>"+
					"<td valign=\"top\"> Etikettenperspektive</td>"+
				"</tr>"+
			"</table></p>"+
			"<p>Eine Farbperspektive verändert das Farbschema welches im Diagramm verwendet wird und eine Etikettenperspektive fügt Textinformation zum Objekt im Diagramm hinzu. Nur eine Farbperspektive und eine Etikettenperspektive können gleichzeitig aktiviert sein. Die Schaltfläche um die Perspektive zu kontrollieren hat drei mögliche Status. Jedes Mal, wenn Sie auf die Schaltfläche klicken, ändert ihren Zustand:</p>"+
			"<p><table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-off\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Die Perspektive ist inaktiv und hat somit keinen Effekt auf das Diagramm.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Die Perspektive ist aktiv und hat das Farbschema vom Diagramm geändert oder dem Objekt auf dem Diagramm wurde Text hinzugefügt. Eine Legende unter der aktiven Perspektive wird angezeigt.</td>"+
				"</tr>"+
				
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i><span class=\"btn-viewpoint-on-right-section\"></span><i class=\"fa fa-thumb-tack fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Die Ansicht ist aktiv und angeheftet. Beim navigieren zur einer anderen Diagrammseite wird die Perspektive aktiv bleiben und automatisch auf relevante Diagramme angewendet werden. Auch, wenn eine Perspektive nicht für ein bestimmtes Diagramm verfügbar ist, bleibt es eingeschalten. Es hat nur kein Effekt auf dieses Diagramm.</td>"+
				"</tr>"+
			"</table></p>",
			
			"help_objectpage" : "Objektseite",
			"help_objectpage_contents" : "<p>Die Objektseite beiinhaltet Informationen über ein spezifisches Objekt. Die Objektseite kann von einer Diagrammseite oder eine andere Objektseite erreicht werden.</p>"+
			"<p>Die Objektseite hat die gleiche Struktur wie die Diagrammseite und beinhaltet Informationen über das in Sektionen aufgeteilte Objekt. Allerdings hat die Objektseite kein Bild vom Objekt noch Schaltflächen für Perspektiven.</p>",
			
			"help_helppage" : "Hilfeseite",
			"help_helppage_contents" : "<p>Die Hilfeseite (<i class=\"fa fa-question fa-lg fa-fw link-color\"></i>) ist die Seite die Sie gerade lesen.</p>",

			"help_navigation" : "Navigation",
			"help_navigation_contents" : "<p>Der InSite Lite Bericht erlaubt viele Navigationsmöglichkeiten. Die wichtigste Möglichkeit ist die Navigationsleiste - diese befindet sich am Anfang jeder Seite und regelt die Navigation durch den gesammten Bericht. Die Navigation innerhalb einer Seite ist möglich - dazu steht auf der Seite ein Menü zur Verfügung und gibt es einen Pfeil (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) rechts neben der Sektionsüberschrift.</p>",

			"help_navbar" : "Navigationsleiste",
			"help_navbar_contents" : "<p>Die Navigationsleiste steht auf jeder Seite zur Verfügung und erlaubt folgende Navigationseinstellungen:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-left fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Zurück zur vorherigen Seite.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-right fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Zur nächsten Seite.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-home fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Zur Startseite des InSite Lite Berichts. Diese Seite ist der Anfang des Berichts.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-th fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Zur Übersichtsseite vom InSite Lite Bericht. Diese Seite zeigt alle Modelle und Diagramme die im Bericht zur Verfügung stehen.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-question fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Zu dieser Hilfseite gehen.</td>"+
				"</tr>"+
			"</table></p>",

			"help_context_menu" : "Menü",
			"help_context_menu_contents" : "<p>Das Menü befindet sich auf verschiedene Seiten und bietet eine Übersicht über die verfügbare Sektionen der Seite. Dieses Menü befindet sich auf der linken Seite oder am Anfang der Seite, abhängig vom zur Verfügung stehendem Platz auf dem Bildschirm oder Browser-Fenster. Der Inhalt des Menüs wird dynamisch für jede Seite erstellt. Wenn Sie im Menü auf ein Item klicken, gelangen Sie direkt zur entsprechenden Sektion.</p>",

			"help_onpage_navigation" : "Navigation auf der Seite",
			"help_onpage_navigation_contents" : "<p>Auf Seiten mit mehreren Sektionen finden Sie Pfeile auf der rechten Seite von jeder Sektionsüberschrift (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>). When Sie auf diesen Pfeil klicken, gelangen Sie automatisch zum Anfang der Seite.</p>",

			"help_search" : "Suche",
			"help_search_contents" : "<p>Sie können an zwei Orten im Bericht suchen:</p>"+
			"<p>Die Übersichtsseite von InSite Lite bietet die Möglichkeit der Suche nach Diagrammen. Um dies zu tun, geben Sie in das Suchfeld oberhalb des Menüs einen Suchbegriff ein. Sie können nur nach (Teile von) Diagrammnamen suchen, nicht nach Namen der zugrunde liegenden Themen wie Objekte, Objekteigenschaften oder Perspektiven. Der Inhalt der Übersichtsseite wird gleich aktualisiert beim Eingeben des Suchbegriffs. Die Suchergebnisse werden pro Modell gruppiert. Nur Diagramme, die die Suche entsprechen, werden im Modell dargestellt. Die Suchergebnisse werden bestellt beim Modell mit den höchsten entsprechenden Diagramme.</p>"+
			"<p>Zusätzlich ist ein Suchfeld vorhanden in der oberen rechten Ecke jeder Seite des Berichts. Es ermöglicht Ihnen, für die Elemente durch den gesamten Bericht zu suchen. Geben Sie einen Suchbegriff ein und drücken Sie die Eingabetaste. Die Ergebnisse werden in einer Liste angezeigt. Die Liste enthält alle Elemente, die den Suchbegriff enthalten. Beim Klicken auf ein Element, wird der Seite des Berichts vorgestellt wo das Element sich befindet. Wenn die Suche zu keinen Ergebnissen führen, bleibt die Liste leer.</p>",

			"help_search_remove" : "Suchergebnisse entfernen",
			"help_search_remove_contents" : "<p>Um Suchergebnisse zu entfernen, bitte die Löschen Schaltfläche (<i class=\"fa fa-times\"></i>) hinter dem Suchfeld klicken und die Diagramme werden wieder angezeigt.</p>",
			
			"name" : "Name",
			"info" : "_START_ bis _END_ von _TOTAL_ Einträgen",
			"zeroRecords": "Keine Einträge vorhanden.",
			"infoEmpty": "Keine Einträge vorhanden.",
			"infoFiltered": "(gefiltert von _MAX_ Einträgen)"
		}
	},
	"fr" : {
			translation : {
			"back_button" : "Retour",
			"forward_button" : "Suivant",
			"home_button" : "Accueil",
			"all_views_button" : "Diagrammes",
			"help_button": "Aide",
			"properties_message" : "Propriétés",
			"property_name_message" : "Propriété",			
			"property_value_message" : "Valeur",
			"on_screen_guidance_title" : "Directives à l'écran",
			"osg_type" : "Type",
			"feature_under_development" : "Cette fonctionnalité est en développement",			
			"osg_feature_under_development_details": "Vous trouverez ici des informations qui vous aideront à comprendre ce que l'objet signifie, ce que le type de l'objet veut dire, et quels concepts sont pertinents par rapport à cet objet.",
			"view" : "Diagramme",
			"viewpoint_legend_no_info" : "Aucune information comme légende de ce point de vue",
			"object_information" : "Détails",
			"object_views" : "Apparaît dans",
			"object_relations" : "Relations",
			"relation_via_message": "Rôle",
			"relation_to_message": "Vers",
			"filter_inputfield_text": "Rechercher diagrammes",
			"filter_clear_text": "Cliquez ici pour effacer la requête de la recherche",
			"filter_result": "Résultat",
			"filter_1_diagram" : "diagramme",
			"filter_x_diagrams" : "diagrammes",
			"index-page-section-up": "Retour au haut de la page",
			"error_title" : "Erreur",
			"error_notfound" : "Objet avec l'ID '__id__' n'est pas trouvé.",

			"help_general": "Général",
			"help_general_content" : "<p>Bienvenue sur la page d'aide du rapport InSite Lite. Sur cette page vous trouverez des informations au sujet de la structure du rapport et comment naviguer à travers les pages du rapport.</p>",
			
			"help_components" : "Composants",
			"help_components_contents" : "<p>Le rapport InSite Lite est constitué de multiple composants; une page de démarrage, une page de vue d'ensemble, une ou plusieurs pages de diagrammes, une ou plusieurs pages pour les objets, et cette page d'aide.</p>",
			
			"help_startpage" : "Page de démarrage",
			"help_startpage_contents" : "<p>La page de démarrage (<i class=\"fa fa-home fa-lg fa-fw link-color\"></i>) est le point d'entrée dans le rapport. Cette page contient le diagramme qui a été choisi comme diagramme de début quand le rapport a été créé. C'est pourquoi le contenu de la page de démarrage peut être différent dans chaque rapport. Le diagramme sur la page de démarrage du rapport peut aussi être trouvé sur la page de vue d'ensemble.</p>",

			"help_diagramspage" : "Page de vue d'ensemble",
			"help_diagramspage_contents" : "<p>La page de vue d'ensemble (<i class=\"fa fa-th fa-lg fa-fw link-color\"></i>) fournit un aperçu de tous les modèles et de leurs diagrammes existant dans le rapport. Le menu montre les noms de tous les modèles dans leur ordre alphabétique. Sur la page, tous les diagrammes sont présentés graphiquement regroupés par modèle.</p> <p>Lorsque vous cliquez sur un modèle dans le menu, la page va directement au modèle et les diagrammes correspondants sur la page de vue d'ensemble. En cliquant sur un diagramme vous serez immédiatement redirigé vers la page correpondant à ce diagramme.</p>",
			
			"help_diagrampage" : "Page de diagramme",
			"help_diagrampage_contents" : "<p>La page de diagramme contient la représentation graphique d'un diagramme du modèle ainsi que les informations associées à ce diagramme. Vous pouvez accéder à la page de diagramme en cliquant sur le diagramme situé sur la page de vue d'ensemble. Vous pouvez aussi accéder aux pages des autres diagrammes ou objets en cliquant sur un diagramme apparaissant dans la section \"Apparaît dans\" de cette page.</p>"+
			"<p>En cliquant sur un objet montré dans le diagramme, vous naviguerez immédiatement vers la page de l'objet ou du diagramme associé à cet objet. Le menu sur la page du diagramme montre les sections disponibles et permet de naviguer immédiatement vers la section désirée sur cette page.</p>",

			"help_viewpoints" : "Points de vue",
			"help_viewpoints_contents" : "<p>Pour chaque point de vue disponible sur un diagramme, un bouton, avec le nom du point de vue situé derrière est montré pour contrôler l'état du point de vue. Avec ce bouton, il vous est possible d'activer, ou de désactiver, ou d'épingler ce point de vue.</p>"+
			"<p>InSite Lite supporte les deux types suivants de points de vue: "+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-adjust fa-fw\"></i></td>"+
					"<td valign=\"top\"> point de vue couleur</td>"+
				"</tr>"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-tag fa-fw\"></i></td>"+
					"<td valign=\"top\"> point de vue libellé</td>"+
				"</tr>"+
			"</table></p>"+
			"<p>Un point de vue couleur change le code des couleurs utilisées dans un diagramme, et un point de vue libellé ajoute des informations sous forme de texte aux objets du diagramme. Seulement un point de vue couleur et un point de vue libellé peuvent être actifs en même temps. Le bouton pour contrôler le point de vue a les trois états. En cliquant sur le bouton vous changez la situation:</p>"+
			"<p><table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-off\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Le point de vue est désactivé et n'a aucun effet sur le diagramme.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Le point de vue est activé et il a soit son code couleurs de modifier sur le diagramme, soit des informations sous forme de texte ajoutées aux objets sur le diagramme. Une légende est mise sous le diagramme pour lequel le point de vue est activé.</td>"+
				"</tr>"+
				
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i><span class=\"btn-viewpoint-on-right-section\"></span><i class=\"fa fa-thumb-tack fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Le point de vue est activé et épinglé. Quand vous naviguez vers une autre page de diagramme, le point de vue restera activé et sera automatiquement appliqué à tout diagramme où il sera applicable. Le point de vue restera actif même s'il n'est pas applicable à un diagramme particulier. Dans ce cas cependant, il n'aura aucun effet sur un tel diagramme.</td>"+
				"</tr>"+
			"</table></p>",
			
			"help_objectpage" : "Page objet",
			"help_objectpage_contents" : "<p>La page objet montre les informations relatives à un objet donné. Vous pouvez atteindre la page objet à partir d'une page diagramme ou d'une autre page objet.</p>"+
			"<p>La page objet a la même structure que la page diagramme. Elle contient, au sujet de l'objet, des informations réparties dans plusieurs sections. La page objet n'a pas de représentation graphique de l'objet ni de boutons associés à des points de vue.</p>",
			
			"help_helppage" : "Page d'aide",
			"help_helppage_contents" : "<p>La page d'aide (<i class=\"fa fa-question fa-lg fa-fw link-color\"></i>) est la page que vous être en train de lire.</p>",

			"help_navigation" : "Navigation",
			"help_navigation_contents" : "<p>Le rapport InSite Lite offre plusieurs manières de naviguer. Le moyen de navigation le plus important est la barre de navigation située en haut de chacune des pages, car elle contrôle la navigation au travers de l'ensemble du rapport. Pour naviguer dans une page, un menu et une flêche (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) à la droite du titre de chacune des sections sont disponibles sur la page.</p>",

			"help_navbar" : "Barre de navigation",
			"help_navbar_contents" : "<p>La barre de navigation en haut de la page est disponible sur chacune des pages et comprend les contrôles suivants pour naviguer au travers du rapport:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-left fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Retour à la page précédente.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-right fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Aller à la page suivante.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-home fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Aller à la page de démarrage du rapport InSite Lite. Cette page est le point d'entrée du rapport.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-th fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Aller à la page de vue d'ensemble du rapport InSite Lite. Cette page contient tous les modèles et leurs diagrammes disponibles dans le rapport.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-question fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Aller à cette page d'aide.</td>"+
				"</tr>"+
			"</table></p>",

			"help_context_menu" : "Menu",
			"help_context_menu_contents" : "<p>Le menu est présent sur différentes pages et offre une vue d'ensemble sur les différentes sections disponibles sur la page. Ce menu est situé sur le coté gauche de la page ou au sommet de la page, en fonction de l'espace disponible sur l'écran ou dans la fenêtre du navigateur. Le contenu de ce menu est mis à jour de façon dynamique sur chacune des pages. En cliquant sur un des éléments du menu, vous naviguerez directement vers la section correspondante sur la page.</p>",

			"help_onpage_navigation" : "Navigation sur la page",
			"help_onpage_navigation_contents" : "<p>Sur les pages ayant de multiples sections, il y aura une flêche (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) à la droite du titre de chacune des sections. En cliquant sur cette flêche vous retournerez au sommet de la page.</p>",

			"help_search" : "Rechercher",
			"help_search_contents" : "<p>Vous pouvez chercher à deux endroits dans le rapport:</p>"+
			"<p>La page de vue d'ensemble d'InSite Lite permet de faire des recherches dans les diagrammes. On peut rechercher un diagramme en entrant des requêtes dans la zone de recherche. Vous pouvez seulement rechercher des (parties de) noms de diagrammes, pas les noms des éléments enfants tels que des objets, propriétés de l'objet, ou points de vue. Le contenu de la page de vue d'ensemble sera mis à jour avec les résultats de la recherche que vous aurez saisie. Les résultats seront groupés par modèle, et seulement les diagrammes qui correspondront à votre recherche seront montrés. Les résultats de la recherche seront ordonnés par modèle ayant les diagrammes correspondant le mieux à la requête.</p>"+
			"<p>En outre, une zone de recherche est présent dans le coin supérieur droit de chaque page du rapport. Il vous permet de rechercher des éléments à travers l'ensemble du rapport. Entrez un terme de recherche et appuyez sur Entrée. Les résultats sont présentés dans une liste. La liste contient tous les éléments qui contiennent le terme de recherche. Lorsque vous cliquez sur un élément, la page du rapport où se trouve l'élément, est présenté. Si la recherche n'a pas de résultats, la liste reste vide.</p>",

			"help_search_remove" : "Effacer les résultats de la recherche",
			"help_search_remove_contents" : "<p>Pour effacer les résultats de la recherche il suffit de cliquer sur le bouton supprimer (<i class=\"fa fa-times\"></i>) à coté du zone de recherche et tous les diagrammes réapparaitront à nouveau.</p>",
			
			"name" : "Nom",
			"zeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
			"info":           "Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
			"infoEmpty":      "Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments",
			"sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)"		
		}
	},
	"es" : {
		translation : {
			"back_button" : "Atrás",
			"forward_button" : "Adelante",
			"home_button" : "Inicio",
			"all_views_button" : "Diagramas",
			"help_button": "Ayuda",
			"properties_message" : "Propriedades",
			"property_name_message" : "Propriedad",			
			"property_value_message" : "Valor",
			"on_screen_guidance_title" : "Guía sencilla en pantalla",
			"osg_type" : "Tipo",
			"feature_under_development" : "Este función se está preparando",			
			"osg_feature_under_development_details": "Aqui podrán ver la información para ayudar que significa el objeto, que significa el tipo de objeto y dominar los conceptos más relevantes en relación con este objeto.",
			"view" : "Diagrama",
			"viewpoint_legend_no_info" : "No información de leyenda del punto de vista está disponible para este diagrama",
			"object_information" : "Detalles",
			"object_views" : "Aparece en",
			"object_relations" : "Relaciones",
			"relation_via_message": "Papel",
			"relation_to_message": "Hacia",
			"filter_inputfield_text": "Buscar diagramas",
			"filter_clear_text": "Haga click aquí para borrar el texto de búsqueda",
			"filter_result": "Resulto",
			"filter_1_diagram" : "diagrama",
			"filter_x_diagrams" : "diagramas",
			"index-page-section-up": "Atrás hasta inicio de la página",
			"error_title" : "Error",
			"error_notfound" : "No se ha encontrado el objeto con id '__id__'.",

			"help_general": "General",
			"help_general_content" : "<p>Bienvenido en la página de ayuda del Informe InSite Lite. En este página encontrará información sobre la estructura del informe y como navigar en las páginas del informe.</p>",
			
			"help_components" : "Componentes",
			"help_components_contents" : "<p>El informe The InSite Lite consiste de componentes multiples; una página de inicio, una página de visión general, una o varias páginas de diagramas, y esta página de ayuda.</p>",
			
			"help_startpage" : "Página de inicio",
			"help_startpage_contents" : "<p>La página de inicio (<i class=\"fa fa-home fa-lg fa-fw link-color\"></i>) es el punto de entrada del informe. Esta página contiene el diagrama seleccionado como diagrama inicial cuando el informe estaba creado. Por eso el contenido de la página de inicio puede estar diferente para cada informe. El diagráma en la página principal se puede ver tambien en la página de visión general.</p>",

			"help_diagramspage" : "Página de visión general",
			"help_diagramspage_contents" : "<p>La página de visión general (<i class=\"fa fa-th fa-lg fa-fw link-color\"></i>) ofrece una vision de todos los modelos y sus diagramas disponibles en el informe. El menu muestre los nombres de todos los modelos en orden alfabético. En la página, los diagramas se muestran gráficamente agrupadas por modelo.</p> <p>Al hacer clic en un modelo en el menú, la página salta directamente al modelo y sus diagramas en la página de visión general. Haciendo clic sobre un diagrama usted está redirigido inmediatemente hasta la página del diagrama correspondiente.</p>",
			
			"help_diagrampage" : "Página de diagrama",
			"help_diagrampage_contents" : "<p>La página de diagramas contiene une representación gráfico de un modelo de diagrama i la información de este diagrama. Puede acceder el diagrama haciendo clic sobre un diagrama en la página de visión general. La página de diagrama se puede acceder tambien desde otras páginas de diagramas o páginas de objetos haciendo clic en la sección 'Aparece en' de esta página.</p>"+
			"<p>Haciendo clic sobre un objeto mostrado en el diagrama usted está redirigido inmediatemente hasta la página del objeto o la página del diagrama asociado con este objeto. El menu en la página del diagrama muestre los selecciónes disponibles y permite una navigación inmediata hasta la sección de la página de diagrama.</p>",

			"help_viewpoints" : "Puntos de vista",
			"help_viewpoints_contents" : "<p>Para cada punto de vista disponible en un diagrama un botón con el nombre del punto de vista junto a él se demuestra para controlar el estado del punto de vista. Se puede habilitar, hacer clic o deshabilitar el punto de vista con este botón.</p>"+
			"<p>InSite Lite apoya los dos tipos de puntos de vista siguientes:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-adjust fa-fw\"></i></td>"+
					"<td valign=\"top\"> punto de vista de color</td>"+
				"</tr>"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-tag fa-fw\"></i></td>"+
					"<td valign=\"top\"> punto de vista de etiqueta</td>"+
				"</tr>"+
			"</table></p>"+
			"<p>Un punto de vista de color cambia el esquema de colores utilizados en el diagrama, y a punto de vista de etiqueta agrega información textual a los objetos en el diagrama. Solamente un punto de vista de color y un punto de vista de etiqueta pueden ser activado al mismo tiempo. El botón donde se puede hacer clic para controlar un punto de vista puede tener 3 posibles estados. Cada vez que haga clic en el botón, sus cambios de estado:</p>"+
			"<p><table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-off\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">El punto de vista está desactivado y no afectará al diagrama.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">El punto de vista está activado y ha cambiado el esquema de colores del diagrama, o ha agregado información textual a los objetos en el diagrama. Una leyenda está visible abajo el diagrama específico al punto de vista activo.</td>"+
				"</tr>"+
				
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i><span class=\"btn-viewpoint-on-right-section\"></span><i class=\"fa fa-thumb-tack fa-fw\"></i></a></td>"+
					"<td valign=\"top\">El punto de vista está activado y anclado. Si navigues hasta otra página de diagrama, el punto de vista se quede activado y se aplicará automáticamente a cada diagrama relevante. Aunque el punto de vista no está disponible para un diagrama particular, permanecerá activado. Sin embargo no afectará este diagrama.</td>"+
				"</tr>"+
			"</table></p>",
			
			"help_objectpage" : "Página de objeto",
			"help_objectpage_contents" : "<p>La pagina de objeto muestre información con respecto a un objeto específico. Puede acceder la página de objeto desde una página de diagrama o desde otro página de objeto.</p>"+
			"<p>La página de objetos tiene la misma estructura que la página de diagrama; contiene información sobre el objeto dividio en secciónes multiples. La página de objeto no tiene ni una representación gráfica de un objeto ni contiene botones de puntos de vista.</p>",
			
			"help_helppage" : "Página de ayuda",
			"help_helppage_contents" : "<p>La página de ayuda (<i class=\"fa fa-question fa-lg fa-fw link-color\"></i>) es la página actual.</p>",

			"help_navigation" : "Navegación",
			"help_navigation_contents" : "<p>El informe de InSite Lite tiene multiple posibilidades de navegación. La mas importante es la barra de navegación en la parte superior de cada página, la que controla la navegación en el informe entero. Para navegación en una página un menú y una flecha a la derecha del titulo de cada sección (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) está disponible en la página.</p>",

			"help_navbar" : "Barra de navegación",
			"help_navbar_contents" : "<p>La barra de navegación está disponible en cada página y contiene los controles de navegación siguientes en el informe:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-left fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Volver a la página anterior.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-right fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Pasar a la página siguiente.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-home fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Pasar a la página de inicio del informe InSite Lite. Este página es el punto de entrada del informe.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-th fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Pasar a la página de visión general del informe InSite Lite. Este página contiene todos los modelos y sus diagramas disponibles en el informe.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-question fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Pasar a esta página de ayuda.</td>"+
				"</tr>"+
			"</table></p>",

			"help_context_menu" : "Menú",
			"help_context_menu_contents" : "<p>El menú está presente en varias páginas y offrece una vista general del los secciónes disponibles en la página. Este menú se encuentra a l'izquierda de la página o en la parte superior de la página, dependiente del espacio disponible en su pantalla o su ventana de navegador. El contenido de este menú está personalizado dinámicamente para cada página. Haciendo clic en un elemento en el menú, navegará directamente a una sección en la página.</p>",

			"help_onpage_navigation" : "Navegación en la página",
			"help_onpage_navigation_contents" : "<p>En páginas con secciónes multiples habra una flecha (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) a la derecha de cada título de sección. Si haces clic en este botón de flecha vuelve al inicio de la página.</p>",

			"help_search" : "Buscar",
			"help_search_contents" : "<p>Usted puede buscar en dos sitios en el informe:</p>"+
			"<p>La página de vista general de InSite Lite offrece la posibilidad de buscar diagramas. Puede buscar una diagrama escribiendo una consulta de búsqueda en el cuadro de búsqueda. Se puede buscar unicámente (partes de) nombres de diagramas, no para los nombres de los elementos subyacentes tales como objetos, las propiedades del objeto, o puntos de vista. El contenido de la página de vista general se actualizará con los resultados de la busqúeda a medida que escriba. Los resultados son agrupados por modelo, y unicamente los diagramas que se correspondan con la búsqueda serán mostrados para un modelo. Los resultados de la búsqueda son ordenados por modelo con la mayoría de diagramas.</p>"+
			"<p>Además, un cuadro de búsqueda está presente en la esquina superior derecha de cada página del informe. Permite realizar búsquedas de elementos a través de todo el informe. Introduzca un término de búsqueda y presione Entrar. Los resultados se presentan en una lista. La lista contiene todos los elementos que contienen el término de búsqueda. Al hacer clic en un elemento, la página del informe dónde se encuentra el elemento, se presenta. Si la búsqueda no tiene resultados, la lista permanece vacía.</p>",

			"help_search_remove" : "Borrar resultados de búsqueda",
			"help_search_remove_contents" : "<p>Para borrar los resultados de la búsqueda simplemente haz clic en el butón de borrar (<i class=\"fa fa-times\"></i>) al lado del cuadro de búsqueda. Todos los diagramas se vuelven a mostrar de nuevo.</p>",
			
			"name" : "Nombre",
			"zeroRecords":    "No se encontraron resultados",
			"info":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
			"infoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
			"infoFiltered":   "(filtrado de un total de _MAX_ registros)"
	}
	},
	"sv" : {
		translation : {
			"back_button" : "Bakåt",
			"forward_button" : "Framåt",
			"home_button" : "Startsida",
			"all_views_button" : "Diagram",
			"help_button": "Help",
			"properties_message" : "Egenskaper",
			"property_name_message" : "Egenskap",
			"property_value_message" : "Värde",
			"on_screen_guidance_title" : "Skärmvägledning",
			"osg_type" : "Typ",
			"feature_under_development" : "Denna funktion är under utveckling",			
			"osg_feature_under_development_details": "Här hittar du information som hjälper dig att förstå vad objektet betyder, vad objekttypen betyder och vilka koncept som är relevanta i relation till detta objekt.",
			"view" : "Diagram",
			"viewpoint_legend_no_info" : "Det finns ingen förklaring tillgänglig för perspektivet till detta diagram",
			"object_information" : "Detaljer",
			"object_views" : "Visas i",
			"object_relations" : "Relationer",
			"relation_via_message": "Roll",
			"relation_to_message": "Till",
			"filter_inputfield_text": "Söka diagram",
			"filter_clear_text": "Klicka här för att radera söktexten",
			"filter_result": "Resultat",
			"filter_1_diagram" : "diagram",
			"filter_x_diagrams" : "diagram",
			"index-page-section-up": "Överst på sidan",
			"error_title" : "Fel",
			"error_notfound" : "Objektet med id '__id__' hittades ej.",

			"help_general": "Allmänt",
			"help_general_content" : "<p>Välkommen till InSite Lite rapportens hjälpsida. På denna sida finns information om rapportens struktur och hur du skall navigera på rapportens sidor.</p>",
			
			"help_components" : "Komponenter",
			"help_components_contents" : "<p>InSite Lite rapporten består av flera komponenter; en startsida, en översiktssida, en eller flera diagramsidor, en eller flera objektsidor, och den här hjälpsidan.</p>",
			
			"help_startpage" : "Startsida",
			"help_startpage_contents" : "<p>Startsidan (<i class=\"fa fa-home fa-lg fa-fw link-color\"></i>) är startpunkten för rapporten. Den här sidan består av diagrammet som valdes till startdiagram när rapporten skapades. Startsidans innehåll kan därför skilja sig åt för varje rapport. Diagrammet på startsidan visas också på översiktssidan.</p>",

			"help_diagramspage" : "Översiktssida",
			"help_diagramspage_contents" : "<p>Översiktssidan (<i class=\"fa fa-th fa-lg fa-fw link-color\"></i>) ger en överblick av alla modeller och deras diagram som är tillgängliga i rapporten. Menyn visar namnen på alla modeller i alfabetisk ordning. På sidan, är alla diagram grupperade efter modell visas grafiskt.</p> <p>När du klickar på en modell i menyn, hoppar den sidan direkt till modellen och dess diagram på översiktssidan. Genom att klicka på ett diagram kommer du direkt till den motsvarande diagramsidan.</p>",
			
			"help_diagrampage" : "Diagramsida",
			"help_diagrampage_contents" : "<p>Diagramsidan består av den grafiska representationen av en diagrammodell och den för diagrammet relevanta informationen. Du kommer åt diagramsidan genom att klicka på diagrammet på översiktssidan. Du kan också komma åt diagramsidan från andra diagramsidor eller från objektsidor genom att klicka på ett diagram i \"Visas\" i delen av den sidan.</p>"+
			"<p>Genom att klicka på ett objekt i diagrammet navigerar du direkt till den diagram- eller objektsida som är associerad till objektet. Menyn på diagramsidan visar de tillgängliga avsnitten och möjliggör direkt navigering till det avsnittet på diagramsidan.</p>",

			"help_viewpoints" : "Perspektiv",
			"help_viewpoints_contents" : "<p>För varje tillgängligt perspektiv i ett diagram finns en knapp med perspektivets namn synligt för att styra perspektivets tillstånd. Du kan aktivera, fästa eller inaktivera perspektivet med denna knapp.</p>"+
			"<p>InSite Lite stöder följande två perspektivtyper:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-adjust fa-fw\"></i></td>"+
					"<td valign=\"top\"> färgperspektiv</td>"+
				"</tr>"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-tag fa-fw\"></i></td>"+
					"<td valign=\"top\"> etikettperspektiv</td>"+
				"</tr>"+
			"</table></p>"+
			"<p>Ett färgperspektiv ändrar färgschemat i diagrammet, och ett etikettperspektiv lägger till textinformation på objekten i diagrammet. Endast en färgperspektiv och en etikettperspektiv kan vara aktiva samtidigt. Den knappen som styr perspektivet har tre möjliga tillstånd. Varje gång du klickar på knappen, dess tillstånd ändras:</p>"+
			"<p><table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-off\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Perspektivet är inaktiverat och påverkar inte diagrammet.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Perspektivet är aktiverat och har ändrat färgschemat för diagrammet, eller har lagt till textinformation på objektet i diagrammet. En förklaring visas under det specifika diagrammet för det aktiva perspektivet.</td>"+
				"</tr>"+
				
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i><span class=\"btn-viewpoint-on-right-section\"></span><i class=\"fa fa-thumb-tack fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Perspektivet är aktivt och fäst. När du navigerar till en annan diagramsida kommer perspektivet att vara aktivt och automatiskt appliceras på relevanta diagram. Även om ett perspektiv inte är tillgängligt för ett specifikt diagram kommer det att fortsätta vara aktivt. Det kommer däremot i detta fall inte ha någon påverkan på diagrammet.</td>"+
				"</tr>"+
			"</table></p>",
			
			"help_objectpage" : "Objektsida",
			"help_objectpage_contents" : "<p>Objektsidan visar information för ett specifikt objekt. Du kan nå objektsidan från diagramsidan eller från en annan objektsida.</p>"+
			"<p>Objektsidan har samma struktur som diagramsidan; den innehåller information om objektet indelat i flera avsnitt. Objektsidan har inte någon grafisk representation av objektet och har inte heller några perspektivknappar.</p>",
			
			"help_helppage" : "Hjälpsida",
			"help_helppage_contents" : "<p>Hjälpsidan (<i class=\"fa fa-question fa-lg fa-fw link-color\"></i>) är denna sida som du just nu läser.</p>",

			"help_navigation" : "Navigering",
			"help_navigation_contents" : "<p>Du kan navigera i InSite Lite rapporten på olika sätt. Det viktigaste sättet är via navigeringsfältet på toppen av varje sida där du kan kontrollera hur du navigerar genom hela rapporten. För att navigera på en sida finns en menyrad och en pil till höger om rubriken på varje avsnitt (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) tillgängligt på sidan.</p>",

			"help_navbar" : "Navigeringsfält",
			"help_navbar_contents" : "<p>Navigeringsfältet är tillgängligt på alla sidor och innehåller följande kontroller för att navigera i rapporten:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-left fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Gå tillbaka till föregående sida.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-right fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Gå till nästa sida.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-home fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Gå till startsidan för InSite Lite rapporten. Denna sida är startpunkten på rapporten.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-th fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Gå till InSite Lite rapportens översiktssida. Denna sida innehåller alla modeller och deras diagram som är tillgängliga i rapporten.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-question fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Gå till denna hjälpsida.</td>"+
				"</tr>"+
			"</table></p>",

			"help_context_menu" : "Meny",
			"help_context_menu_contents" : "<p>Menyn finns tillgänglig på olika sidor och erbjuder en översikt av tillgängliga avsnitt på sidan. Menyn är placerad till vänster på sidan eller på sidans topp beroende på tillgängligt utrymmer på din skärm eller webbläsare. Innehållet i denna menyn är dynamiskt anpassad för varje sida. Genom att klicka på ett menykommando navigeras du direkt till det avsnittet på sidan.</p>",

			"help_onpage_navigation" : "Navigering på sidan",
			"help_onpage_navigation_contents" : "<p>På sidor med flera avsnitt finns det en pil till höger om varje avsnittsrubrik (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>). När du klickar på pilen så återgår du till sidans top.</p>",

			"help_search" : "Söka",
			"help_search_contents" : "<p>Du kan söka på två platser i rapporten:</p>"+
			"<p>På InSite Lites översiktssida kan du söka efter diagram. Du kan söka efter diagram genom att skriva en sökfråga i sökrutan. Du kan bara söka på (delar av) diagramnamn, inte för namnen på underliggande element som objekt, objektegenskaper, och åsikter. Innehållet på översiktssidan uppdateras med sökresultatet vartefter du skriver. Resultatet är grupperat per modell och endast diagram som matchar dina sökkriterier visas för en modell. Modellerna ordnas i sökresultatet efter flest matchande diagram.</p>"+
			"<p>Dessutom är en sökruta som finns i det övre högra hörnet på varje sida i rapporten. Den låter dig söka efter element genom hela rapporten. Ange ett sökterm och tryck på Enter. Resultaten presenteras i en lista. Listan innehåller alla element som innehåller söktermen. När du klickar på ett element, den sida i rapporten där elementet ligger, presenteras. Om sökningen inte har några resultat, listan förblir tom.</p>",

			"help_search_remove" : "Rensa sökresultat",
			"help_search_remove_contents" : "<p>För att rensa sökresultatet klickar du på ta bort knappen (<i class=\"fa fa-times\"></i>) bredvid sökrutan och då kommer alla diagram att visas igen.</p>",
			
			"name" : "Namn",
			"zeroRecords": "Hittade inga matchande resultat",
			"info": "Visar _START_ till _END_ av totalt _TOTAL_ rader",
			"infoEmpty": "Visar 0 till 0 av totalt 0 rader",
			"infoFiltered": "(filtrerade från totalt _MAX_ rader)"
		}
	},
		"sk" : {
		translation : {
			"back_button" : "Späť",
			"forward_button" : "Vpred",
			"home_button" : "Domov",
			"all_views_button" : "Diagramy",
			"help_button": "Nápoveda",
			"properties_message" : "Vlastnosti",
			"property_name_message" : "Vlastnosť",
			"property_value_message" : "Hodnota",
			"on_screen_guidance_title" : "Nápoveda na obrazovke",
			"osg_type" : "Typ",
			"feature_under_development" : "Táto funkčnosť je vo vývoji",
			"osg_feature_under_development_details": "Tu uvidíte informáciu, ktorá vám pomôže pochopiť význam objektu, význam typu objektu a ktoré koncepty sú relevantné vo vzťahu k tomuto objektu.",
			"view" : "Diagram",
			"viewpoint_legend_no_info" : "Pre tento diagram nie je dostupná legenda pre šablónu pohľadu",
			"object_information" : "Podrobnosti",
			"object_views" : "Nachádza sa na",
			"object_relations" : "Relácie",
			"relation_via_message" : "Rola",
			"relation_to_message" : "Ku",
			"filter_inputfield_text": "Filtrovať diagramy",
			"filter_clear_text": "Stlačiť pre zrušenie filtra",
			"filter_result": "Výsledok",
			"filter_1_diagram" : "diagram",
			"filter_x_diagrams" : "diagramov",
			"index-page-section-up": "Späť na vrch strany",
			"error_title" : "Chyba",
			"error_notfound": "Objekt s id '__id__' nebol nájdený.",

			"help_general": "Všeobecné",
			"help_general_content" : "<p>Vitajte na stránke nápovedy pre InSite Lite report. Na tejto stránke nájdete informácie o štruktúre InSite Lite reportu a o tom ako navigovať jednotlivými stránkami reportu. </p>",

			"help_components" : "Súčasti",
			"help_components_contents" : "<p>InSite Lite report pozostáva z niekoľkých súčastí: domovskej stránky, prehľadu diagramov, jednej alebo viacerých stránok diagramov, jednej alebo viacerých stránok objektov a tejto nápovedy.</p>",

			"help_startpage" : "Domovská stránka",
			"help_startpage_contents" : "<p>Domovská stránka (<i class=\"fa fa-home fa-lg fa-fw link-color\"></i>) je vstupným miestom do reportu. Táto stránka zobrazuje diagram, ktorý bol zvolený ako počiatočný diagram pri vytváraní reportu. Pre každý vytvorený report môže byť zvolený iný diagram na domovskú stránku. Diagram zobrazený na domovskej stránke je zaradený aj medzi diagramami na stránke prehľadu diagramov.</p>",

			"help_diagramspage" : "Stránka prehľadu diagramov",
			"help_diagramspage_contents" : "<p>Stránka prehľadu diagramov (<i class=\"fa fa-th fa-lg fa-fw link-color\"></i>) zobrazuje prehľad všetkých modelov a ich diagramov dostupných vo vytvorenom reporte. V menu sa nachádzajú všetky modely v abecednom poradí. Výberom modelu v menu sa zobrazia všetky diagramy daného modelu na prehľadovej stránke.</p> <p>Po výbere diagramu na prehľadovej stránke sa otvorí konkrétna stránka vybratého diagramu.</p>",

			"help_diagrampage" : "Stránka diagramu",
			"help_diagrampage_contents" : "Stránka diagramu zobrazuje grafickú reprezentáciu diagramu z modelu a informácie relevantné pre tento diagram. Ku stránke diagramu je možné dostať sa zo stránky prehľadu diagramov. Taktiež je možná navigácia z iných stránok diagramov alebo zo stránok objektov výberom niektorého diagramu zo sekcie 'Nachádza sa na'.</p>"+
			"<p>Kliknutím myšou na objekt v diagrame sa navigujete na stránku objektu alebo stránku diagramu prislúchajúcu k objektu na ktorý ste klikli. Menu na stránke diagramu zobrazuje prehľad dostupných sekcií a umožňuje priamu navigáciu k danej sekcii na stránke diagramu.</p>",
				
			"help_viewpoints" : "Šablóny pohľadov",
			"help_viewpoints_contents" : "<p>Pre každú šablónu pohľadu dostupnú ku danému diagramu sa zobrazí prepínateľné tlačítko s menom šablóny pohľadu, pomocou ktorého je možné ovládať jej stav. Stlačením tlačítka môžete šablónu pohľadu zapnúť, zapnúť natrvalo alebo vypnúť.</p>"+
			"<p>InSite Lite podporuje naseldovné dva typy šablón pohľadu:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-adjust fa-fw\"></i></td>"+
					"<td valign=\"top\"> farebná šablóna pohľadu</td>"+
				"</tr>"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-tag fa-fw\"></i></td>"+
					"<td valign=\"top\"> šablóna pohľadu s popiskami</td>"+
				"</tr>"+
			"</table></p>"+
			"<p>Farebná šablóna pohľadu mení farebnú schému použitú v diagrame a šablóna pohľadu s popiskami pridáva textové informácie k objektom diagramu. Iba jedna farebná šablóna pohľadu a jedna šablóna pohľadu s popiskami môže byť aktívna v jednom okamihu. Prepínateľné tlačítko pre šablónu pohľadu má nasledovné tri stavy:</p>"+
			"<p><table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-off\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Šablóna pohľadu je vypnutá a nemá efekt na diagram.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Šablóna pohľadu je zapnutá a mení farebnú schému diagramu alebo pridáva textové informácie k objektom diagramu. Pod diagramom sa zobrazuje legenda špecifická pre aktívnu šablónu.</td>"+
				"</tr>"+
			
				"<tr>"+
					"<td valign=\"top\"><a class=\"btn btn-default btn-viewpoint-on\" style=\"width:65px;margin-right:10px;\"><i class=\"fa fa-adjust fa-fw\"></i><span class=\"btn-viewpoint-on-right-section\"></span><i class=\"fa fa-thumb-tack fa-fw\"></i></a></td>"+
					"<td valign=\"top\">Šablóna pohľadu je zapnutá natrvalo. Pri navigácii na iný diagram ostane šablóna pohľadu zapnutá a je automaticky aplikovaná na ľubovoľný relevantný diagram. Šablóna pohľadu zapnutá natrvalo zostáva aktívna aj keď nie je pre aktívny diagram dostupná, v takom prípade nebude mať na danom diagrame efekt.</td>"+ 
				"</tr>"+
			"</table></p>",

			"help_objectpage" : "Stránka objektu",
			"help_objectpage_contents" : "<p>Stránka objektu zobrazuje informácie pre špecifický objekt. Stránka objektu sa dá zobraziť navigáciou zo stránky diagramu alebo z inej stránky objektu.</p>"+
			"<p>Stránka objektu má rovnakú štruktúru ako stránka diagramu a zobrazuje informácie o objekte vo viacerých sekciách. Stránka objektu neobsahuje grafickú reprezentáciu objektu a ani tlačítka pre šablóny pohľadov.</p>",
				
			"help_helppage" : "Stránka nápovedy",
			"help_helppage_contents" : "<p>Stránka nápovedy (<i class=\"fa fa-question fa-lg fa-fw link-color\"></i>) je táto stránka.</p>",

			"help_navigation" : "Navigácia",
			"help_navigation_contents" : "<p>InSite Lite report umožnuje viacero spôsobov navigácie. Hlavným navigačným prvkom je navigačná lišta na vrchu stránky, ktorá umožňuje navigáciu celým reportom. Pre navigáciu v rámci stránky je dostupné menu. Vpravo od nadpisu každej sekcie je zobrazená šípka nahor (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>) pre navigáciu na vrch stránky.</p>",

			"help_navbar" : "Navigačná lišta",
			"help_navbar_contents" : "<p>Navigačná lišta je zobrazená na vrchu každej stránky a umožňuje nasledovnú navigáciu:"+
			"<table style=\"margin-left:20px;\">"+
				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-left fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Späť na predchádzajúcu zobrazenú stránku.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-chevron-right fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Vpred na stránku.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-home fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Domovská stránka InSite Lite report. Táto stránka je vstupným miestom do reportu.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-th fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Stránka prehľadu diagramov InSite Lite report. Táto stránka zobrazuje prehľad všetkých modelov a ich diagramov dostupných vo vytvorenom reporte.</td>"+
				"</tr>"+

				"<tr>"+
					"<td valign=\"top\"><i class=\"fa fa-question fa-lg fa-fw link-color\" style=\"margin-right:10px;\"></i></td>"+
					"<td valign=\"top\">Stránka nápovedy (táto stránka).</td>"+
				"</tr>"+
			"</table></p>",

			"help_context_menu" : "Menu",
			"help_context_menu_contents" : "<p>Menu sa nachádza na rozličných stránkach a poskytuje prehľad sekcií dostupných na stránke. Menu je zobrazené na stránkach vľavo  alebo hore v závislosti na mieste dostupnom na obrazovke alebo v prehliadači. Obsah menu je dynamicky vytvorený na každej stránke. Kliknutím na položku v menu budete navigovaný na príslušnú sekciu na stránke.</p>",
			
			"help_onpage_navigation" : "Navigácia na stránke",
			"help_onpage_navigation_contents" : "<p>Na stránkach s viacerými sekciami je vpravo od názvu sekcií zobrazená šípka nahor (<i class=\"fa fa-chevron-up fa-lg fa-fw link-color\"></i>). Stlačením šípky sa vrátite na vrch stránky.</p>",
				
			"help_search" : "Vyhľadávanie",
			"help_search_contents" : "<p>Vyhľadávať môžete na dvoch miestach do reportu:</p>"+
			"<p>Stránka prehľadu diagramov v InSite Lite umožňuje vyhľadávanie diagramov. Diagramy môžete vyhľadávať vložením vyhľadávaného textu do políčka filtra diagramov. Vyhľadávať je možné len na základe (častí) mien diagramov. Obsah stránky prehľadu diagramov bude dynamicky upravovaný výsledkami vyhľadávania priebežne ako píšete. Výsledky vyhľadávania su zobrazené v skupinách pre jednotlivé modely a pre každý model sú zobrazené len diagramy zodpovedajúce textu aktívneho filtra. Výsledky sú zoradené podľa modelu a relevancie diagramov.</p>"+
			"<p>Navyše je vyhľadávacie pole zobrazené v pravom hornom rohu každej stránky schémy. To vám umožní vyhľadávať jednotlivé prvky v celým reportom. Zadajte hľadaný výraz a stlačte Enter. Výsledky sú uvedené v zozname. Zoznam obsahuje všetky prvky, ktoré obsahujú hľadaný výraz. Kliknutím na prvok, sa zobrazí strana reportu,na ktorej je prvok umiestnený. V prípade, že vyhľadávanie neposkytuje žiadne výsledky, zoznam zostane prázdny.</p>",

			"help_search_remove" : "Zrušenie vyhľadávania",
			"help_search_remove_contents" : "<p>Pre zrušenie výsledkov vyhľadávania stlačte tlačítko (<i class=\"fa fa-times\"></i>) vedľa poľa filtrovania a opäť sa zobrazia všetky diagramy všetkých modelov.</p>",
			
			"name"	:	"Názov", 
			"zeroRecords":    "Nenašli sa žiadne vyhovujúce záznamy",
			"info":           "Záznamy _START_ až _END_ z celkom _TOTAL_",
			"infoEmpty":      "Záznamy 0 až 0 z celkom 0 ",
			"infoFiltered":   "(vyfiltrované spomedzi _MAX_ záznamov)"		  
		}
	}	
};

(function it_initialize(){
	i18n.init({
		resStore: resources,
		lng: availableLanguages[0].id,
		fallbackLng: 'en',
		useCookie: false
	});
})();
