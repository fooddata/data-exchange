/**
 * @preserve  insite-diagram-view.js
 *  Version 1.0 
 *
 * The MIT License (MIT)
 * 
 * Copyright (c) 2013 BiZZdesign B.V.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

function idv_isFunction(functionToCheck)
{
	var getType = {};
	return functionToCheck && getType.toString.call(functionToCheck) === '[object Function]';
}

var ViewpointsModel = Backbone.Model.extend(
{
	initialize: function() 
	{
		var colourViews = [];
		var labelViews = [];
		var highlightViews = [];
		
		_.each(this.get('viewpoints'), function(viewpoint)
		{
			if (viewpoint.presentationType == 'FmtColourView') 
			{
				colourViews.push(viewpoint);
			}
			else if (viewpoint.presentationType == 'FmtLabelView')
			{
				labelViews.push(viewpoint);
			}
			else if (viewpoint.presentationType == 'FmtHighlightView') 
			{
				highlightViews.push(viewpoint);
			}
		});
		this.set('colourViews', colourViews);
		this.set('labelViews', labelViews);
		this.set('highlightViews', highlightViews);

		//Read the globally stored viewpoints and store them in the state (prevents having to read the global storage too often)
  		var viewpointId = storage.get('colorViewpointPinned');
		if (viewpointId) 
		{
			this.set('activeColorViewpoint', viewpointId);
		}
		viewpointId = storage.get('labelViewpointPinned');
		if (viewpointId) 
		{
			this.set('activeLabelViewpoint', viewpointId);
		}
		viewpointId = storage.get('highlightViewpointPinned');
		if (viewpointId)
		{
			this.set('activeHighlightViewpoint', viewpointId);
		}
	},
	
	getActiveViewpoints: function()
	{
		var activeColourViewId = this.get('activeColorViewpoint');
		var activeLabelViewId = this.get('activeLabelViewpoint');
		var activeHighlightViewId = this.get('activeHighlightViewpoint');

		var active = _.filter(this.get('viewpoints'), function(viewpoint)
		{
			return viewpoint.id == activeColourViewId || viewpoint.id == activeLabelViewId || viewpoint.id == activeHighlightViewId;
		});
		
		return active;
	}
});

var DiagramView = Backbone.View.extend({
    el: $("svg"),


    initialize: function() {
        // Listen for changes for any of the viewpoints
        this.listenTo(this.model, 'change:activeColorViewpoint', this.updateViewpoint);
        this.listenTo(this.model, 'change:activeLabelViewpoint', this.updateViewpoint);
        this.listenTo(this.model, 'change:activeHighlightViewpoint', this.updateViewpoint);
        // Call updateViewpoint for initializing the viewpoints on the view
        this.updateViewpoint();
        // Set the width of the container of the SVG to the width of the SVG.
        // This is where we will add a context menu and we want to prevent wrapping the icons
        // within the context menu.
        $("#main").css("min-width", this.$el.innerWidth());

        // Register for events on the main. So we could detect clicks outside the SVG.
        // This is not yet working... We need to set the height of the main to 100%.
        var viewClickHandler = _.bind(this.viewClick, this);
        $("#main").click(viewClickHandler);
    },


    viewClick: function(event) {

        // Example to get the clicked instance, if we clicked on a use (happens in FireFox):
        // At this moment we don't need to know the clicked element in the instance of the use
        //		if (event.originalEvent) {
        //			var originalTarget = event.originalEvent.originalTarget;
        //		}
        var $clickedObject = $(event.target);

        // If we clicked an instance of a svg-use, then we want to have the use (in Chrome and IE)
        if ($clickedObject.attr('correspondingUseElement')) {
            $clickedObject = $($clickedObject.attr('correspondingUseElement'));
        }

        var $selection = $clickedObject.parents('#selection');
        if ($selection.length > 0) {
            return;
        }

        var bizzsemantic = $clickedObject.attr('bizzsemantic');
        if (!bizzsemantic) {
            $clickedObject = $clickedObject.parents('[bizzsemantic]').first();
        }
        
        // TP-3610: Do not handle a click on a regular HTML hyperlink
        var isHTMLHyperlink = ($clickedObject.context.parentElement != null && $clickedObject.context.parentElement.nodeName != null) ? $clickedObject.context.parentElement.nodeName == "a" : false;

        if ($clickedObject.length > 0 && !isHTMLHyperlink) {
            bizzsemantic = $clickedObject.attr('bizzsemantic');

            // There is at least one parent found. The first one is the closest parent.
            var refObjectId = $clickedObject.attr('bizzid');
            if (refObjectId != null && bizzsemantic != null && viewReferences[refObjectId] == null && objectReferences[refObjectId] == null) {
                // TP-7159: we assume that when 'bizzid' and 'bizzsemantic' are both set, and 'bizzid' is not in any of the
                // reference/referred mappings, this means that this is not a reference object, and 'bizzid' is not for us:
                refObjectId = null;
            }
            if (refObjectId) {
                // Check if we clicked on a collapsed object equal to the current view, so in fact we clicked on ourself
                var clickedOnSelf = viewData.id == refObjectId;

                // Check if the selected object has a viewLink. If so, navigate to this view.
                var viewLink = this.getViewLink(refObjectId);
                if (!clickedOnSelf && viewLink) {
                    window.location.href = viewLink;
                }
                else {
                    // Only the objectReferences are valid objects for the object page.
                    // Other objects on the view are only graphical objects.
                    var referredId = objectReferences[refObjectId];
                    if (referredId != null) {
                        // We clicked a ref object, the referred object is used for the object.html page
                        // Go to the object.html page directly
                        var dataFile = objectDataMapping[referredId];
                        if (dataFile) {
                            window.location.href = InsiteUtils.createUrl("object_" + dataFile + ".html?object=" + referredId);
                        }
                    }
                }
            }
            else {
                // Check if the bizzsemantic is a view. 
                if (this.isView(bizzsemantic)) {
                    window.location.href = InsiteUtils.createUrl("views/view_" + bizzsemantic + ".html");
                }
                // If not an actual view, maybe it is a collapsed reference (and then we should open its detail diagram)
                else if (this.hasDiagram(bizzsemantic)) {
                    window.location.href = InsiteUtils.createUrl("views/view_" + bizzsemantic + ".html");
                }
                else {
                    var dataFile = objectDataMapping[bizzsemantic];
                    if (dataFile) {
                        window.location.href = InsiteUtils.createUrl("object_" + dataFile + ".html?object=" + bizzsemantic);
                    }
                }
            }
        }
    },

    isView: function(semanticId) {
        // Find this id within the views within insite_models.
        // The outer 'find' returns the model containing the view with semanticId
        var modelContainingView = _.find(insite_models, function(model) {
            return _.find(model.views, function(view) {
            return view.id == semanticId;
            });
        });
        return modelContainingView !== undefined;
    },

    hasDiagram: function(semanticId) {
        return insiteViews[semanticId] !== undefined;
    },

    getViewLink: function(objectId) {
        if (viewReferences[objectId]) {
            return InsiteUtils.createUrl("views/view_" + viewReferences[objectId] + ".html");
        }
        else {
            return null;
        }
    },

    updateViewpoint: function() {

        // The viewpoints are made visible by setting the viewpointId as a class
        // The viewpoints are predefined in CSS under this classname.

        // Remove all existing viewpoints by removing the class
        this.$el.removeAttr('class');

        // Collect all viewpointIds that are active
        var viewpointIds = [];
        _.each(this.model.getActiveViewpoints(), function(viewpoint) {
            viewpointIds.push(viewpoint.id);
        });

        if (viewpointIds.length > 0) {
            // Set the viewpointIds separated with a space
            this.$el.attr('class', viewpointIds.join(' '));
        }
    }

});


var ViewpointsView = Backbone.Marionette.ItemView.extend(
{
	template: Handlebars.compile($("#viewpointsTemplate").html()),
	events	: 
	{
		"click .viewpointButton" 		: "viewpointButtonClicked"
	},
	
	localViewIds :
	{
		color		: 'none', 
		label		: 'none', 
		highlight	: 'none'
	},
	
	applyActiveViewpoints: function()
	{
		var activeColorViewpoint = this.model.get('activeColorViewpoint');
		var activeLabelViewpoint = this.model.get('activeLabelViewpoint');
		var activeHighlightViewpoint = this.model.get('activeHighlightViewpoint');
		if(activeColorViewpoint)
		{
			this.processSelectedViewpoint(activeColorViewpoint, 'color', true);
		}
		if(activeLabelViewpoint)
		{
			this.processSelectedViewpoint(activeLabelViewpoint, 'label', true);
		}
		if(activeHighlightViewpoint)
		{
			this.processSelectedViewpoint(activeHighlightViewpoint, 'highlight', true);
		}
	},

	viewpointButtonClicked: function(e)
	{
		var viewpointId = e.currentTarget.getAttribute("viewpointId");
		var viewpointType = e.currentTarget.getAttribute("viewpointType");

		this.processSelectedViewpoint(viewpointId, viewpointType, false);
        //The event has been processed, prevent the default actions from being performed for this click event
	  	e.preventDefault();
	},
	
	VIEWPOINT_STATE : 
	{
        OFF : {value: 0, name: "Off"}, 
        ON: {value: 1, name: "On"}, 
        PINNED : {value: 2, name: "Pinned"}
    },

	getViewpointState: function(viewpointId, viewpointType)
    {
        var state = state = this.VIEWPOINT_STATE.OFF;
        if(this.localViewIds[viewpointType] == viewpointId)
        {
            state = this.VIEWPOINT_STATE.ON;
			var currentViewpointIdPinned = storage.get(viewpointType+'ViewpointPinned');
			if(typeof currentViewpointIdPinned != 'undefined')
			{
				if(currentViewpointIdPinned == viewpointId)
				{
					state = this.VIEWPOINT_STATE.PINNED;            
				}
		   }
		}
		return state;
	},

	activateViewpoint: function(viewpointId, viewpointType)
	{
		//disable the currently selected viewpoint, if any
		if(this.localViewIds[viewpointType] != 'none' && this.localViewIds[viewpointType] != viewpointId)
		{
			this.deactivateViewpoint(this.localViewIds[viewpointType], viewpointType);
		}
		var viewpointButton = $(".viewpointButton[viewpointId='"+viewpointId+"']");
		$(viewpointButton).toggleClass('btn-viewpoint-off');
		$(viewpointButton).toggleClass('btn-viewpoint-on');
		this.localViewIds[viewpointType] = viewpointId;
		if(viewpointType == 'color')
		{
			this.model.set('activeColorViewpoint', viewpointId);
		} else if(viewpointType == 'label')
		{
			this.model.set('activeLabelViewpoint', viewpointId);
		} else if(viewpointType == 'highlight')
		{
			this.model.set('activeHighlightViewpoint', viewpointId);
		}
		if(this.hasLegendData(viewpointId))
		{
			var currentViewpointLegend = $(".viewpointLegend[viewpointId='"+viewpointId+"']");
			$("#"+viewpointId+"LegendContent") .html(this.buildLegendHtml(viewpointId, viewpointType));
			$(currentViewpointLegend).toggle();
			$('#'+viewpointType+'ViewpointLegendFiller').toggle();
		}
	},

	pinViewpoint: function(viewpointId, viewpointType)
	{
		var viewpointButton = $(".viewpointButton[viewpointId='"+viewpointId+"']");
		$(viewpointButton).append(' <span class="btn-viewpoint-on-right-section"></span><i class="fa fa-thumb-tack fa-fw"></i>');
		storage.set(viewpointType+'ViewpointPinned', viewpointId);
	},

	deactivateViewpoint: function(viewpointId, viewpointType)
	{
		var viewpointButton = $(".viewpointButton[viewpointId='"+viewpointId+"']");
		$(viewpointButton).toggleClass('btn-viewpoint-on');
		$(viewpointButton).toggleClass('btn-viewpoint-off');
		this.localViewIds[viewpointType] = 'none';
		if(viewpointType == 'color')
		{
			$(viewpointButton).html('<i class="fa fa-adjust fa-fw"></i>');
			this.model.unset('activeColorViewpoint');
		} else if(viewpointType == 'label')
		{
			$(viewpointButton).html('<i class="fa fa-tag fa-fw"></i>');
			this.model.unset('activeLabelViewpoint');
		} else if(viewpointType == 'highlight')
		{
			$(viewpointButton).html('<i class="fa fa-lightbulb-o fa-fw"></i>');
			this.model.unset('activeHighlightViewpoint');
		}
		storage.set(viewpointType+'ViewpointPinned', '');
		
		if(this.hasLegendData(viewpointId))
		{
			var currentViewpointLegend = $(".viewpointLegend[viewpointId='"+viewpointId+"']");
			$(currentViewpointLegend).toggle();
			$('#'+viewpointType+'ViewpointLegendFiller').toggle();
		}
	},
    
	processSelectedViewpoint: function(viewpointId, viewpointType, init)
	{
		var showLegend = (viewpointType == 'label' || viewpointType == 'color') && this.hasLegendData(viewpointId);
		
		var viewpointState = this.getViewpointState(viewpointId, viewpointType);
		if(viewpointState.value == this.VIEWPOINT_STATE.OFF.value)
		{
			this.activateViewpoint(viewpointId, viewpointType);
			if(init)
		    {
		        this.pinViewpoint(viewpointId, viewpointType);
		    }
		} else if(viewpointState.value == this.VIEWPOINT_STATE.ON.value)
		{
			this.pinViewpoint(viewpointId, viewpointType);
		} else if(viewpointState.value == this.VIEWPOINT_STATE.PINNED.value)
		{    
			this.deactivateViewpoint(viewpointId, viewpointType);
		}
	},
	
	hasLegendData : function(viewpointId)
	{
		return  typeof vp_legends !== 'undefined' && typeof vp_legends[viewpointId] !== 'undefined';
	},
	
	buildLegendHtml: function(viewpointId, viewpointType)
	{
		var html = "";
		if(this.hasLegendData(viewpointId))
		{
			if(vp_legends[viewpointId].labels.length > 0)
			{	
				for(var i = 0; i < vp_legends[viewpointId].labels.length; i++)
				{
					if(vp_legends[viewpointId].labels.length > 1)
					{
						html += vp_legends[viewpointId].labels[i];
					}
					if(vp_legends[viewpointId].content[i].length > 0)
					{				
						for(var j = 0; j < vp_legends[viewpointId].content[i].length; j++)
						{
							if(viewpointType == 'color')
							{
								html += "<i class='fa fa-square' style='margin-left:5px;margin-right:1px;color:rgb("+
										vp_legends[viewpointId].content[i][j].value1+");'></i>"+
										vp_legends[viewpointId].content[i][j].value2;
							} else if(viewpointType == 'label')
							{
								html += "<b>"+vp_legends[viewpointId].content[i][j].value1+"</b> "+
										vp_legends[viewpointId].content[i][j].value2+" ";
							}
							
						}
					} else
					{
						html += i18n.t('viewpoint_legend_no_info');
					}
				}
			}
			else
			{
				html += i18n.t('viewpoint_legend_no_info');
			}
		}

		return html;
	}
});

//Initialize if the page is loaded
InSite.addInitializer(function(insiteState){

    var viewpointsModel = new ViewpointsModel({viewpoints : viewpointsData});

	// Attach the already rendered diagram view to the main region. 
	var diagramView = new DiagramView({model:viewpointsModel});
	InSite.main.attachView(diagramView);
	InSite.main.ensureEl();
	InSite.main.$el.css('visibility','inherit');
	//the following ensures the svg is always horizontally centered on the page.
	diagramView.$el.attr('style', 'margin-left:auto;margin-right:auto;display:block;');

	//Show the viewpoints
	var viewpointsView = new ViewpointsView({ model: viewpointsModel });
	InSite.viewpoints.show(viewpointsView);
	viewpointsView.applyActiveViewpoints();
});
