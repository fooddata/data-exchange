/**
 * @preserve  insite.js
 *  Version 1.0
 *
 * The MIT License (MIT)
 * 
 * Copyright (c) 2013 BiZZdesign B.V.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

var orgValue = null;

function brandMouseOver(newText)
{
	orgValue = document.getElementById("navbar-location").innerHTML;
	document.getElementById("navbar-location").innerHTML=i18n.t(newText);
}
function brandMouseOut()
{
	document.getElementById("navbar-location").innerHTML=orgValue;
}

function componentToHex(c) {
    var hex = c.toString(16);
    return hex.length == 1 ? "0" + hex : hex;
}

// InSiteState contains for example the available languages.
var InSiteState = Backbone.Model.extend({
});

// Create the application and create regions for showing the views.
// Currently only the header is managed through a region.
var InSite = new Backbone.Marionette.Application();
var storage = new Persist.Store('InSite');

InSite.addRegions(
{
	header	: '#header',
	main		: '#main',
	viewpoints	: '#viewpointsTarget',
	objectDetails	: '#objectDetails'
});

// Initialize if the page is loaded
InSite.addInitializer(function(insiteState) {
    // Register the translation library as a helper in Handlebars, so we can translate within the templates.
    Handlebars.registerHelper('t', function(i18n_key) {
        var result = i18n.t(i18n_key);
        return new Handlebars.SafeString(result);
    });

    if (FastClick) {
        $(function() {
            FastClick.attach(document.body);
        });
    }
});

function InsiteUtils() {}

InsiteUtils.getUrlToInsiteRoot = function() {
    if (typeof insiteRootUrl == 'undefined') {
        return "";
    }
    else {
        return insiteRootUrl;
    }
}

InsiteUtils.createUrl = function(urlFromRoot) {
	if (typeof insiteRootUrl == 'undefined') {
		return urlFromRoot;
	}
	else {
		return insiteRootUrl + urlFromRoot;
	}
};

InsiteUtils.language = availableLanguages[0].id;

InsiteUtils.getLanguageData = function(objectId) {
    var selectedObjectData = objectData[objectId];
    if (selectedObjectData) {
        return _.find(selectedObjectData.data, function(data) { return data.lang == InsiteUtils.language; });
    }
    return null;
};

InsiteUtils.hasInfo = function(objectId) {
    var languageData = InsiteUtils.getLanguageData(objectId);
    var hasInfo = languageData && languageData.categories && Object.keys(languageData.categories).length > 0;
    return hasInfo;
};

InsiteUtils.hasRelations = function(objectId) {
    var relationsData = objectRelations[objectId];
    var hasRelations = relationsData && relationsData.length > 0;
    return hasRelations;
};

InsiteUtils.hasViews = function(objectId) {
    var views = objectsOnViews[objectId];
    var hasViews = views && views.length > 0;
    return hasViews;
};

InsiteUtils.getSectionsForObject = function(objectId, isView) {
    var sections = new Array();

    if (isView) {
        var section = new Array();
        section.id = "diagram";
        section.title = i18n.t('view');

        sections.push(section);
    }
    var languageData = InsiteUtils.getLanguageData(objectId);
    // Return the following only if we know about the object (the languageData must exist)
    if (languageData) {
        if (languageData.categories) {
            for (var i in languageData.categories) {
                var category = languageData.categories[i];

                var section = new Array();
                section.id = "section" + i;
                if(category.title.localeCompare("__is_translate_properties_title__") == 0)
                {
                    var translatedTitle = i18n.t('properties_message');
                    section.title = translatedTitle.charAt(0).toUpperCase() + translatedTitle.substr(1);
                } else
                {
                    section.title = category.title.charAt(0).toUpperCase() + category.title.substr(1);
                }
                sections.push(section);
            }
        }
        var relationsData = objectRelations[objectId];
        var views = objectsOnViews[objectId];
        if (views && views.length > 0) {
            var section = new Array();
            section.id = "relatedViews";
            section.title = i18n.t('object_views');
            sections.push(section);
        }
        if (relationsData && relationsData.length > 0) {
            var section = new Array();
            section.id = "object_relations";
            section.title = i18n.t('object_relations');
            sections.push(section);
        }
    }
    return sections;
}
