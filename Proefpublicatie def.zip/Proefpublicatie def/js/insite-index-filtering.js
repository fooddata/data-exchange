/**
 * @preserve  insite-index-filtering.js
 *  Version 1.0
 * 
 * The MIT License (MIT)
 * 
 * Copyright (c) 2013 BiZZdesign B.V.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

function clearSearch()
{
	/* reset the inputfield value */
	$("#search").val('');

	/* Filter views based on an empty filter string, this ensures a uniform way of updating relevant html aspects */
	filterViews("");

	/* reset the scroll positions back to default */
	$(window).scrollTop(0);
	$(window).scrollLeft(0);
}

/* Filter as text is entered */
$("#search").on("keyup", function() 
{
	var filterString = this.value;
	filterViews(filterString);
	/* reset the scroll positions back to default */
	$(window).scrollTop(0);
	$(window).scrollLeft(0);
});

function filterViews(filterString)
{
	/* if text has been entered, we must display the remove icon button. The no text remains then hide the remove button again */
	if(filterString.length > 0)
	{
		$(".search-remove-icon-sidebar").css("display", "inline");
	} else
	{
		$(".search-remove-icon-sidebar").css("display", "none");
	}

	var shownViewsCumulative = 0;
	var totalViewsCumulative = 0;
	/* Now do the actual filtering. This is simple filering for now */
	$(".model-searchable").each(function()
	{
		var totalViews = 0;
		var shownViews = 0;

		$(this).find(".view-searchable").each(function() 
		{
			totalViews = totalViews + 1;
			var $this = $(this);
			var viewName = $(this).text().toLowerCase();
			if(viewName.indexOf(filterString.toLowerCase()) != -1)
			{
				shownViews = shownViews + 1;
				/*the filterString is contained, so show the view */
				$this.toggle(true);					
			}
			else
			{
				/*the filterString is not contained, so hide the view */
				$this.toggle(false);	
			}
		});
		if(filterString.length > 0)
		{
			if(shownViews == 1)
			{
				/* span is needed for sorting later on */
				$(this).find("h2 > small").html("("+i18n.t('filter_result')+": <span>"+shownViews+"</span> "+i18n.t('filter_1_diagram')+")");
			} else
			{
				/* span is needed for sorting later on */
				$(this).find("h2 > small").html("("+i18n.t('filter_result')+": <span>"+shownViews+"</span> "+i18n.t('filter_x_diagrams')+")");
			}
		} else
		{
			if(shownViews == 1)
			{
				$(this).find("h2 > small").html("("+shownViews+" "+i18n.t('filter_1_diagram')+")");
			} else
			{
				$(this).find("h2 > small").html("("+shownViews+" "+i18n.t('filter_x_diagrams')+")");
			}
		}
		shownViewsCumulative = shownViewsCumulative + shownViews;
		totalViewsCumulative = totalViewsCumulative + totalViews;
	});

	/* now sort the sections according to the filter results */
	var list = $('.all-models');
	var listItems = list.find('.model-searchable').sort(function(a,b)
	{ 

		if(shownViewsCumulative == totalViewsCumulative)
		{
			/* Alphabetical sorting based on model name as nothing was filtered away */
			return $(a).find("h2").text().toUpperCase().localeCompare($(b).find("h2").text().toUpperCase());
		} else
		{
			/* Some matches, sort based on model with most matched views first, highest number has priority so sort from 10, 9, 8, not 8, 9, 10 */
			var aVal = parseInt($(a).find("h2 > small > span").text(), 10);
			var bVal = parseInt($(b).find("h2 > small > span").text(), 10);
			if(aVal < bVal)
			{
				return 1;
			} else if(aVal > bVal)
			{
				return -1;
			} else
			{
				/* same number of shown views, so sort alphabetically based on the model name again */
				return $(a).find("h2").text().toUpperCase().localeCompare($(b).find("h2").text().toUpperCase());
			}

		}
	});
	list.find('.model-searchable').remove();
	list.append(listItems);	
}

function sortDiagrams()
{
	
	var list = $('.all-models');
	var listItems = list.find('.model-searchable')
	for (var i = 0; i < listItems.length; i++) 
	{
		var sortedItems = $(listItems[i]).find('.diagram-preview').sort(function(a,b)
		{ 
			/* Alphabetical sorting based on model name as nothing was filtered away */
			return $(a).find(".diagram-title").text().toUpperCase().localeCompare($(b).find(".diagram-title").text().toUpperCase());
		});
		$(listItems[i]).find('.diagram-preview').remove();
		$(listItems[i]).find('.row').append(sortedItems);	
	}
}
