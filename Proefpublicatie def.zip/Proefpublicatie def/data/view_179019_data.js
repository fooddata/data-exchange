var viewData = {"id":179019,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179019" : {
"id":179019,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"iWvGGZ-rollen",
"type":"Resources",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182257" : 182258
,
"182255" : 182256
,
"182259" : 182260
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
