var viewData = {"id":104121,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"104121" : {
"id":104121,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_BeperkingVraag",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184143" : 184144
,
"184161" : 184162
,
"184141" : 184142
,
"184147" : 184148
,
"184151" : 184152
,
"184138" : 184139
,
"184153" : 184154
,
"184149" : 184150
,
"184155" : 184156
,
"184157" : 184158
,
"184159" : 184160
,
"184163" : 184164
,
"184165" : 184166
,
"184145" : 184146
,
"184134" : 184135
,
"184136" : 184137
,
"184173" : 184174
,
"184193" : 184194
,
"184169" : 184170
,
"184209" : 184210
,
"184189" : 184190
,
"184211" : 184212
,
"184201" : 184202
,
"184215" : 184216
,
"184175" : 184176
,
"184221" : 184222
,
"184179" : 184180
,
"184177" : 184178
,
"184219" : 184220
,
"184199" : 184200
,
"184213" : 184214
,
"184217" : 184218
,
"184191" : 184192
,
"184223" : 184224
,
"184183" : 184184
,
"184185" : 184186
,
"184195" : 184196
,
"184197" : 184198
,
"184167" : 184168
,
"184203" : 184204
,
"184187" : 184188
,
"184205" : 184206
,
"184207" : 184208
,
"184171" : 184172
,
"184181" : 184182
,
"184227" : 184228
,
"184247" : 184248
,
"184261" : 184262
,
"184243" : 184244
,
"184229" : 184230
,
"184233" : 184234
,
"184231" : 184232
,
"184267" : 184268
,
"184257" : 184258
,
"184265" : 184266
,
"184245" : 184246
,
"184251" : 184252
,
"184237" : 184238
,
"184239" : 184240
,
"184255" : 184256
,
"184263" : 184264
,
"184249" : 184250
,
"184253" : 184254
,
"184241" : 184242
,
"184259" : 184260
,
"184225" : 184226
,
"184235" : 184236
,
"184140" : 178595
,
"184270" : 184271
,
"184269" : 103405
};
var viewpointsData = 
[
{"id":"viewpoint189139","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
,{"id":"viewpoint189133","name":"Datatype details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint189139": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint189133": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint189139.labels[0] = "Labelview";
vp_legends.viewpoint189139.content[0] = new Array();
vp_legends.viewpoint189139.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
vp_legends.viewpoint189133.labels[0] = "Labelview";
vp_legends.viewpoint189133.content[0] = new Array();
vp_legends.viewpoint189133.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
