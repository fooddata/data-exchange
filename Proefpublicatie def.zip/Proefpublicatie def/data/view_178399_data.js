var viewData = {"id":178399,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178399" : {
"id":178399,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Zorgaanbieder",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184974" : 184973
,
"184986" : 184985
,
"185022" : 184325
,
"185000" : 184316
,
"185006" : 184318
,
"185010" : 184319
,
"184990" : 184326
,
"185008" : 184317
,
"184994" : 184314
,
"184992" : 184320
,
"185002" : 184328
,
"184996" : 184315
,
"185012" : 184327
,
"184978" : 184322
,
"185016" : 184323
,
"185018" : 184321
,
"184998" : 184324
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
