var viewData = {"id":66932,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"66932" : {
"id":66932,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"Opbouw berichten",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
