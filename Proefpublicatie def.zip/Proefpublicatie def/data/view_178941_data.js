var viewData = {"id":178941,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178941" : {
"id":178941,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Aanvrager",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183722" : 183721
,
"183726" : 183725
,
"183734" : 183733
,
"183742" : 183741
,
"183731" : 183730
,
"183747" : 180592
,
"183753" : 183752
,
"183736" : 180597
,
"183745" : 183744
,
"183739" : 183738
,
"183750" : 183749
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
