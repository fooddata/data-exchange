var viewData = {"id":179016,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179016" : {
"id":179016,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182225" : 179890
,
"182226" : 179903
,
"182227" : 179902
,
"182228" : 179881
,
"182229" : 179894
,
"182240" : 179897
,
"182232" : 179893
,
"182243" : 179892
,
"182248" : 179885
,
"182246" : 179899
,
"182230" : 179898
,
"182245" : 179883
,
"182242" : 179901
,
"182238" : 179896
,
"182237" : 179895
,
"182244" : 179887
,
"182234" : 179889
,
"182233" : 179900
,
"182231" : 179904
,
"182235" : 179884
,
"182247" : 179905
,
"182236" : 179882
,
"182241" : 179891
,
"182249" : 179886
,
"182239" : 179888
,
"189709" : 189709
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
