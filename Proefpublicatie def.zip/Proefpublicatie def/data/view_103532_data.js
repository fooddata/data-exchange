var viewData = {"id":103532,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"103532" : {
"id":103532,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_Naam",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183976" : 103376
,
"183977" : 178595
,
"183978" : 183979
,
"190662" : 190662
,
"190665" : 190665
};
var viewpointsData = 
[
{"id":"viewpoint189139","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
,{"id":"viewpoint189133","name":"Datatype details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint189139": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint189133": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint189139.labels[0] = "Labelview";
vp_legends.viewpoint189139.content[0] = new Array();
vp_legends.viewpoint189139.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
vp_legends.viewpoint189133.labels[0] = "Labelview";
vp_legends.viewpoint189133.content[0] = new Array();
vp_legends.viewpoint189133.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
