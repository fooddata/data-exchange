var viewData = {"id":179144,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179144" : {
"id":179144,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_BerichtType",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183012" : 183013
,
"182989" : 182990
,
"183011" : 107952
,
"183009" : 183010
,
"183005" : 183006
,
"183020" : 183021
,
"183016" : 183017
,
"183001" : 183002
,
"182993" : 182994
,
"182999" : 183000
,
"182996" : 182997
,
"183018" : 183019
,
"183022" : 183023
,
"182991" : 182992
,
"183024" : 183025
,
"183014" : 183015
,
"183026" : 183027
,
"183003" : 183004
,
"183007" : 183008
,
"182998" : 178595
,
"182995" : 178577
};
var viewpointsData = 
[
{"id":"viewpoint189139","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
,{"id":"viewpoint189133","name":"Datatype details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint189139": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint189133": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint189139.labels[0] = "Labelview";
vp_legends.viewpoint189139.content[0] = new Array();
vp_legends.viewpoint189139.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
vp_legends.viewpoint189133.labels[0] = "Labelview";
vp_legends.viewpoint189133.content[0] = new Array();
vp_legends.viewpoint189133.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
