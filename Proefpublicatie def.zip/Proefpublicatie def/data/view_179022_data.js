var viewData = {"id":179022,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179022" : {
"id":179022,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Zorgaanbieder",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185146" : 185145
,
"185142" : 185141
,
"185156" : 185155
,
"185135" : 185134
,
"185153" : 185152
,
"185150" : 185149
,
"185139" : 185138
,
"185159" : 185158
,
"185168" : 185167
,
"185172" : 185171
,
"185181" : 185180
,
"185162" : 185161
,
"185165" : 185164
,
"185175" : 185174
,
"185178" : 185177
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
