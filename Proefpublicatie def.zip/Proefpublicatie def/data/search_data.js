var searchData = {
"179804" : {
"id":179804,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179807" : {
"id":179807,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179799" : {
"id":179799,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aavraag ZM ontvangen",
"type":"Intermediate event"
}
]
}
,
"179839" : {
"id":179839,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179801" : {
"id":179801,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"179810" : {
"id":179810,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179813" : {
"id":179813,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"179816" : {
"id":179816,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179835" : {
"id":179835,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179831" : {
"id":179831,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179838" : {
"id":179838,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanwijzen GD",
"type":"Task"
}
]
}
,
"179841" : {
"id":179841,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179832" : {
"id":179832,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht bevindingen GD",
"type":"Task"
}
]
}
,
"179847" : {
"id":179847,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht beslissing tav  indienen verzoekschrift ontvangen",
"type":"Intermediate event"
}
]
}
,
"179851" : {
"id":179851,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179853" : {
"id":179853,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht MV  niet valide",
"type":"End event"
}
]
}
,
"179849" : {
"id":179849,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179855" : {
"id":179855,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht  MV",
"type":"Task"
}
]
}
,
"179846" : {
"id":179846,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179856" : {
"id":179856,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179859" : {
"id":179859,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179854" : {
"id":179854,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179820" : {
"id":179820,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"179860" : {
"id":179860,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanlevering gegevens verplichte zorg is gestart",
"type":"Start event"
}
]
}
,
"179798" : {
"id":179798,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179861" : {
"id":179861,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Aanlevering verplichte zorg opstellen",
"type":"Task"
}
]
}
,
"179862" : {
"id":179862,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179802" : {
"id":179802,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht MV valide?",
"type":"Gateway"
}
]
}
,
"179845" : {
"id":179845,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht MV",
"type":"Task"
}
]
}
,
"179868" : {
"id":179868,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"179827" : {
"id":179827,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht melding  indienen verzoekschrift  ontvangen",
"type":"Intermediate event"
}
]
}
,
"179829" : {
"id":179829,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179808" : {
"id":179808,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"179811" : {
"id":179811,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht bevindingen GD",
"type":"Task"
}
]
}
,
"179833" : {
"id":179833,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"179800" : {
"id":179800,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"179819" : {
"id":179819,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179830" : {
"id":179830,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179805" : {
"id":179805,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"179836" : {
"id":179836,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"179824" : {
"id":179824,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179823" : {
"id":179823,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM niet valide",
"type":"End event"
}
]
}
,
"179817" : {
"id":179817,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179809" : {
"id":179809,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanvraag ZM valide?",
"type":"Gateway"
}
]
}
,
"179825" : {
"id":179825,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht bevindingen GD valide?",
"type":"Gateway"
}
]
}
,
"179826" : {
"id":179826,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179834" : {
"id":179834,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD niet valide",
"type":"End event"
}
]
}
,
"179815" : {
"id":179815,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179837" : {
"id":179837,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179840" : {
"id":179840,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"179842" : {
"id":179842,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179822" : {
"id":179822,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"179843" : {
"id":179843,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179844" : {
"id":179844,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht MV ontvangen",
"type":"Intermediate event"
}
]
}
,
"179814" : {
"id":179814,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"179803" : {
"id":179803,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beslissen over voorbereiding ZM",
"type":"Task"
}
]
}
,
"179828" : {
"id":179828,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht melding indienen verzoekschrift",
"type":"Task"
}
]
}
,
"179848" : {
"id":179848,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"179850" : {
"id":179850,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren  bericht MV",
"type":"Task"
}
]
}
,
"179852" : {
"id":179852,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"179806" : {
"id":179806,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"179812" : {
"id":179812,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht  bevindingen GD",
"type":"Task"
}
]
}
,
"179818" : {
"id":179818,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht aanvraag ZM",
"type":"Task"
}
]
}
,
"179821" : {
"id":179821,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanvraag ZM in behandeling nemen",
"type":"Task"
}
]
}
,
"179877" : {
"id":179877,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179909" : {
"id":179909,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179913" : {
"id":179913,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179869" : {
"id":179869,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces persoonsgegevens betrokkene verstrekken",
"type":"Collaboration diagram"
}
]
}
,
"179899" : {
"id":179899,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding beeindigd",
"type":"End event"
}
]
}
,
"179894" : {
"id":179894,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"179893" : {
"id":179893,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179896" : {
"id":179896,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179911" : {
"id":179911,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179871" : {
"id":179871,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Verstrekken  persoonsgegevens betrokkene is gestart",
"type":"Start event"
}
]
}
,
"179883" : {
"id":179883,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Choreography task"
}
]
}
,
"179885" : {
"id":179885,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beoordelen",
"type":"Choreography task"
}
]
}
,
"179926" : {
"id":179926,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"179912" : {
"id":179912,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179898" : {
"id":179898,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179915" : {
"id":179915,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179914" : {
"id":179914,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179919" : {
"id":179919,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"179895" : {
"id":179895,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Voorbereiding starten",
"type":"Choreography task"
}
]
}
,
"179863" : {
"id":179863,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht Aanlevering verplichte zorg is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"179904" : {
"id":179904,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Verzoekschrift ingediend",
"type":"End event"
}
]
}
,
"179881" : {
"id":179881,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179908" : {
"id":179908,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179901" : {
"id":179901,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"179930" : {
"id":179930,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"179900" : {
"id":179900,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179903" : {
"id":179903,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179864" : {
"id":179864,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Aanlevering verplichte zorg verzenden",
"type":"Task"
}
]
}
,
"179882" : {
"id":179882,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"179879" : {
"id":179879,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene ontvangen",
"type":"End event"
}
]
}
,
"179884" : {
"id":179884,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179889" : {
"id":179889,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179897" : {
"id":179897,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"179902" : {
"id":179902,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179906" : {
"id":179906,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"179890" : {
"id":179890,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beslissen",
"type":"Choreography task"
}
]
}
,
"179907" : {
"id":179907,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Pool"
}
]
}
,
"179916" : {
"id":179916,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179910" : {
"id":179910,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179905" : {
"id":179905,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"179917" : {
"id":179917,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179865" : {
"id":179865,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179875" : {
"id":179875,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179887" : {
"id":179887,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"179888" : {
"id":179888,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanvragen",
"type":"Choreography task"
}
]
}
,
"179891" : {
"id":179891,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179886" : {
"id":179886,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179892" : {
"id":179892,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Aanvraag afgewezen",
"type":"End event"
}
]
}
,
"179873" : {
"id":179873,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Verstrekken",
"type":"Choreography task"
}
]
}
,
"179988" : {
"id":179988,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanvraag ZM",
"type":"Message"
}
]
}
,
"179959" : {
"id":179959,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"179962" : {
"id":179962,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"179963" : {
"id":179963,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"179937" : {
"id":179937,
"typeIconPath":"data/icons/ArchiMate/CompositeGrouping.png",
"data" : [
{
"name":"iPgb",
"type":"Groepering"
}
]
}
,
"179955" : {
"id":179955,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP079: Het is verplicht om gebruik te maken van het BSN van de client in de onderlinge uitwisseling van gegevens.",
"type":"Requirement"
}
]
}
,
"179958" : {
"id":179958,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP080: Aan het tijdstip waarop en de volgorde waarin berichten worden ontvangen en verwerkt kunnen ketenpartijen geen betekenis hechten.",
"type":"Requirement"
}
]
}
,
"179952" : {
"id":179952,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP095: Een bericht mag niet worden afgekeurd op basis van informatie waartoe de verzendende partij geen toegang heeft.",
"type":"Requirement"
}
]
}
,
"179968" : {
"id":179968,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"179951" : {
"id":179951,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"179977" : {
"id":179977,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Pool"
}
]
}
,
"179979" : {
"id":179979,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"179983" : {
"id":179983,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht MV is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"179985" : {
"id":179985,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179960" : {
"id":179960,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP252: Bij een (deels) onbekende geboortedatum moet aangegeven worden welk deel van de geboortedatum betrouwbaar is.",
"type":"Requirement"
}
]
}
,
"179990" : {
"id":179990,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD verzenden",
"type":"Task"
}
]
}
,
"179933" : {
"id":179933,
"typeIconPath":"data/icons/ArchiMate/CompositeGrouping.png",
"data" : [
{
"name":"iWmo en iJw",
"type":"Groepering"
}
]
}
,
"179994" : {
"id":179994,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht bevindingen GD verzenden",
"type":"Task"
}
]
}
,
"179989" : {
"id":179989,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179995" : {
"id":179995,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht bevindingen GD  is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"179996" : {
"id":179996,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour bevindingen GD",
"type":"Message"
}
]
}
,
"179993" : {
"id":179993,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179950" : {
"id":179950,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"179975" : {
"id":179975,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht MV is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"179978" : {
"id":179978,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process diagram"
}
]
}
,
"179973" : {
"id":179973,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179992" : {
"id":179992,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Bevindingen GD",
"type":"Message"
}
]
}
,
"179957" : {
"id":179957,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"179991" : {
"id":179991,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"179940" : {
"id":179940,
"typeIconPath":"data/icons/ArchiMate/CompositeGrouping.png",
"data" : [
{
"name":"iWlz",
"type":"Groepering"
}
]
}
,
"179954" : {
"id":179954,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"179964" : {
"id":179964,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP192: Verzonden bestanden moeten voldoen aan de technische eisen.",
"type":"Requirement"
}
]
}
,
"179965" : {
"id":179965,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"179966" : {
"id":179966,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP179: De grootte van verzonden bestanden mag niet meer zijn dan 25 Mb.",
"type":"Requirement"
}
]
}
,
"179970" : {
"id":179970,
"typeIconPath":"data/icons/UML/UML_PrimitiveType.png",
"data" : [
{
"name":"integer",
"type":"Primitief type"
}
]
}
,
"179974" : {
"id":179974,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht MV verzenden",
"type":"Task"
}
]
}
,
"179961" : {
"id":179961,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"179976" : {
"id":179976,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour MV",
"type":"Message"
}
]
}
,
"179980" : {
"id":179980,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"179981" : {
"id":179981,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"179982" : {
"id":179982,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht MV verzenden",
"type":"Task"
}
]
}
,
"179984" : {
"id":179984,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"MV",
"type":"Message"
}
]
}
,
"179986" : {
"id":179986,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM verzenden",
"type":"Task"
}
]
}
,
"179987" : {
"id":179987,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180025" : {
"id":180025,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180004" : {
"id":180004,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing voorbereiding of indiening ZM",
"type":"Message"
}
]
}
,
"180013" : {
"id":180013,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180035" : {
"id":180035,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"JP",
"type":"Enumeratiewaarde"
}
]
}
,
"180002" : {
"id":180002,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht beslissing tav aanvraag / voorbereiding ZM verzenden",
"type":"Task"
}
]
}
,
"180057" : {
"id":180057,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IT",
"type":"Enumeratiewaarde"
}
]
}
,
"180047" : {
"id":180047,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NE",
"type":"Enumeratiewaarde"
}
]
}
,
"180003" : {
"id":180003,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht beslissing  voorbereiding of indiening ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180029" : {
"id":180029,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KM",
"type":"Enumeratiewaarde"
}
]
}
,
"66932" : {
"id":66932,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"Opbouw berichten",
"type":"Klassendiagram"
}
]
}
,
"180031" : {
"id":180031,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KI",
"type":"Enumeratiewaarde"
}
]
}
,
"180037" : {
"id":180037,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD032: Land",
"type":"Enumeratie"
}
]
}
,
"180008" : {
"id":180008,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanvraag ZM",
"type":"Message"
}
]
}
,
"180012" : {
"id":180012,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanwijzing GD",
"type":"Message"
}
]
}
,
"179998" : {
"id":179998,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM verzenden",
"type":"Task"
}
]
}
,
"180043" : {
"id":180043,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LR",
"type":"Enumeratiewaarde"
}
]
}
,
"180045" : {
"id":180045,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LB",
"type":"Enumeratiewaarde"
}
]
}
,
"179999" : {
"id":179999,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180001" : {
"id":180001,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180039" : {
"id":180039,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CI",
"type":"Enumeratiewaarde"
}
]
}
,
"180033" : {
"id":180033,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"DO",
"type":"Enumeratiewaarde"
}
]
}
,
"180049" : {
"id":180049,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TC",
"type":"Enumeratiewaarde"
}
]
}
,
"66939" : {
"id":66939,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG109",
"type":"Klassendiagram"
}
]
}
,
"180007" : {
"id":180007,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180011" : {
"id":180011,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180016" : {
"id":180016,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanwijzing GD",
"type":"Message"
}
]
}
,
"180041" : {
"id":180041,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CU",
"type":"Enumeratiewaarde"
}
]
}
,
"179997" : {
"id":179997,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180009" : {
"id":180009,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180006" : {
"id":180006,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM verzenden",
"type":"Task"
}
]
}
,
"180023" : {
"id":180023,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TT",
"type":"Enumeratiewaarde"
}
]
}
,
"180051" : {
"id":180051,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CY",
"type":"Enumeratiewaarde"
}
]
}
,
"180055" : {
"id":180055,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EE",
"type":"Enumeratiewaarde"
}
]
}
,
"180027" : {
"id":180027,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MW",
"type":"Enumeratiewaarde"
}
]
}
,
"180000" : {
"id":180000,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing voorbereiding of indiening ZM",
"type":"Message"
}
]
}
,
"180010" : {
"id":180010,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD verzenden",
"type":"Task"
}
]
}
,
"180015" : {
"id":180015,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180014" : {
"id":180014,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD verzenden",
"type":"Task"
}
]
}
,
"180053" : {
"id":180053,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MN",
"type":"Enumeratiewaarde"
}
]
}
,
"180019" : {
"id":180019,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NI",
"type":"Enumeratiewaarde"
}
]
}
,
"180059" : {
"id":180059,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KW",
"type":"Enumeratiewaarde"
}
]
}
,
"180021" : {
"id":180021,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TV",
"type":"Enumeratiewaarde"
}
]
}
,
"180005" : {
"id":180005,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180069" : {
"id":180069,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KG",
"type":"Enumeratiewaarde"
}
]
}
,
"180085" : {
"id":180085,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TF",
"type":"Enumeratiewaarde"
}
]
}
,
"180061" : {
"id":180061,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MT",
"type":"Enumeratiewaarde"
}
]
}
,
"180065" : {
"id":180065,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MO",
"type":"Enumeratiewaarde"
}
]
}
,
"180101" : {
"id":180101,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ID",
"type":"Enumeratiewaarde"
}
]
}
,
"180117" : {
"id":180117,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"RU",
"type":"Enumeratiewaarde"
}
]
}
,
"180071" : {
"id":180071,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LT",
"type":"Enumeratiewaarde"
}
]
}
,
"180105" : {
"id":180105,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AE",
"type":"Enumeratiewaarde"
}
]
}
,
"180083" : {
"id":180083,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KP",
"type":"Enumeratiewaarde"
}
]
}
,
"180095" : {
"id":180095,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180111" : {
"id":180111,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IN",
"type":"Enumeratiewaarde"
}
]
}
,
"180115" : {
"id":180115,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CL",
"type":"Enumeratiewaarde"
}
]
}
,
"180079" : {
"id":180079,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NA",
"type":"Enumeratiewaarde"
}
]
}
,
"180067" : {
"id":180067,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MD",
"type":"Enumeratiewaarde"
}
]
}
,
"180073" : {
"id":180073,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PK",
"type":"Enumeratiewaarde"
}
]
}
,
"180089" : {
"id":180089,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MC",
"type":"Enumeratiewaarde"
}
]
}
,
"180097" : {
"id":180097,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CH",
"type":"Enumeratiewaarde"
}
]
}
,
"180087" : {
"id":180087,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180109" : {
"id":180109,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MU",
"type":"Enumeratiewaarde"
}
]
}
,
"180113" : {
"id":180113,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IL",
"type":"Enumeratiewaarde"
}
]
}
,
"180099" : {
"id":180099,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EH",
"type":"Enumeratiewaarde"
}
]
}
,
"180103" : {
"id":180103,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GL",
"type":"Enumeratiewaarde"
}
]
}
,
"180119" : {
"id":180119,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LV",
"type":"Enumeratiewaarde"
}
]
}
,
"180075" : {
"id":180075,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PM",
"type":"Enumeratiewaarde"
}
]
}
,
"180081" : {
"id":180081,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CW",
"type":"Enumeratiewaarde"
}
]
}
,
"180121" : {
"id":180121,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IM",
"type":"Enumeratiewaarde"
}
]
}
,
"180107" : {
"id":180107,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AW",
"type":"Enumeratiewaarde"
}
]
}
,
"180123" : {
"id":180123,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TO",
"type":"Enumeratiewaarde"
}
]
}
,
"180077" : {
"id":180077,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CX",
"type":"Enumeratiewaarde"
}
]
}
,
"180093" : {
"id":180093,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"JM",
"type":"Enumeratiewaarde"
}
]
}
,
"180063" : {
"id":180063,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LS",
"type":"Enumeratiewaarde"
}
]
}
,
"180091" : {
"id":180091,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KR",
"type":"Enumeratiewaarde"
}
]
}
,
"180187" : {
"id":180187,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"DE",
"type":"Enumeratiewaarde"
}
]
}
,
"180167" : {
"id":180167,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"DJ",
"type":"Enumeratiewaarde"
}
]
}
,
"180139" : {
"id":180139,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LK",
"type":"Enumeratiewaarde"
}
]
}
,
"180151" : {
"id":180151,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CR",
"type":"Enumeratiewaarde"
}
]
}
,
"180169" : {
"id":180169,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CG",
"type":"Enumeratiewaarde"
}
]
}
,
"180129" : {
"id":180129,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KN",
"type":"Enumeratiewaarde"
}
]
}
,
"180133" : {
"id":180133,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CN",
"type":"Enumeratiewaarde"
}
]
}
,
"180141" : {
"id":180141,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IS",
"type":"Enumeratiewaarde"
}
]
}
,
"180155" : {
"id":180155,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GA",
"type":"Enumeratiewaarde"
}
]
}
,
"180125" : {
"id":180125,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SA",
"type":"Enumeratiewaarde"
}
]
}
,
"180135" : {
"id":180135,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"DZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180161" : {
"id":180161,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SJ",
"type":"Enumeratiewaarde"
}
]
}
,
"180165" : {
"id":180165,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SB",
"type":"Enumeratiewaarde"
}
]
}
,
"180175" : {
"id":180175,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180137" : {
"id":180137,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TD",
"type":"Enumeratiewaarde"
}
]
}
,
"180179" : {
"id":180179,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MK",
"type":"Enumeratiewaarde"
}
]
}
,
"180183" : {
"id":180183,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GF",
"type":"Enumeratiewaarde"
}
]
}
,
"180131" : {
"id":180131,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IE",
"type":"Enumeratiewaarde"
}
]
}
,
"180163" : {
"id":180163,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"HK",
"type":"Enumeratiewaarde"
}
]
}
,
"180127" : {
"id":180127,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TH",
"type":"Enumeratiewaarde"
}
]
}
,
"180147" : {
"id":180147,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CV",
"type":"Enumeratiewaarde"
}
]
}
,
"180159" : {
"id":180159,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180149" : {
"id":180149,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"FM",
"type":"Enumeratiewaarde"
}
]
}
,
"180153" : {
"id":180153,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"HM",
"type":"Enumeratiewaarde"
}
]
}
,
"180177" : {
"id":180177,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TW",
"type":"Enumeratiewaarde"
}
]
}
,
"180181" : {
"id":180181,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KE",
"type":"Enumeratiewaarde"
}
]
}
,
"180173" : {
"id":180173,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GP",
"type":"Enumeratiewaarde"
}
]
}
,
"180171" : {
"id":180171,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MG",
"type":"Enumeratiewaarde"
}
]
}
,
"180157" : {
"id":180157,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KH",
"type":"Enumeratiewaarde"
}
]
}
,
"180145" : {
"id":180145,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LC",
"type":"Enumeratiewaarde"
}
]
}
,
"180185" : {
"id":180185,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"DK",
"type":"Enumeratiewaarde"
}
]
}
,
"180143" : {
"id":180143,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ME",
"type":"Enumeratiewaarde"
}
]
}
,
"180207" : {
"id":180207,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BQ",
"type":"Enumeratiewaarde"
}
]
}
,
"180211" : {
"id":180211,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MQ",
"type":"Enumeratiewaarde"
}
]
}
,
"180189" : {
"id":180189,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GI",
"type":"Enumeratiewaarde"
}
]
}
,
"180203" : {
"id":180203,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TK",
"type":"Enumeratiewaarde"
}
]
}
,
"180235" : {
"id":180235,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PW",
"type":"Enumeratiewaarde"
}
]
}
,
"180237" : {
"id":180237,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ER",
"type":"Enumeratiewaarde"
}
]
}
,
"180197" : {
"id":180197,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CM",
"type":"Enumeratiewaarde"
}
]
}
,
"180191" : {
"id":180191,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"HN",
"type":"Enumeratiewaarde"
}
]
}
,
"180205" : {
"id":180205,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CD",
"type":"Enumeratiewaarde"
}
]
}
,
"180199" : {
"id":180199,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LA",
"type":"Enumeratiewaarde"
}
]
}
,
"180239" : {
"id":180239,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BN",
"type":"Enumeratiewaarde"
}
]
}
,
"180201" : {
"id":180201,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CK",
"type":"Enumeratiewaarde"
}
]
}
,
"180241" : {
"id":180241,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AR",
"type":"Enumeratiewaarde"
}
]
}
,
"180243" : {
"id":180243,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AX",
"type":"Enumeratiewaarde"
}
]
}
,
"180219" : {
"id":180219,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TN",
"type":"Enumeratiewaarde"
}
]
}
,
"180245" : {
"id":180245,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AO",
"type":"Enumeratiewaarde"
}
]
}
,
"180217" : {
"id":180217,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IQ",
"type":"Enumeratiewaarde"
}
]
}
,
"180223" : {
"id":180223,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PY",
"type":"Enumeratiewaarde"
}
]
}
,
"180231" : {
"id":180231,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"UZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180213" : {
"id":180213,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"HU",
"type":"Enumeratiewaarde"
}
]
}
,
"180221" : {
"id":180221,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GQ",
"type":"Enumeratiewaarde"
}
]
}
,
"180215" : {
"id":180215,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AT",
"type":"Enumeratiewaarde"
}
]
}
,
"180225" : {
"id":180225,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MA",
"type":"Enumeratiewaarde"
}
]
}
,
"66299" : {
"id":66299,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR002: Geboortedatum mag niet meer dan 120 jaar voor de Dagtekening liggen, tenzij Geboortedatum onbekend is.",
"type":"Beperking"
}
]
}
,
"180227" : {
"id":180227,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GT",
"type":"Enumeratiewaarde"
}
]
}
,
"180195" : {
"id":180195,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"HR",
"type":"Enumeratiewaarde"
}
]
}
,
"180209" : {
"id":180209,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VA",
"type":"Enumeratiewaarde"
}
]
}
,
"180229" : {
"id":180229,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IR",
"type":"Enumeratiewaarde"
}
]
}
,
"180233" : {
"id":180233,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AS",
"type":"Enumeratiewaarde"
}
]
}
,
"180193" : {
"id":180193,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BW",
"type":"Enumeratiewaarde"
}
]
}
,
"180263" : {
"id":180263,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MS",
"type":"Enumeratiewaarde"
}
]
}
,
"180287" : {
"id":180287,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"RO",
"type":"Enumeratiewaarde"
}
]
}
,
"180305" : {
"id":180305,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BL",
"type":"Enumeratiewaarde"
}
]
}
,
"180307" : {
"id":180307,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GW",
"type":"Enumeratiewaarde"
}
]
}
,
"180309" : {
"id":180309,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GM",
"type":"Enumeratiewaarde"
}
]
}
,
"180247" : {
"id":180247,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GU",
"type":"Enumeratiewaarde"
}
]
}
,
"180259" : {
"id":180259,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MM",
"type":"Enumeratiewaarde"
}
]
}
,
"180279" : {
"id":180279,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NG",
"type":"Enumeratiewaarde"
}
]
}
,
"180291" : {
"id":180291,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NF",
"type":"Enumeratiewaarde"
}
]
}
,
"180271" : {
"id":180271,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GE",
"type":"Enumeratiewaarde"
}
]
}
,
"180285" : {
"id":180285,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"FJ",
"type":"Enumeratiewaarde"
}
]
}
,
"180289" : {
"id":180289,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SD",
"type":"Enumeratiewaarde"
}
]
}
,
"180249" : {
"id":180249,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MV",
"type":"Enumeratiewaarde"
}
]
}
,
"180273" : {
"id":180273,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BG",
"type":"Enumeratiewaarde"
}
]
}
,
"180281" : {
"id":180281,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BE",
"type":"Enumeratiewaarde"
}
]
}
,
"180299" : {
"id":180299,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"FK",
"type":"Enumeratiewaarde"
}
]
}
,
"180269" : {
"id":180269,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CF",
"type":"Enumeratiewaarde"
}
]
}
,
"180277" : {
"id":180277,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PT",
"type":"Enumeratiewaarde"
}
]
}
,
"180303" : {
"id":180303,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PS",
"type":"Enumeratiewaarde"
}
]
}
,
"180261" : {
"id":180261,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EC",
"type":"Enumeratiewaarde"
}
]
}
,
"180283" : {
"id":180283,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"DM",
"type":"Enumeratiewaarde"
}
]
}
,
"180267" : {
"id":180267,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BI",
"type":"Enumeratiewaarde"
}
]
}
,
"180253" : {
"id":180253,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AM",
"type":"Enumeratiewaarde"
}
]
}
,
"180255" : {
"id":180255,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MF",
"type":"Enumeratiewaarde"
}
]
}
,
"180265" : {
"id":180265,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GN",
"type":"Enumeratiewaarde"
}
]
}
,
"180275" : {
"id":180275,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MH",
"type":"Enumeratiewaarde"
}
]
}
,
"180293" : {
"id":180293,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MX",
"type":"Enumeratiewaarde"
}
]
}
,
"180257" : {
"id":180257,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ET",
"type":"Enumeratiewaarde"
}
]
}
,
"180295" : {
"id":180295,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NP",
"type":"Enumeratiewaarde"
}
]
}
,
"180297" : {
"id":180297,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SC",
"type":"Enumeratiewaarde"
}
]
}
,
"180251" : {
"id":180251,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AF",
"type":"Enumeratiewaarde"
}
]
}
,
"180301" : {
"id":180301,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BO",
"type":"Enumeratiewaarde"
}
]
}
,
"180351" : {
"id":180351,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PE",
"type":"Enumeratiewaarde"
}
]
}
,
"180315" : {
"id":180315,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"UM",
"type":"Enumeratiewaarde"
}
]
}
,
"180361" : {
"id":180361,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BS",
"type":"Enumeratiewaarde"
}
]
}
,
"180325" : {
"id":180325,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WF",
"type":"Enumeratiewaarde"
}
]
}
,
"180327" : {
"id":180327,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BR",
"type":"Enumeratiewaarde"
}
]
}
,
"180343" : {
"id":180343,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NC",
"type":"Enumeratiewaarde"
}
]
}
,
"180321" : {
"id":180321,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CO",
"type":"Enumeratiewaarde"
}
]
}
,
"180333" : {
"id":180333,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NR",
"type":"Enumeratiewaarde"
}
]
}
,
"180355" : {
"id":180355,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TG",
"type":"Enumeratiewaarde"
}
]
}
,
"180363" : {
"id":180363,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AU",
"type":"Enumeratiewaarde"
}
]
}
,
"180331" : {
"id":180331,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AG",
"type":"Enumeratiewaarde"
}
]
}
,
"180353" : {
"id":180353,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NU",
"type":"Enumeratiewaarde"
}
]
}
,
"180339" : {
"id":180339,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MP",
"type":"Enumeratiewaarde"
}
]
}
,
"180369" : {
"id":180369,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BH",
"type":"Enumeratiewaarde"
}
]
}
,
"180371" : {
"id":180371,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PL",
"type":"Enumeratiewaarde"
}
]
}
,
"180365" : {
"id":180365,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"FI",
"type":"Enumeratiewaarde"
}
]
}
,
"180367" : {
"id":180367,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BF",
"type":"Enumeratiewaarde"
}
]
}
,
"180357" : {
"id":180357,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BY",
"type":"Enumeratiewaarde"
}
]
}
,
"180311" : {
"id":180311,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EG",
"type":"Enumeratiewaarde"
}
]
}
,
"180319" : {
"id":180319,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TR",
"type":"Enumeratiewaarde"
}
]
}
,
"180323" : {
"id":180323,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PN",
"type":"Enumeratiewaarde"
}
]
}
,
"180337" : {
"id":180337,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"RW",
"type":"Enumeratiewaarde"
}
]
}
,
"180345" : {
"id":180345,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CA",
"type":"Enumeratiewaarde"
}
]
}
,
"180347" : {
"id":180347,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VN",
"type":"Enumeratiewaarde"
}
]
}
,
"180335" : {
"id":180335,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"HT",
"type":"Enumeratiewaarde"
}
]
}
,
"180349" : {
"id":180349,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VI",
"type":"Enumeratiewaarde"
}
]
}
,
"180313" : {
"id":180313,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SX",
"type":"Enumeratiewaarde"
}
]
}
,
"180341" : {
"id":180341,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PA",
"type":"Enumeratiewaarde"
}
]
}
,
"180317" : {
"id":180317,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GR",
"type":"Enumeratiewaarde"
}
]
}
,
"180329" : {
"id":180329,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GS",
"type":"Enumeratiewaarde"
}
]
}
,
"180359" : {
"id":180359,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SH",
"type":"Enumeratiewaarde"
}
]
}
,
"180377" : {
"id":180377,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WS",
"type":"Enumeratiewaarde"
}
]
}
,
"180403" : {
"id":180403,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180399" : {
"id":180399,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SI",
"type":"Enumeratiewaarde"
}
]
}
,
"180427" : {
"id":180427,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"JE",
"type":"Enumeratiewaarde"
}
]
}
,
"180433" : {
"id":180433,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SG",
"type":"Enumeratiewaarde"
}
]
}
,
"180419" : {
"id":180419,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"QA",
"type":"Enumeratiewaarde"
}
]
}
,
"180389" : {
"id":180389,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"US",
"type":"Enumeratiewaarde"
}
]
}
,
"180391" : {
"id":180391,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NL",
"type":"Enumeratiewaarde"
}
]
}
,
"180385" : {
"id":180385,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BB",
"type":"Enumeratiewaarde"
}
]
}
,
"180375" : {
"id":180375,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AD",
"type":"Enumeratiewaarde"
}
]
}
,
"180397" : {
"id":180397,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PH",
"type":"Enumeratiewaarde"
}
]
}
,
"180393" : {
"id":180393,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"YE",
"type":"Enumeratiewaarde"
}
]
}
,
"180411" : {
"id":180411,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"UY",
"type":"Enumeratiewaarde"
}
]
}
,
"180381" : {
"id":180381,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SL",
"type":"Enumeratiewaarde"
}
]
}
,
"180387" : {
"id":180387,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BA",
"type":"Enumeratiewaarde"
}
]
}
,
"180401" : {
"id":180401,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"IO",
"type":"Enumeratiewaarde"
}
]
}
,
"180409" : {
"id":180409,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SS",
"type":"Enumeratiewaarde"
}
]
}
,
"180413" : {
"id":180413,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"RE",
"type":"Enumeratiewaarde"
}
]
}
,
"180417" : {
"id":180417,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MR",
"type":"Enumeratiewaarde"
}
]
}
,
"180421" : {
"id":180421,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BT",
"type":"Enumeratiewaarde"
}
]
}
,
"180373" : {
"id":180373,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VU",
"type":"Enumeratiewaarde"
}
]
}
,
"180379" : {
"id":180379,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VG",
"type":"Enumeratiewaarde"
}
]
}
,
"180407" : {
"id":180407,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TM",
"type":"Enumeratiewaarde"
}
]
}
,
"180423" : {
"id":180423,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BM",
"type":"Enumeratiewaarde"
}
]
}
,
"180425" : {
"id":180425,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ML",
"type":"Enumeratiewaarde"
}
]
}
,
"180405" : {
"id":180405,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NO",
"type":"Enumeratiewaarde"
}
]
}
,
"180395" : {
"id":180395,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VE",
"type":"Enumeratiewaarde"
}
]
}
,
"180415" : {
"id":180415,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GH",
"type":"Enumeratiewaarde"
}
]
}
,
"180383" : {
"id":180383,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"MY",
"type":"Enumeratiewaarde"
}
]
}
,
"180429" : {
"id":180429,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SM",
"type":"Enumeratiewaarde"
}
]
}
,
"180431" : {
"id":180431,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GD",
"type":"Enumeratiewaarde"
}
]
}
,
"180478" : {
"id":180478,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TJ",
"type":"Enumeratiewaarde"
}
]
}
,
"180492" : {
"id":180492,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PG",
"type":"Enumeratiewaarde"
}
]
}
,
"180453" : {
"id":180453,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ZM",
"type":"Enumeratiewaarde"
}
]
}
,
"180457" : {
"id":180457,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"UG",
"type":"Enumeratiewaarde"
}
]
}
,
"180494" : {
"id":180494,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SR",
"type":"Enumeratiewaarde"
}
]
}
,
"180496" : {
"id":180496,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BD",
"type":"Enumeratiewaarde"
}
]
}
,
"180459" : {
"id":180459,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BV",
"type":"Enumeratiewaarde"
}
]
}
,
"180498" : {
"id":180498,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"FR",
"type":"Enumeratiewaarde"
}
]
}
,
"180465" : {
"id":180465,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AL",
"type":"Enumeratiewaarde"
}
]
}
,
"180451" : {
"id":180451,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"OM",
"type":"Enumeratiewaarde"
}
]
}
,
"180461" : {
"id":180461,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"KY",
"type":"Enumeratiewaarde"
}
]
}
,
"180486" : {
"id":180486,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TL",
"type":"Enumeratiewaarde"
}
]
}
,
"180484" : {
"id":180484,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"RS",
"type":"Enumeratiewaarde"
}
]
}
,
"180445" : {
"id":180445,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SN",
"type":"Enumeratiewaarde"
}
]
}
,
"180441" : {
"id":180441,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ES",
"type":"Enumeratiewaarde"
}
]
}
,
"180443" : {
"id":180443,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SE",
"type":"Enumeratiewaarde"
}
]
}
,
"180474" : {
"id":180474,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LY",
"type":"Enumeratiewaarde"
}
]
}
,
"180449" : {
"id":180449,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SK",
"type":"Enumeratiewaarde"
}
]
}
,
"180468" : {
"id":180468,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LI",
"type":"Enumeratiewaarde"
}
]
}
,
"180472" : {
"id":180472,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SO",
"type":"Enumeratiewaarde"
}
]
}
,
"180480" : {
"id":180480,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180482" : {
"id":180482,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SV",
"type":"Enumeratiewaarde"
}
]
}
,
"180463" : {
"id":180463,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PR",
"type":"Enumeratiewaarde"
}
]
}
,
"180455" : {
"id":180455,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PF",
"type":"Enumeratiewaarde"
}
]
}
,
"180488" : {
"id":180488,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LU",
"type":"Enumeratiewaarde"
}
]
}
,
"180435" : {
"id":180435,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AQ",
"type":"Enumeratiewaarde"
}
]
}
,
"180470" : {
"id":180470,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"SY",
"type":"Enumeratiewaarde"
}
]
}
,
"180437" : {
"id":180437,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GY",
"type":"Enumeratiewaarde"
}
]
}
,
"180490" : {
"id":180490,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"UA",
"type":"Enumeratiewaarde"
}
]
}
,
"180439" : {
"id":180439,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BZ",
"type":"Enumeratiewaarde"
}
]
}
,
"180476" : {
"id":180476,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"JO",
"type":"Enumeratiewaarde"
}
]
}
,
"180447" : {
"id":180447,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"YT",
"type":"Enumeratiewaarde"
}
]
}
,
"180511" : {
"id":180511,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ST",
"type":"Enumeratiewaarde"
}
]
}
,
"180529" : {
"id":180529,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aavraag ZM ontvangen",
"type":"Intermediate event"
}
]
}
,
"180503" : {
"id":180503,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"FO",
"type":"Enumeratiewaarde"
}
]
}
,
"180507" : {
"id":180507,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GB",
"type":"Enumeratiewaarde"
}
]
}
,
"180544" : {
"id":180544,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180561" : {
"id":180561,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"180501" : {
"id":180501,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CC",
"type":"Enumeratiewaarde"
}
]
}
,
"180525" : {
"id":180525,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180513" : {
"id":180513,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VC",
"type":"Enumeratiewaarde"
}
]
}
,
"180528" : {
"id":180528,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180530" : {
"id":180530,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"180535" : {
"id":180535,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanvraag ZM valide?",
"type":"Gateway"
}
]
}
,
"180536" : {
"id":180536,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM niet valide",
"type":"End event"
}
]
}
,
"180555" : {
"id":180555,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"180558" : {
"id":180558,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"180521" : {
"id":180521,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"180509" : {
"id":180509,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ZA",
"type":"Enumeratiewaarde"
}
]
}
,
"180532" : {
"id":180532,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht bevindingen GD",
"type":"Task"
}
]
}
,
"180515" : {
"id":180515,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"GG",
"type":"Enumeratiewaarde"
}
]
}
,
"180531" : {
"id":180531,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180538" : {
"id":180538,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht MV",
"type":"Task"
}
]
}
,
"180539" : {
"id":180539,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren  bericht MV",
"type":"Task"
}
]
}
,
"180537" : {
"id":180537,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180541" : {
"id":180541,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht MV valide?",
"type":"Gateway"
}
]
}
,
"180534" : {
"id":180534,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180543" : {
"id":180543,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beslissen over aanvraag en  voorbereiding ZM",
"type":"Task"
}
]
}
,
"180527" : {
"id":180527,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD niet valide",
"type":"End event"
}
]
}
,
"180540" : {
"id":180540,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180545" : {
"id":180545,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht beslissing tav aanvraag / voorbereiding ZM",
"type":"Task"
}
]
}
,
"180546" : {
"id":180546,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180547" : {
"id":180547,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht bevindingen GD",
"type":"Task"
}
]
}
,
"180548" : {
"id":180548,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180526" : {
"id":180526,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht bevindingen GD valide?",
"type":"Gateway"
}
]
}
,
"180549" : {
"id":180549,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180551" : {
"id":180551,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180552" : {
"id":180552,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180553" : {
"id":180553,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanvraag beoordelen",
"type":"Task"
}
]
}
,
"180517" : {
"id":180517,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ZW",
"type":"Enumeratiewaarde"
}
]
}
,
"180556" : {
"id":180556,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"180557" : {
"id":180557,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180523" : {
"id":180523,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"180550" : {
"id":180550,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"180559" : {
"id":180559,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanwijzen GD",
"type":"Task"
}
]
}
,
"180542" : {
"id":180542,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180519" : {
"id":180519,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AI",
"type":"Enumeratiewaarde"
}
]
}
,
"180533" : {
"id":180533,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht  bevindingen GD",
"type":"Task"
}
]
}
,
"180562" : {
"id":180562,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180554" : {
"id":180554,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180505" : {
"id":180505,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BJ",
"type":"Enumeratiewaarde"
}
]
}
,
"180560" : {
"id":180560,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180574" : {
"id":180574,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht beslissing tav aanvraag / voorbereiding ZM",
"type":"Task"
}
]
}
,
"180565" : {
"id":180565,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"180595" : {
"id":180595,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Aanvrager",
"type":"Process diagram"
}
]
}
,
"180618" : {
"id":180618,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanwijzing GD valide?",
"type":"Gateway"
}
]
}
,
"180590" : {
"id":180590,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180602" : {
"id":180602,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht melding indienen verzoekschrift",
"type":"Task"
}
]
}
,
"180604" : {
"id":180604,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD niet valide",
"type":"End event"
}
]
}
,
"180564" : {
"id":180564,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180575" : {
"id":180575,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180610" : {
"id":180610,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht  beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"180620" : {
"id":180620,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht bevindingen GD",
"type":"Task"
}
]
}
,
"180583" : {
"id":180583,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"180598" : {
"id":180598,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180608" : {
"id":180608,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180616" : {
"id":180616,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht beslissing tav  indienen verzoekschrift valide?",
"type":"Gateway"
}
]
}
,
"180594" : {
"id":180594,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Aanvrager",
"type":"Pool"
}
]
}
,
"180622" : {
"id":180622,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180624" : {
"id":180624,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"180626" : {
"id":180626,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht aanwijzing GD",
"type":"Task"
}
]
}
,
"180585" : {
"id":180585,
"typeIconPath":"data/icons/UML/UML_PrimitiveType.png",
"data" : [
{
"name":"dateTime",
"type":"Primitief type"
}
]
}
,
"180628" : {
"id":180628,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180572" : {
"id":180572,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180581" : {
"id":180581,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht  MV",
"type":"Task"
}
]
}
,
"180596" : {
"id":180596,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180566" : {
"id":180566,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180573" : {
"id":180573,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht beslissing tav  aanvraag / voorbereiding ZM ontvangen",
"type":"Intermediate event"
}
]
}
,
"180571" : {
"id":180571,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180568" : {
"id":180568,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht aanvraag ZM",
"type":"Task"
}
]
}
,
"180579" : {
"id":180579,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180591" : {
"id":180591,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM verzenden",
"type":"Task"
}
]
}
,
"180567" : {
"id":180567,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180589" : {
"id":180589,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180597" : {
"id":180597,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM verzenden",
"type":"Task"
}
]
}
,
"180612" : {
"id":180612,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"180614" : {
"id":180614,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht bevindingen GD  ontvangen",
"type":"Intermediate event"
}
]
}
,
"180570" : {
"id":180570,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180576" : {
"id":180576,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht MV ontvangen",
"type":"Intermediate event"
}
]
}
,
"180580" : {
"id":180580,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180577" : {
"id":180577,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180569" : {
"id":180569,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180592" : {
"id":180592,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180588" : {
"id":180588,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"180578" : {
"id":180578,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht MV  niet valide",
"type":"End event"
}
]
}
,
"180563" : {
"id":180563,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"180593" : {
"id":180593,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG102 - Retour aanvraag ZM",
"type":"Message"
}
]
}
,
"180599" : {
"id":180599,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG101 - Aanvraag ZM",
"type":"Message"
}
]
}
,
"180606" : {
"id":180606,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Opvolgen",
"type":"Lane"
}
]
}
,
"180650" : {
"id":180650,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"66574" : {
"id":66574,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR002: Geboortedatum mag niet meer dan 120 jaar voor de Dagtekening liggen.",
"type":"Beperking"
}
]
}
,
"180668" : {
"id":180668,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Uitvoeren psychiatrisch onderzoek",
"type":"Task"
}
]
}
,
"180690" : {
"id":180690,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Melding indienen verzoekschrift ontvangen",
"type":"Task"
}
]
}
,
"180692" : {
"id":180692,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180672" : {
"id":180672,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180678" : {
"id":180678,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180682" : {
"id":180682,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"180630" : {
"id":180630,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180654" : {
"id":180654,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Lane"
}
]
}
,
"180656" : {
"id":180656,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht melding indienen verzoekschrift niet valide",
"type":"End event"
}
]
}
,
"180662" : {
"id":180662,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht melding  indienen verzoekschriftt compleet?",
"type":"Gateway"
}
]
}
,
"180680" : {
"id":180680,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180640" : {
"id":180640,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180664" : {
"id":180664,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180658" : {
"id":180658,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180638" : {
"id":180638,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"180676" : {
"id":180676,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180632" : {
"id":180632,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180636" : {
"id":180636,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180648" : {
"id":180648,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht melding indienen verzoekschrift",
"type":"Task"
}
]
}
,
"180666" : {
"id":180666,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht MV",
"type":"Task"
}
]
}
,
"180634" : {
"id":180634,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht MV",
"type":"Task"
}
]
}
,
"180670" : {
"id":180670,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180686" : {
"id":180686,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Kennisnemen",
"type":"Lane"
}
]
}
,
"180652" : {
"id":180652,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"180688" : {
"id":180688,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht melding indienen verzoekschrift",
"type":"Task"
}
]
}
,
"180642" : {
"id":180642,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180674" : {
"id":180674,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht MV ontvangen",
"type":"Intermediate event"
}
]
}
,
"180644" : {
"id":180644,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180684" : {
"id":180684,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM ontvangen",
"type":"Intermediate event"
}
]
}
,
"180646" : {
"id":180646,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"180660" : {
"id":180660,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180702" : {
"id":180702,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht beslissing tav  indienen verzoekschrift niet valide",
"type":"End event"
}
]
}
,
"180714" : {
"id":180714,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180742" : {
"id":180742,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"180746" : {
"id":180746,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanvragen ZM",
"type":"Task"
}
]
}
,
"180696" : {
"id":180696,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Indienen verzoekschrift gemeld",
"type":"End event"
}
]
}
,
"180708" : {
"id":180708,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht beslissing tav indienen verzoekschrift ontvangen",
"type":"Intermediate event"
}
]
}
,
"180748" : {
"id":180748,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"180722" : {
"id":180722,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beoordelen Pva, zorgplan en zorgkaart",
"type":"Task"
}
]
}
,
"180734" : {
"id":180734,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aavragen",
"type":"Lane"
}
]
}
,
"180740" : {
"id":180740,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180750" : {
"id":180750,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_XsdVersie",
"type":"Datatype"
}
]
}
,
"180698" : {
"id":180698,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180736" : {
"id":180736,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180710" : {
"id":180710,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen  beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"180732" : {
"id":180732,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180744" : {
"id":180744,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180694" : {
"id":180694,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht melding  indienen verzoekschrift  ontvangen",
"type":"Intermediate event"
}
]
}
,
"180724" : {
"id":180724,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht bevindingen GD",
"type":"Task"
}
]
}
,
"180730" : {
"id":180730,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180754" : {
"id":180754,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180755" : {
"id":180755,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM controleren",
"type":"Task"
}
]
}
,
"180728" : {
"id":180728,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Beslissing tot beeindigen voorbereiden ZM ontvangen?",
"type":"Gateway"
}
]
}
,
"180756" : {
"id":180756,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanvraag ZM valide?",
"type":"Gateway"
}
]
}
,
"180757" : {
"id":180757,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180704" : {
"id":180704,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180712" : {
"id":180712,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"180720" : {
"id":180720,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180738" : {
"id":180738,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"180726" : {
"id":180726,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding ZM gestopt",
"type":"End event"
}
]
}
,
"180700" : {
"id":180700,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180716" : {
"id":180716,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180706" : {
"id":180706,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180718" : {
"id":180718,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180764" : {
"id":180764,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180816" : {
"id":180816,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"180765" : {
"id":180765,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD opstellen",
"type":"Task"
}
]
}
,
"180795" : {
"id":180795,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180818" : {
"id":180818,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"6",
"type":"Enumeratiewaarde"
}
]
}
,
"180773" : {
"id":180773,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180791" : {
"id":180791,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"180820" : {
"id":180820,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"180792" : {
"id":180792,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"180780" : {
"id":180780,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180772" : {
"id":180772,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"GD aanwijzen",
"type":"Task"
}
]
}
,
"180778" : {
"id":180778,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180781" : {
"id":180781,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180786" : {
"id":180786,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180797" : {
"id":180797,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180789" : {
"id":180789,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180798" : {
"id":180798,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180800" : {
"id":180800,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180802" : {
"id":180802,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht MV ontvangen",
"type":"Task"
}
]
}
,
"180785" : {
"id":180785,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180769" : {
"id":180769,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beslissing over voorbereiding of indiening ZM nemen",
"type":"Task"
}
]
}
,
"180774" : {
"id":180774,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180805" : {
"id":180805,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180794" : {
"id":180794,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180770" : {
"id":180770,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180787" : {
"id":180787,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180782" : {
"id":180782,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD ontvangen",
"type":"Task"
}
]
}
,
"180793" : {
"id":180793,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180761" : {
"id":180761,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180810" : {
"id":180810,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD700: Naamgebruik",
"type":"Enumeratie"
}
]
}
,
"180814" : {
"id":180814,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"180758" : {
"id":180758,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM Ontvangen",
"type":"Task"
}
]
}
,
"180777" : {
"id":180777,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"180762" : {
"id":180762,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht  bevindingen GD controleren",
"type":"Task"
}
]
}
,
"180784" : {
"id":180784,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD is niet valide",
"type":"End event"
}
]
}
,
"180763" : {
"id":180763,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht bevindingen GD valide?",
"type":"Gateway"
}
]
}
,
"180775" : {
"id":180775,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen aanvraag ZM beoordelen",
"type":"Task"
}
]
}
,
"180760" : {
"id":180760,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM opstellen",
"type":"Task"
}
]
}
,
"180776" : {
"id":180776,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180779" : {
"id":180779,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM is niet valide",
"type":"End event"
}
]
}
,
"180767" : {
"id":180767,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180768" : {
"id":180768,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht MV valide?",
"type":"Gateway"
}
]
}
,
"180783" : {
"id":180783,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180790" : {
"id":180790,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180766" : {
"id":180766,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180801" : {
"id":180801,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180803" : {
"id":180803,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"180804" : {
"id":180804,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht MV  is niet valide",
"type":"End event"
}
]
}
,
"180807" : {
"id":180807,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4",
"type":"Enumeratiewaarde"
}
]
}
,
"180759" : {
"id":180759,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180796" : {
"id":180796,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180799" : {
"id":180799,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht MV controleren",
"type":"Task"
}
]
}
,
"180788" : {
"id":180788,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180812" : {
"id":180812,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"180771" : {
"id":180771,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"180838" : {
"id":180838,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180841" : {
"id":180841,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceScheme.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources diagram"
}
]
}
,
"180844" : {
"id":180844,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process diagram"
}
]
}
,
"180852" : {
"id":180852,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process diagram"
}
]
}
,
"180873" : {
"id":180873,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceScheme.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources diagram"
}
]
}
,
"180874" : {
"id":180874,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces gegevens geleverde verplichte zorg aanleveren",
"type":"Collaboration diagram"
}
]
}
,
"180855" : {
"id":180855,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"ZM voorbereiden - Procesmodel",
"type":"Collaboration diagram"
}
]
}
,
"180847" : {
"id":180847,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration diagram"
}
]
}
,
"180850" : {
"id":180850,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceScheme.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources diagram"
}
]
}
,
"180875" : {
"id":180875,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces over voorbereiding ZM beslissen",
"type":"Collaboration diagram"
}
]
}
,
"180859" : {
"id":180859,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180877" : {
"id":180877,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Geneesheer-directeur",
"type":"Resource role"
}
]
}
,
"180879" : {
"id":180879,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Resource role"
}
]
}
,
"180857" : {
"id":180857,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Aanvrager",
"type":"Process diagram"
}
]
}
,
"180881" : {
"id":180881,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgverlener",
"type":"Resource role"
}
]
}
,
"180828" : {
"id":180828,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceScheme.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources diagram"
}
]
}
,
"180846" : {
"id":180846,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"IGJ",
"type":"Process diagram"
}
]
}
,
"180861" : {
"id":180861,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180827" : {
"id":180827,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography diagram"
}
]
}
,
"180863" : {
"id":180863,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"Waardeketen iWvggz",
"type":"Choreography diagram"
}
]
}
,
"180856" : {
"id":180856,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180849" : {
"id":180849,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Stichting PVP",
"type":"Process diagram"
}
]
}
,
"180854" : {
"id":180854,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"ZM voorbereiden",
"type":"Choreography diagram"
}
]
}
,
"180867" : {
"id":180867,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene  verstrekken",
"type":"Choreography diagram"
}
]
}
,
"180843" : {
"id":180843,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180865" : {
"id":180865,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process diagram"
}
]
}
,
"180872" : {
"id":180872,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process diagram"
}
]
}
,
"180845" : {
"id":180845,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography diagram"
}
]
}
,
"180824" : {
"id":180824,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"180885" : {
"id":180885,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"180832" : {
"id":180832,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration diagram"
}
]
}
,
"180871" : {
"id":180871,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces bevindingen beoordelen",
"type":"Collaboration diagram"
}
]
}
,
"180836" : {
"id":180836,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180837" : {
"id":180837,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process diagram"
}
]
}
,
"180831" : {
"id":180831,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180834" : {
"id":180834,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process diagram"
}
]
}
,
"180833" : {
"id":180833,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces GD aanwijzen",
"type":"Collaboration diagram"
}
]
}
,
"180835" : {
"id":180835,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration diagram"
}
]
}
,
"180839" : {
"id":180839,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography diagram"
}
]
}
,
"180840" : {
"id":180840,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180842" : {
"id":180842,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process diagram"
}
]
}
,
"180848" : {
"id":180848,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography diagram"
}
]
}
,
"180858" : {
"id":180858,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"ZM voorbereiden - Choreografiemodel",
"type":"Choreography diagram"
}
]
}
,
"180860" : {
"id":180860,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces ZM aanragen",
"type":"Collaboration diagram"
}
]
}
,
"180862" : {
"id":180862,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces indiening VCM mededelen",
"type":"Collaboration diagram"
}
]
}
,
"180864" : {
"id":180864,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process diagram"
}
]
}
,
"180866" : {
"id":180866,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"OM",
"type":"Process diagram"
}
]
}
,
"180851" : {
"id":180851,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process diagram"
}
]
}
,
"180869" : {
"id":180869,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"proces medisch onderzoeken",
"type":"Collaboration diagram"
}
]
}
,
"180870" : {
"id":180870,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyScheme.png",
"data" : [
{
"name":"Toezicht houden",
"type":"Choreography diagram"
}
]
}
,
"180830" : {
"id":180830,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceScheme.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources diagram"
}
]
}
,
"180822" : {
"id":180822,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5",
"type":"Enumeratiewaarde"
}
]
}
,
"180853" : {
"id":180853,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationScheme.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration diagram"
}
]
}
,
"180868" : {
"id":180868,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessScheme.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process diagram"
}
]
}
,
"180829" : {
"id":180829,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceScheme.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources diagram"
}
]
}
,
"180906" : {
"id":180906,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"MV",
"type":"Message"
}
]
}
,
"180907" : {
"id":180907,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180916" : {
"id":180916,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Meldiing indienen verzoekschrift",
"type":"Message"
}
]
}
,
"180898" : {
"id":180898,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180903" : {
"id":180903,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180915" : {
"id":180915,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180924" : {
"id":180924,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"180908" : {
"id":180908,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing tav indienen verzoekschrift",
"type":"Message"
}
]
}
,
"180891" : {
"id":180891,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Geneesheer-directeur",
"type":"Resource role"
}
]
}
,
"180910" : {
"id":180910,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanwijzing GD",
"type":"Message"
}
]
}
,
"180901" : {
"id":180901,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180936" : {
"id":180936,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Pool"
}
]
}
,
"180919" : {
"id":180919,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180930" : {
"id":180930,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Lane"
}
]
}
,
"180902" : {
"id":180902,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanwijzing GD",
"type":"Message"
}
]
}
,
"180896" : {
"id":180896,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"180911" : {
"id":180911,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180904" : {
"id":180904,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour bevindingen GD",
"type":"Message"
}
]
}
,
"180889" : {
"id":180889,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgverlener",
"type":"Resource role"
}
]
}
,
"180897" : {
"id":180897,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"180893" : {
"id":180893,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_UUID",
"type":"Datatype"
}
]
}
,
"180913" : {
"id":180913,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180914" : {
"id":180914,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Bevindingen GD",
"type":"Message"
}
]
}
,
"180918" : {
"id":180918,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing tav indienen verzoekschrift",
"type":"Message"
}
]
}
,
"180917" : {
"id":180917,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180922" : {
"id":180922,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanvraag ZM",
"type":"Message"
}
]
}
,
"180923" : {
"id":180923,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"180925" : {
"id":180925,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Gebruikte kleuren: Wlz = mosgroen Jeugdwet = violet Wmo = donkerblauw Pgb = oranje Referentie = donkergeel",
"type":"Tekenvorm"
}
]
}
,
"180927" : {
"id":180927,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"GD aanwijzen",
"type":"Task"
}
]
}
,
"180900" : {
"id":180900,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Pool"
}
]
}
,
"180899" : {
"id":180899,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour melding indienen verzoekschrift",
"type":"Message"
}
]
}
,
"180887" : {
"id":180887,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Resource role"
}
]
}
,
"180912" : {
"id":180912,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanvraag ZM",
"type":"Message"
}
]
}
,
"180921" : {
"id":180921,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180909" : {
"id":180909,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180920" : {
"id":180920,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour MV",
"type":"Message"
}
]
}
,
"180905" : {
"id":180905,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180957" : {
"id":180957,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"180954" : {
"id":180954,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"180963" : {
"id":180963,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD verzenden",
"type":"Task"
}
]
}
,
"180952" : {
"id":180952,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"180960" : {
"id":180960,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180950" : {
"id":180950,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"113485" : {
"id":113485,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Bedrijfsregels - OP WvGGZ",
"type":"Motivatie-elementen"
}
]
}
,
"187536" : {
"id":187536,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187525" : {
"id":187525,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187523" : {
"id":187523,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187530" : {
"id":187530,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Over iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"187540" : {
"id":187540,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatiemodel iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"187544" : {
"id":187544,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187538" : {
"id":187538,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187546" : {
"id":187546,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187548" : {
"id":187548,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187550" : {
"id":187550,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187542" : {
"id":187542,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"De afspraken tussen de ketenpartijen die nodig zijn om de informatieuitwisseling goed uit te kunnen voeren, zijn beschreven in de regels.   Vaststaande gegevens zijn beschreven in uitgangspunten. Hiervan afgeleid zijn operationele bedrijfsregels, die  technisch gecontroleerd kunnen worden met technische regels. Daarnaast zijn nog condities, constraints en  invulinstructies beschreven die verder bepalen hoe de berichten gevuld moeten worden.  Hieronder kunt u doorklikken naar de pagina's waar de regels per standaard beschreven staan.",
"type":"Tekenvorm"
}
]
}
,
"191116" : {
"id":191116,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0120",
"type":"Enumeratiewaarde"
}
]
}
,
"191114" : {
"id":191114,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1210",
"type":"Enumeratiewaarde"
}
]
}
,
"191113" : {
"id":191113,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2420",
"type":"Enumeratiewaarde"
}
]
}
,
"191117" : {
"id":191117,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2120",
"type":"Enumeratiewaarde"
}
]
}
,
"191115" : {
"id":191115,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0740",
"type":"Enumeratiewaarde"
}
]
}
,
"191118" : {
"id":191118,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3130",
"type":"Enumeratiewaarde"
}
]
}
,
"191151" : {
"id":191151,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1240",
"type":"Enumeratiewaarde"
}
]
}
,
"191126" : {
"id":191126,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0230",
"type":"Enumeratiewaarde"
}
]
}
,
"191121" : {
"id":191121,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0140",
"type":"Enumeratiewaarde"
}
]
}
,
"191127" : {
"id":191127,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0330",
"type":"Enumeratiewaarde"
}
]
}
,
"191129" : {
"id":191129,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0420",
"type":"Enumeratiewaarde"
}
]
}
,
"191137" : {
"id":191137,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0730",
"type":"Enumeratiewaarde"
}
]
}
,
"191134" : {
"id":191134,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0620",
"type":"Enumeratiewaarde"
}
]
}
,
"191139" : {
"id":191139,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0780",
"type":"Enumeratiewaarde"
}
]
}
,
"191142" : {
"id":191142,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0920",
"type":"Enumeratiewaarde"
}
]
}
,
"191150" : {
"id":191150,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1200",
"type":"Enumeratiewaarde"
}
]
}
,
"191123" : {
"id":191123,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0200",
"type":"Enumeratiewaarde"
}
]
}
,
"191144" : {
"id":191144,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0950",
"type":"Enumeratiewaarde"
}
]
}
,
"191152" : {
"id":191152,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1410",
"type":"Enumeratiewaarde"
}
]
}
,
"191153" : {
"id":191153,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1420",
"type":"Enumeratiewaarde"
}
]
}
,
"191131" : {
"id":191131,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0530",
"type":"Enumeratiewaarde"
}
]
}
,
"191132" : {
"id":191132,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0600",
"type":"Enumeratiewaarde"
}
]
}
,
"191138" : {
"id":191138,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0750",
"type":"Enumeratiewaarde"
}
]
}
,
"191143" : {
"id":191143,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0930",
"type":"Enumeratiewaarde"
}
]
}
,
"191120" : {
"id":191120,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD459: Indicatieorgaan - Vervallen",
"type":"Enumeratie"
}
]
}
,
"191136" : {
"id":191136,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0710",
"type":"Enumeratiewaarde"
}
]
}
,
"191145" : {
"id":191145,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0980",
"type":"Enumeratiewaarde"
}
]
}
,
"191147" : {
"id":191147,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0982",
"type":"Enumeratiewaarde"
}
]
}
,
"191119" : {
"id":191119,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2320",
"type":"Enumeratiewaarde"
}
]
}
,
"191128" : {
"id":191128,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0410",
"type":"Enumeratiewaarde"
}
]
}
,
"191141" : {
"id":191141,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0810",
"type":"Enumeratiewaarde"
}
]
}
,
"191124" : {
"id":191124,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0210",
"type":"Enumeratiewaarde"
}
]
}
,
"191148" : {
"id":191148,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0983",
"type":"Enumeratiewaarde"
}
]
}
,
"191149" : {
"id":191149,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1020",
"type":"Enumeratiewaarde"
}
]
}
,
"191133" : {
"id":191133,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0610",
"type":"Enumeratiewaarde"
}
]
}
,
"191130" : {
"id":191130,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0510",
"type":"Enumeratiewaarde"
}
]
}
,
"191146" : {
"id":191146,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0981",
"type":"Enumeratiewaarde"
}
]
}
,
"191140" : {
"id":191140,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0790",
"type":"Enumeratiewaarde"
}
]
}
,
"191125" : {
"id":191125,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0220",
"type":"Enumeratiewaarde"
}
]
}
,
"191122" : {
"id":191122,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0142",
"type":"Enumeratiewaarde"
}
]
}
,
"191135" : {
"id":191135,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0700",
"type":"Enumeratiewaarde"
}
]
}
,
"191158" : {
"id":191158,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1820",
"type":"Enumeratiewaarde"
}
]
}
,
"191171" : {
"id":191171,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2700",
"type":"Enumeratiewaarde"
}
]
}
,
"191166" : {
"id":191166,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2410",
"type":"Enumeratiewaarde"
}
]
}
,
"191180" : {
"id":191180,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3140",
"type":"Enumeratiewaarde"
}
]
}
,
"191175" : {
"id":191175,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2920",
"type":"Enumeratiewaarde"
}
]
}
,
"191164" : {
"id":191164,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2330",
"type":"Enumeratiewaarde"
}
]
}
,
"191167" : {
"id":191167,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2510",
"type":"Enumeratiewaarde"
}
]
}
,
"191174" : {
"id":191174,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2900",
"type":"Enumeratiewaarde"
}
]
}
,
"191157" : {
"id":191157,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1810",
"type":"Enumeratiewaarde"
}
]
}
,
"191176" : {
"id":191176,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2930",
"type":"Enumeratiewaarde"
}
]
}
,
"191155" : {
"id":191155,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1600",
"type":"Enumeratiewaarde"
}
]
}
,
"191168" : {
"id":191168,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2520",
"type":"Enumeratiewaarde"
}
]
}
,
"191154" : {
"id":191154,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1500",
"type":"Enumeratiewaarde"
}
]
}
,
"191161" : {
"id":191161,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1910",
"type":"Enumeratiewaarde"
}
]
}
,
"191177" : {
"id":191177,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3010",
"type":"Enumeratiewaarde"
}
]
}
,
"191178" : {
"id":191178,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3020",
"type":"Enumeratiewaarde"
}
]
}
,
"191169" : {
"id":191169,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2540",
"type":"Enumeratiewaarde"
}
]
}
,
"191159" : {
"id":191159,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1830",
"type":"Enumeratiewaarde"
}
]
}
,
"191160" : {
"id":191160,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1900",
"type":"Enumeratiewaarde"
}
]
}
,
"191162" : {
"id":191162,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2000",
"type":"Enumeratiewaarde"
}
]
}
,
"191170" : {
"id":191170,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2600",
"type":"Enumeratiewaarde"
}
]
}
,
"191173" : {
"id":191173,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2820",
"type":"Enumeratiewaarde"
}
]
}
,
"191179" : {
"id":191179,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3120",
"type":"Enumeratiewaarde"
}
]
}
,
"191172" : {
"id":191172,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2800",
"type":"Enumeratiewaarde"
}
]
}
,
"191163" : {
"id":191163,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2110",
"type":"Enumeratiewaarde"
}
]
}
,
"191165" : {
"id":191165,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2340",
"type":"Enumeratiewaarde"
}
]
}
,
"191156" : {
"id":191156,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1730",
"type":"Enumeratiewaarde"
}
]
}
,
"191189" : {
"id":191189,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"16",
"type":"Enumeratiewaarde"
}
]
}
,
"191183" : {
"id":191183,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"191190" : {
"id":191190,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"82",
"type":"Enumeratiewaarde"
}
]
}
,
"191191" : {
"id":191191,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"83",
"type":"Enumeratiewaarde"
}
]
}
,
"191181" : {
"id":191181,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD001: Zorgkantoor - Vervallen",
"type":"Enumeratie"
}
]
}
,
"191187" : {
"id":191187,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"191188" : {
"id":191188,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"14",
"type":"Enumeratiewaarde"
}
]
}
,
"191186" : {
"id":191186,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"JZ756: Eenheid - Vervallen",
"type":"Enumeratie"
}
]
}
,
"191185" : {
"id":191185,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5522",
"type":"Enumeratiewaarde"
}
]
}
,
"191110" : {
"id":191110,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3100",
"type":"Enumeratiewaarde"
}
]
}
,
"191111" : {
"id":191111,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3000",
"type":"Enumeratiewaarde"
}
]
}
,
"191108" : {
"id":191108,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD126: BOPZ",
"type":"Enumeratie"
}
]
}
,
"191106" : {
"id":191106,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"191105" : {
"id":191105,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD588: Mutatiecode - Vervallen",
"type":"Enumeratie"
}
]
}
,
"191107" : {
"id":191107,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2310",
"type":"Enumeratiewaarde"
}
]
}
,
"191109" : {
"id":191109,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9",
"type":"Enumeratiewaarde"
}
]
}
,
"191112" : {
"id":191112,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0900",
"type":"Enumeratiewaarde"
}
]
}
,
"192190" : {
"id":192190,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"192191" : {
"id":192191,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"192192" : {
"id":192192,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"182776" : {
"id":182776,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"07",
"type":"Enumeratiewaarde"
}
]
}
,
"182749" : {
"id":182749,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"10",
"type":"Enumeratiewaarde"
}
]
}
,
"182718" : {
"id":182718,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Medische verklaring is ontvangen",
"type":"End event"
}
]
}
,
"182739" : {
"id":182739,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"182764" : {
"id":182764,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"12",
"type":"Enumeratiewaarde"
}
]
}
,
"182728" : {
"id":182728,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht Medische verklaring verzenden",
"type":"Task"
}
]
}
,
"182730" : {
"id":182730,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"37291" : {
"id":37291,
"typeIconPath":"data/icons/UML/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"182724" : {
"id":182724,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182736" : {
"id":182736,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht Medische verklaring valide?",
"type":"Gateway"
}
]
}
,
"182734" : {
"id":182734,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"182714" : {
"id":182714,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182757" : {
"id":182757,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"15",
"type":"Enumeratiewaarde"
}
]
}
,
"182726" : {
"id":182726,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medische verklaring controleren",
"type":"Task"
}
]
}
,
"182755" : {
"id":182755,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"11",
"type":"Enumeratiewaarde"
}
]
}
,
"182759" : {
"id":182759,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182741" : {
"id":182741,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht Medische verklaring is niet valide",
"type":"End event"
}
]
}
,
"182747" : {
"id":182747,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"182745" : {
"id":182745,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182753" : {
"id":182753,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"182770" : {
"id":182770,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"182720" : {
"id":182720,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"182738" : {
"id":182738,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"182768" : {
"id":182768,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182751" : {
"id":182751,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"182766" : {
"id":182766,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"182732" : {
"id":182732,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht Medische verklaring is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"182772" : {
"id":182772,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"06",
"type":"Enumeratiewaarde"
}
]
}
,
"182716" : {
"id":182716,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"182774" : {
"id":182774,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"14",
"type":"Enumeratiewaarde"
}
]
}
,
"182722" : {
"id":182722,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"37341" : {
"id":37341,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Datatypen",
"type":"Model"
}
]
}
,
"37339" : {
"id":37339,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Codelijsten",
"type":"Model"
}
]
}
,
"182554" : {
"id":182554,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"De regels uit de iWvggz-standaard moeten zowel aan de verzendende- als    de ontvangende zijde worden gecontroleerd (geen conrtole door Vecozo)",
"type":"Tekenvorm"
}
]
}
,
"182553" : {
"id":182553,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182651" : {
"id":182651,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182671" : {
"id":182671,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Psychiatrisch onderzoek uitvoeren",
"type":"Task"
}
]
}
,
"182655" : {
"id":182655,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Lane"
}
]
}
,
"182653" : {
"id":182653,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182645" : {
"id":182645,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182657" : {
"id":182657,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"182665" : {
"id":182665,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht Medische verklaring is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"182667" : {
"id":182667,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medische verklaring opstellen",
"type":"Task"
}
]
}
,
"182669" : {
"id":182669,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medische verklaring verzenden",
"type":"Task"
}
]
}
,
"182672" : {
"id":182672,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"182659" : {
"id":182659,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182661" : {
"id":182661,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182663" : {
"id":182663,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanwijzing GD is ontvangen",
"type":"Start event"
}
]
}
,
"182701" : {
"id":182701,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"182705" : {
"id":182705,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182692" : {
"id":182692,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182704" : {
"id":182704,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"182686" : {
"id":182686,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"182694" : {
"id":182694,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"182702" : {
"id":182702,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"182699" : {
"id":182699,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182703" : {
"id":182703,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"182706" : {
"id":182706,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182708" : {
"id":182708,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182690" : {
"id":182690,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182709" : {
"id":182709,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182693" : {
"id":182693,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"182707" : {
"id":182707,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182710" : {
"id":182710,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182712" : {
"id":182712,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medische verklaring ontvangen",
"type":"Task"
}
]
}
,
"182697" : {
"id":182697,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"114672" : {
"id":114672,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_AfzenderOntvangerIdentificatie",
"type":"Datatype"
}
]
}
,
"114673" : {
"id":114673,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_AfzenderOntvangerType",
"type":"Datatype"
}
]
}
,
"114674" : {
"id":114674,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_PvpCode",
"type":"Datatype"
}
]
}
,
"184695" : {
"id":184695,
"typeIconPath":"data/icons/ArchiMate/CompositeGrouping.png",
"data" : [
{
"name":"iEb",
"type":"Groepering"
}
]
}
,
"184705" : {
"id":184705,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanleveren",
"type":"Lane"
}
]
}
,
"184664" : {
"id":184664,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184666" : {
"id":184666,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184660" : {
"id":184660,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184662" : {
"id":184662,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"GD aanwijzen",
"type":"Task"
}
]
}
,
"184674" : {
"id":184674,
"typeIconPath":"data/icons/ArchiMate/CompositeGrouping.png",
"data" : [
{
"name":"iWmo",
"type":"Groepering"
}
]
}
,
"184702" : {
"id":184702,
"typeIconPath":"data/icons/ArchiMate/CompositeGrouping.png",
"data" : [
{
"name":"iJw",
"type":"Groepering"
}
]
}
,
"184707" : {
"id":184707,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"184770" : {
"id":184770,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184734" : {
"id":184734,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184737" : {
"id":184737,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG108 - Retour bevindingen GD",
"type":"Message"
}
]
}
,
"184729" : {
"id":184729,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Aanlevering gegevens verplichte zorg ontvangen",
"type":"End event"
}
]
}
,
"184748" : {
"id":184748,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Choreography task"
}
]
}
,
"184766" : {
"id":184766,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Mededelen",
"type":"Choreography task"
}
]
}
,
"184744" : {
"id":184744,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184760" : {
"id":184760,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding is gestart",
"type":"End event"
}
]
}
,
"184732" : {
"id":184732,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184736" : {
"id":184736,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184746" : {
"id":184746,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Verzoekschrift is ingediend",
"type":"End event"
}
]
}
,
"184762" : {
"id":184762,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Aanvraag is afgewezen",
"type":"End event"
}
]
}
,
"184772" : {
"id":184772,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184774" : {
"id":184774,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184756" : {
"id":184756,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"184758" : {
"id":184758,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184740" : {
"id":184740,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184752" : {
"id":184752,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"184731" : {
"id":184731,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Aanlevering gegevens verplichte zorg is gestart",
"type":"Start event"
}
]
}
,
"184768" : {
"id":184768,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"184776" : {
"id":184776,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184750" : {
"id":184750,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"184742" : {
"id":184742,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Choreography task"
}
]
}
,
"184738" : {
"id":184738,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG107 - Bevindingen GD",
"type":"Message"
}
]
}
,
"184778" : {
"id":184778,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beoordelen",
"type":"Choreography task"
}
]
}
,
"184727" : {
"id":184727,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanleveren",
"type":"Choreography task"
}
]
}
,
"184764" : {
"id":184764,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding is beeindigd",
"type":"End event"
}
]
}
,
"184754" : {
"id":184754,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184815" : {
"id":184815,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VCM",
"type":"Enumeratiewaarde"
}
]
}
,
"184819" : {
"id":184819,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"PIJ",
"type":"Enumeratiewaarde"
}
]
}
,
"184837" : {
"id":184837,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"184798" : {
"id":184798,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184786" : {
"id":184786,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184802" : {
"id":184802,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184823" : {
"id":184823,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184817" : {
"id":184817,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TBS",
"type":"Enumeratiewaarde"
}
]
}
,
"184821" : {
"id":184821,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ZM",
"type":"Enumeratiewaarde"
}
]
}
,
"184805" : {
"id":184805,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"NOOD",
"type":"Enumeratiewaarde"
}
]
}
,
"184796" : {
"id":184796,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184800" : {
"id":184800,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TEMP",
"type":"Enumeratiewaarde"
}
]
}
,
"184808" : {
"id":184808,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CM",
"type":"Enumeratiewaarde"
}
]
}
,
"184788" : {
"id":184788,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"184826" : {
"id":184826,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184794" : {
"id":184794,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"184792" : {
"id":184792,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanvragen",
"type":"Choreography task"
}
]
}
,
"184830" : {
"id":184830,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VCM",
"type":"Enumeratiewaarde"
}
]
}
,
"184784" : {
"id":184784,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"184810" : {
"id":184810,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ZM",
"type":"Enumeratiewaarde"
}
]
}
,
"184790" : {
"id":184790,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184828" : {
"id":184828,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CM",
"type":"Enumeratiewaarde"
}
]
}
,
"184834" : {
"id":184834,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184780" : {
"id":184780,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184813" : {
"id":184813,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184782" : {
"id":184782,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184848" : {
"id":184848,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"184841" : {
"id":184841,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184845" : {
"id":184845,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"184868" : {
"id":184868,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"184843" : {
"id":184843,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"184875" : {
"id":184875,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Lane"
}
]
}
,
"184929" : {
"id":184929,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"22",
"type":"Enumeratiewaarde"
}
]
}
,
"184927" : {
"id":184927,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184932" : {
"id":184932,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184891" : {
"id":184891,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Opvolgen",
"type":"Lane"
}
]
}
,
"184916" : {
"id":184916,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"21",
"type":"Enumeratiewaarde"
}
]
}
,
"184937" : {
"id":184937,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"184940" : {
"id":184940,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184925" : {
"id":184925,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184919" : {
"id":184919,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"23",
"type":"Enumeratiewaarde"
}
]
}
,
"184922" : {
"id":184922,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"20",
"type":"Enumeratiewaarde"
}
]
}
,
"184935" : {
"id":184935,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"184898" : {
"id":184898,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aavragen",
"type":"Lane"
}
]
}
,
"184963" : {
"id":184963,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"184942" : {
"id":184942,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184965" : {
"id":184965,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184952" : {
"id":184952,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"06",
"type":"Enumeratiewaarde"
}
]
}
,
"184946" : {
"id":184946,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"184955" : {
"id":184955,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184958" : {
"id":184958,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"184960" : {
"id":184960,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184950" : {
"id":184950,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"184948" : {
"id":184948,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"184973" : {
"id":184973,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"185025" : {
"id":185025,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"185028" : {
"id":185028,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"184985" : {
"id":184985,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"184971" : {
"id":184971,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"184969" : {
"id":184969,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"184613" : {
"id":184613,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beslissen",
"type":"Lane"
}
]
}
,
"184563" : {
"id":184563,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184585" : {
"id":184585,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184565" : {
"id":184565,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht Medische Verklaring valide?",
"type":"Gateway"
}
]
}
,
"184615" : {
"id":184615,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184575" : {
"id":184575,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184560" : {
"id":184560,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"184579" : {
"id":184579,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184571" : {
"id":184571,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"184581" : {
"id":184581,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"184555" : {
"id":184555,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"184587" : {
"id":184587,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184583" : {
"id":184583,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184577" : {
"id":184577,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Mededelen",
"type":"Lane"
}
]
}
,
"184594" : {
"id":184594,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medische Verklaring controleren",
"type":"Task"
}
]
}
,
"184558" : {
"id":184558,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184573" : {
"id":184573,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM controleren",
"type":"Task"
}
]
}
,
"184592" : {
"id":184592,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen aanvraag ZM beoordelen",
"type":"Task"
}
]
}
,
"184596" : {
"id":184596,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM Ontvangen",
"type":"Task"
}
]
}
,
"184598" : {
"id":184598,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184604" : {
"id":184604,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medsiche Verklaring ontvangen",
"type":"Task"
}
]
}
,
"184606" : {
"id":184606,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM opstellen",
"type":"Task"
}
]
}
,
"184569" : {
"id":184569,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"184567" : {
"id":184567,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"184590" : {
"id":184590,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanvraag ZM valide?",
"type":"Gateway"
}
]
}
,
"184608" : {
"id":184608,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184610" : {
"id":184610,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184602" : {
"id":184602,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht  bevindingen GD controleren",
"type":"Task"
}
]
}
,
"184632" : {
"id":184632,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184649" : {
"id":184649,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD opstellen",
"type":"Task"
}
]
}
,
"184651" : {
"id":184651,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"184655" : {
"id":184655,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184619" : {
"id":184619,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184657" : {
"id":184657,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184627" : {
"id":184627,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beslissing over voorbereiding of indiening ZM nemen",
"type":"Task"
}
]
}
,
"184640" : {
"id":184640,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD ontvangen",
"type":"Task"
}
]
}
,
"184638" : {
"id":184638,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184623" : {
"id":184623,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"184653" : {
"id":184653,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"184636" : {
"id":184636,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184625" : {
"id":184625,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"184642" : {
"id":184642,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Lane"
}
]
}
,
"184634" : {
"id":184634,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht  Medische Verklaring  is niet valide",
"type":"End event"
}
]
}
,
"184617" : {
"id":184617,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht bevindingen GD valide?",
"type":"Gateway"
}
]
}
,
"184621" : {
"id":184621,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184644" : {
"id":184644,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184646" : {
"id":184646,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"184630" : {
"id":184630,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD is niet valide",
"type":"End event"
}
]
}
,
"184017" : {
"id":184017,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"15",
"type":"Enumeratiewaarde"
}
]
}
,
"183995" : {
"id":183995,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"18",
"type":"Enumeratiewaarde"
}
]
}
,
"184013" : {
"id":184013,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"22",
"type":"Enumeratiewaarde"
}
]
}
,
"183989" : {
"id":183989,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183992" : {
"id":183992,
"typeIconPath":"data/icons/UML/UML_PrimitiveType.png",
"data" : [
{
"name":"date",
"type":"Primitief type"
}
]
}
,
"184041" : {
"id":184041,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"24",
"type":"Enumeratiewaarde"
}
]
}
,
"184003" : {
"id":184003,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"12",
"type":"Enumeratiewaarde"
}
]
}
,
"184021" : {
"id":184021,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184033" : {
"id":184033,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"08",
"type":"Enumeratiewaarde"
}
]
}
,
"184035" : {
"id":184035,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"16",
"type":"Enumeratiewaarde"
}
]
}
,
"184037" : {
"id":184037,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"11",
"type":"Enumeratiewaarde"
}
]
}
,
"184005" : {
"id":184005,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"13",
"type":"Enumeratiewaarde"
}
]
}
,
"184039" : {
"id":184039,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"25",
"type":"Enumeratiewaarde"
}
]
}
,
"184001" : {
"id":184001,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD472: Soort relatie",
"type":"Enumeratie"
}
]
}
,
"183986" : {
"id":183986,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184009" : {
"id":184009,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"19",
"type":"Enumeratiewaarde"
}
]
}
,
"142468" : {
"id":142468,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Processen - oud",
"type":"Totaalview"
}
]
}
,
"183999" : {
"id":183999,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"07",
"type":"Enumeratiewaarde"
}
]
}
,
"184023" : {
"id":184023,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"184027" : {
"id":184027,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"184011" : {
"id":184011,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"09",
"type":"Enumeratiewaarde"
}
]
}
,
"184019" : {
"id":184019,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"06",
"type":"Enumeratiewaarde"
}
]
}
,
"183997" : {
"id":183997,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"184007" : {
"id":184007,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"21",
"type":"Enumeratiewaarde"
}
]
}
,
"184029" : {
"id":184029,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"14",
"type":"Enumeratiewaarde"
}
]
}
,
"184025" : {
"id":184025,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"20",
"type":"Enumeratiewaarde"
}
]
}
,
"184031" : {
"id":184031,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"17",
"type":"Enumeratiewaarde"
}
]
}
,
"184015" : {
"id":184015,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"10",
"type":"Enumeratiewaarde"
}
]
}
,
"184066" : {
"id":184066,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184093" : {
"id":184093,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Plaatsnaam",
"type":"Attribuut"
}
]
}
,
"184103" : {
"id":184103,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"184043" : {
"id":184043,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184101" : {
"id":184101,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"184070" : {
"id":184070,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184078" : {
"id":184078,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Verzoekschrift VCM is ingediend",
"type":"Start event"
}
]
}
,
"184072" : {
"id":184072,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Zorgaanbieder over indiening VCM informeren",
"type":"Task"
}
]
}
,
"184053" : {
"id":184053,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"184080" : {
"id":184080,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht VCM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184074" : {
"id":184074,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht VCM opstellen",
"type":"Task"
}
]
}
,
"184098" : {
"id":184098,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184045" : {
"id":184045,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"23",
"type":"Enumeratiewaarde"
}
]
}
,
"184064" : {
"id":184064,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184082" : {
"id":184082,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_GeslotenPeriode",
"type":"Datatype"
}
]
}
,
"184068" : {
"id":184068,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht VCM verzenden",
"type":"Task"
}
]
}
,
"184048" : {
"id":184048,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184055" : {
"id":184055,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"184091" : {
"id":184091,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Straatnaam",
"type":"Attribuut"
}
]
}
,
"184057" : {
"id":184057,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184060" : {
"id":184060,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"184062" : {
"id":184062,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Mededelen",
"type":"Lane"
}
]
}
,
"184076" : {
"id":184076,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184109" : {
"id":184109,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184150" : {
"id":184150,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0114",
"type":"Enumeratiewaarde"
}
]
}
,
"184152" : {
"id":184152,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0102",
"type":"Enumeratiewaarde"
}
]
}
,
"184156" : {
"id":184156,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0214",
"type":"Enumeratiewaarde"
}
]
}
,
"184158" : {
"id":184158,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0401",
"type":"Enumeratiewaarde"
}
]
}
,
"184111" : {
"id":184111,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"07",
"type":"Enumeratiewaarde"
}
]
}
,
"184160" : {
"id":184160,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0107",
"type":"Enumeratiewaarde"
}
]
}
,
"184115" : {
"id":184115,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"184113" : {
"id":184113,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD736: Grondslag zorg",
"type":"Enumeratie"
}
]
}
,
"184133" : {
"id":184133,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184148" : {
"id":184148,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0113",
"type":"Enumeratiewaarde"
}
]
}
,
"184146" : {
"id":184146,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0410",
"type":"Enumeratiewaarde"
}
]
}
,
"184142" : {
"id":184142,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0104",
"type":"Enumeratiewaarde"
}
]
}
,
"184127" : {
"id":184127,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184162" : {
"id":184162,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD825: Vraag beperking",
"type":"Enumeratie"
}
]
}
,
"184164" : {
"id":184164,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0110",
"type":"Enumeratiewaarde"
}
]
}
,
"184119" : {
"id":184119,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"184121" : {
"id":184121,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184139" : {
"id":184139,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0403",
"type":"Enumeratiewaarde"
}
]
}
,
"184137" : {
"id":184137,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0505",
"type":"Enumeratiewaarde"
}
]
}
,
"184154" : {
"id":184154,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0212",
"type":"Enumeratiewaarde"
}
]
}
,
"184123" : {
"id":184123,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184144" : {
"id":184144,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184135" : {
"id":184135,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0307",
"type":"Enumeratiewaarde"
}
]
}
,
"184107" : {
"id":184107,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"06",
"type":"Enumeratiewaarde"
}
]
}
,
"184117" : {
"id":184117,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"184166" : {
"id":184166,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0301",
"type":"Enumeratiewaarde"
}
]
}
,
"184200" : {
"id":184200,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0108",
"type":"Enumeratiewaarde"
}
]
}
,
"184208" : {
"id":184208,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0103",
"type":"Enumeratiewaarde"
}
]
}
,
"184186" : {
"id":184186,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0205",
"type":"Enumeratiewaarde"
}
]
}
,
"184204" : {
"id":184204,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0607",
"type":"Enumeratiewaarde"
}
]
}
,
"184210" : {
"id":184210,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0506",
"type":"Enumeratiewaarde"
}
]
}
,
"184212" : {
"id":184212,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0202",
"type":"Enumeratiewaarde"
}
]
}
,
"184214" : {
"id":184214,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0209",
"type":"Enumeratiewaarde"
}
]
}
,
"184218" : {
"id":184218,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0208",
"type":"Enumeratiewaarde"
}
]
}
,
"184220" : {
"id":184220,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0302",
"type":"Enumeratiewaarde"
}
]
}
,
"142626" : {
"id":142626,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Regels",
"type":"Totaalview"
}
]
}
,
"184174" : {
"id":184174,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0304",
"type":"Enumeratiewaarde"
}
]
}
,
"184172" : {
"id":184172,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0305",
"type":"Enumeratiewaarde"
}
]
}
,
"184198" : {
"id":184198,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0204",
"type":"Enumeratiewaarde"
}
]
}
,
"184178" : {
"id":184178,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0203",
"type":"Enumeratiewaarde"
}
]
}
,
"184188" : {
"id":184188,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0611",
"type":"Enumeratiewaarde"
}
]
}
,
"184216" : {
"id":184216,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0404",
"type":"Enumeratiewaarde"
}
]
}
,
"184170" : {
"id":184170,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0101",
"type":"Enumeratiewaarde"
}
]
}
,
"184202" : {
"id":184202,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0201",
"type":"Enumeratiewaarde"
}
]
}
,
"184176" : {
"id":184176,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0211",
"type":"Enumeratiewaarde"
}
]
}
,
"184222" : {
"id":184222,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0605",
"type":"Enumeratiewaarde"
}
]
}
,
"184192" : {
"id":184192,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0309",
"type":"Enumeratiewaarde"
}
]
}
,
"184180" : {
"id":184180,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0112",
"type":"Enumeratiewaarde"
}
]
}
,
"184168" : {
"id":184168,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0111",
"type":"Enumeratiewaarde"
}
]
}
,
"184184" : {
"id":184184,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0306",
"type":"Enumeratiewaarde"
}
]
}
,
"184182" : {
"id":184182,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0407",
"type":"Enumeratiewaarde"
}
]
}
,
"142629" : {
"id":142629,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Gegevens",
"type":"Totaalview"
}
]
}
,
"184190" : {
"id":184190,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0502",
"type":"Enumeratiewaarde"
}
]
}
,
"184196" : {
"id":184196,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0604",
"type":"Enumeratiewaarde"
}
]
}
,
"184194" : {
"id":184194,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0206",
"type":"Enumeratiewaarde"
}
]
}
,
"184206" : {
"id":184206,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0405",
"type":"Enumeratiewaarde"
}
]
}
,
"184258" : {
"id":184258,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0402",
"type":"Enumeratiewaarde"
}
]
}
,
"184240" : {
"id":184240,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0408",
"type":"Enumeratiewaarde"
}
]
}
,
"184264" : {
"id":184264,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0601",
"type":"Enumeratiewaarde"
}
]
}
,
"184228" : {
"id":184228,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0105",
"type":"Enumeratiewaarde"
}
]
}
,
"184252" : {
"id":184252,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0409",
"type":"Enumeratiewaarde"
}
]
}
,
"184226" : {
"id":184226,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0406",
"type":"Enumeratiewaarde"
}
]
}
,
"184256" : {
"id":184256,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0609",
"type":"Enumeratiewaarde"
}
]
}
,
"184232" : {
"id":184232,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0109",
"type":"Enumeratiewaarde"
}
]
}
,
"184242" : {
"id":184242,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0504",
"type":"Enumeratiewaarde"
}
]
}
,
"184224" : {
"id":184224,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0303",
"type":"Enumeratiewaarde"
}
]
}
,
"184262" : {
"id":184262,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0501",
"type":"Enumeratiewaarde"
}
]
}
,
"184230" : {
"id":184230,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0213",
"type":"Enumeratiewaarde"
}
]
}
,
"184254" : {
"id":184254,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0411",
"type":"Enumeratiewaarde"
}
]
}
,
"184246" : {
"id":184246,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0503",
"type":"Enumeratiewaarde"
}
]
}
,
"184234" : {
"id":184234,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0210",
"type":"Enumeratiewaarde"
}
]
}
,
"184238" : {
"id":184238,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0207",
"type":"Enumeratiewaarde"
}
]
}
,
"184236" : {
"id":184236,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0106",
"type":"Enumeratiewaarde"
}
]
}
,
"184244" : {
"id":184244,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0603",
"type":"Enumeratiewaarde"
}
]
}
,
"184250" : {
"id":184250,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0602",
"type":"Enumeratiewaarde"
}
]
}
,
"184266" : {
"id":184266,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0610",
"type":"Enumeratiewaarde"
}
]
}
,
"184268" : {
"id":184268,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0308",
"type":"Enumeratiewaarde"
}
]
}
,
"184271" : {
"id":184271,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"142647" : {
"id":142647,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Casuistiek",
"type":"Totaalview"
}
]
}
,
"184248" : {
"id":184248,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0606",
"type":"Enumeratiewaarde"
}
]
}
,
"184260" : {
"id":184260,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0608",
"type":"Enumeratiewaarde"
}
]
}
,
"184299" : {
"id":184299,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184319" : {
"id":184319,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bevindingen op uitgangspunten beoordelen",
"type":"Task"
}
]
}
,
"184325" : {
"id":184325,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"ZM nav VCM is niet aangevraagd",
"type":"End event"
}
]
}
,
"184328" : {
"id":184328,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Bericht VCM is ontvangen",
"type":"Start event"
}
]
}
,
"184330" : {
"id":184330,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184322" : {
"id":184322,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184303" : {
"id":184303,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184308" : {
"id":184308,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184341" : {
"id":184341,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184314" : {
"id":184314,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184344" : {
"id":184344,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht Persoonsgegevens betrokkene valide?",
"type":"Gateway"
}
]
}
,
"184316" : {
"id":184316,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD verzenden",
"type":"Task"
}
]
}
,
"184317" : {
"id":184317,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184311" : {
"id":184311,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"184318" : {
"id":184318,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanwijzing GD is ontvangen",
"type":"Start event"
}
]
}
,
"184320" : {
"id":184320,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"184321" : {
"id":184321,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"ZM nav VCM aanvragen?",
"type":"Gateway"
}
]
}
,
"184323" : {
"id":184323,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD opstellen",
"type":"Task"
}
]
}
,
"184324" : {
"id":184324,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"184326" : {
"id":184326,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184315" : {
"id":184315,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht bevindingen GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184327" : {
"id":184327,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184385" : {
"id":184385,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Persoonsgegevens betrokkene ontvangen",
"type":"Task"
}
]
}
,
"184358" : {
"id":184358,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184366" : {
"id":184366,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Stichting PVP",
"type":"Pool"
}
]
}
,
"184382" : {
"id":184382,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"184348" : {
"id":184348,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Pool"
}
]
}
,
"184400" : {
"id":184400,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Persoonsgegevens betrokkene controleren",
"type":"Task"
}
]
}
,
"184364" : {
"id":184364,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184379" : {
"id":184379,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184354" : {
"id":184354,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"184388" : {
"id":184388,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene ontvangen",
"type":"End event"
}
]
}
,
"184368" : {
"id":184368,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184370" : {
"id":184370,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"184376" : {
"id":184376,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184391" : {
"id":184391,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht Persoonsgegevens betrokkene is niet valide",
"type":"End event"
}
]
}
,
"184394" : {
"id":184394,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht Persoonsgegevens betrokkene is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184373" : {
"id":184373,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht Persoonsgegevens betrokkene verzenden",
"type":"Task"
}
]
}
,
"184397" : {
"id":184397,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"184437" : {
"id":184437,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184428" : {
"id":184428,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184440" : {
"id":184440,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM verzenden",
"type":"Task"
}
]
}
,
"184443" : {
"id":184443,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht bevindingen GD verzenden",
"type":"Task"
}
]
}
,
"184433" : {
"id":184433,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184434" : {
"id":184434,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD verzenden",
"type":"Task"
}
]
}
,
"184445" : {
"id":184445,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184442" : {
"id":184442,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184446" : {
"id":184446,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht beslissing  voorbereiding of indiening ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184444" : {
"id":184444,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour bevindingen GD ()",
"type":"Message"
}
]
}
,
"184436" : {
"id":184436,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184406" : {
"id":184406,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"184425" : {
"id":184425,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184423" : {
"id":184423,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM verzenden",
"type":"Task"
}
]
}
,
"184419" : {
"id":184419,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184421" : {
"id":184421,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Bevindingen GD ()",
"type":"Message"
}
]
}
,
"184420" : {
"id":184420,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184424" : {
"id":184424,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing voorbereiding of indiening ZM ()",
"type":"Message"
}
]
}
,
"184427" : {
"id":184427,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Medische Verklaring ()",
"type":"Message"
}
]
}
,
"184429" : {
"id":184429,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184430" : {
"id":184430,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanvraag ZM ()",
"type":"Message"
}
]
}
,
"184431" : {
"id":184431,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"184432" : {
"id":184432,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Pool"
}
]
}
,
"184435" : {
"id":184435,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanwijzing GD ()",
"type":"Message"
}
]
}
,
"184426" : {
"id":184426,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht Medische Verklaring is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"184439" : {
"id":184439,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184441" : {
"id":184441,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanvraag ZM ()",
"type":"Message"
}
]
}
,
"184422" : {
"id":184422,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184438" : {
"id":184438,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanwijzing GD ()",
"type":"Message"
}
]
}
,
"184468" : {
"id":184468,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184502" : {
"id":184502,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184503" : {
"id":184503,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184450" : {
"id":184450,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour Medische Verklaring ()",
"type":"Message"
}
]
}
,
"184471" : {
"id":184471,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"184504" : {
"id":184504,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184505" : {
"id":184505,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184449" : {
"id":184449,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht Medische Verklaring verzenden",
"type":"Task"
}
]
}
,
"184464" : {
"id":184464,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184460" : {
"id":184460,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184477" : {
"id":184477,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184482" : {
"id":184482,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184486" : {
"id":184486,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184494" : {
"id":184494,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184495" : {
"id":184495,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184506" : {
"id":184506,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184507" : {
"id":184507,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184481" : {
"id":184481,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184452" : {
"id":184452,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Resource role"
}
]
}
,
"184462" : {
"id":184462,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"184488" : {
"id":184488,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184490" : {
"id":184490,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184456" : {
"id":184456,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgverlener",
"type":"Resource role"
}
]
}
,
"184499" : {
"id":184499,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184508" : {
"id":184508,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184489" : {
"id":184489,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184498" : {
"id":184498,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184484" : {
"id":184484,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184454" : {
"id":184454,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Geneesheer-directeur",
"type":"Resource role"
}
]
}
,
"184448" : {
"id":184448,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"184466" : {
"id":184466,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184470" : {
"id":184470,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184473" : {
"id":184473,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184474" : {
"id":184474,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184483" : {
"id":184483,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184487" : {
"id":184487,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184492" : {
"id":184492,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184493" : {
"id":184493,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184447" : {
"id":184447,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing voorbereiding of indiening ZM ()",
"type":"Message"
}
]
}
,
"184496" : {
"id":184496,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184485" : {
"id":184485,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184479" : {
"id":184479,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184497" : {
"id":184497,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184500" : {
"id":184500,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184501" : {
"id":184501,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184457" : {
"id":184457,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184512" : {
"id":184512,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184519" : {
"id":184519,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184510" : {
"id":184510,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184544" : {
"id":184544,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"184509" : {
"id":184509,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184520" : {
"id":184520,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184528" : {
"id":184528,
"typeIconPath":"data/icons/ArchiMate/TriggeringRelation.png",
"data" : [
{
"name":"Triggeringrelatie",
"type":"Triggeringrelatie"
}
]
}
,
"184551" : {
"id":184551,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"184513" : {
"id":184513,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184553" : {
"id":184553,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM is niet valide",
"type":"End event"
}
]
}
,
"184549" : {
"id":184549,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"184515" : {
"id":184515,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184521" : {
"id":184521,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184514" : {
"id":184514,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184511" : {
"id":184511,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184517" : {
"id":184517,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184516" : {
"id":184516,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184522" : {
"id":184522,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184524" : {
"id":184524,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184523" : {
"id":184523,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"184547" : {
"id":184547,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"184526" : {
"id":184526,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184518" : {
"id":184518,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"184525" : {
"id":184525,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190486" : {
"id":190486,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190483" : {
"id":190483,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190489" : {
"id":190489,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190487" : {
"id":190487,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190491" : {
"id":190491,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190515" : {
"id":190515,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190503" : {
"id":190503,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190493" : {
"id":190493,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190498" : {
"id":190498,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190506" : {
"id":190506,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190510" : {
"id":190510,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190495" : {
"id":190495,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190512" : {
"id":190512,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190514" : {
"id":190514,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190505" : {
"id":190505,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190499" : {
"id":190499,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190508" : {
"id":190508,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190502" : {
"id":190502,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190521" : {
"id":190521,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190535" : {
"id":190535,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190526" : {
"id":190526,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190523" : {
"id":190523,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190529" : {
"id":190529,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190530" : {
"id":190530,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190533" : {
"id":190533,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190532" : {
"id":190532,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190517" : {
"id":190517,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190518" : {
"id":190518,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190537" : {
"id":190537,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190538" : {
"id":190538,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190550" : {
"id":190550,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190540" : {
"id":190540,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190543" : {
"id":190543,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190547" : {
"id":190547,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190551" : {
"id":190551,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190545" : {
"id":190545,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"34217" : {
"id":34217,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"OPN_ACCOMMODATIE",
"type":"Enumeratiewaarde"
}
]
}
,
"192153" : {
"id":192153,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP607: De iWvggz ondersteunt het volgen van een aanvraag voor een zorgmachtiging, vanaf de aanvraag tot en met de beslissing.",
"type":"Principe"
}
]
}
,
"192193" : {
"id":192193,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"192194" : {
"id":192194,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"182037" : {
"id":182037,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Tussen beoordelen en onderzoeken",
"type":"Tekenvorm"
}
]
}
,
"182038" : {
"id":182038,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Tussen beoordelen en onderzoeken",
"type":"Tekenvorm"
}
]
}
,
"182097" : {
"id":182097,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182075" : {
"id":182075,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"182098" : {
"id":182098,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Verzoekschrift VCM is ingediend",
"type":"Start event"
}
]
}
,
"182069" : {
"id":182069,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanvragen",
"type":"Choreography task"
}
]
}
,
"182076" : {
"id":182076,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"182090" : {
"id":182090,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Aanvragen ZM is gestart",
"type":"Start event"
}
]
}
,
"182073" : {
"id":182073,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182086" : {
"id":182086,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Pool"
}
]
}
,
"182088" : {
"id":182088,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182099" : {
"id":182099,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182100" : {
"id":182100,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182067" : {
"id":182067,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182063" : {
"id":182063,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182101" : {
"id":182101,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182080" : {
"id":182080,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"182093" : {
"id":182093,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"182066" : {
"id":182066,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Pool"
}
]
}
,
"182085" : {
"id":182085,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"182087" : {
"id":182087,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182071" : {
"id":182071,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Pool"
}
]
}
,
"182096" : {
"id":182096,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Verzoekschrift is ingediend",
"type":"End event"
}
]
}
,
"182061" : {
"id":182061,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182077" : {
"id":182077,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Choreography task"
}
]
}
,
"182079" : {
"id":182079,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Aanvrager",
"type":"Pool"
}
]
}
,
"182072" : {
"id":182072,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"182082" : {
"id":182082,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182062" : {
"id":182062,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Conform de regels van de iWvggz-standaard",
"type":"Tekenvorm"
}
]
}
,
"182074" : {
"id":182074,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182078" : {
"id":182078,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beslissen",
"type":"Choreography task"
}
]
}
,
"182083" : {
"id":182083,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"182089" : {
"id":182089,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182064" : {
"id":182064,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Choreography task"
}
]
}
,
"182068" : {
"id":182068,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182092" : {
"id":182092,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"ZM nav VCM aanvragen?",
"type":"Gateway"
}
]
}
,
"182095" : {
"id":182095,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182081" : {
"id":182081,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"182084" : {
"id":182084,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beoordelen",
"type":"Choreography task"
}
]
}
,
"182091" : {
"id":182091,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182065" : {
"id":182065,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"182094" : {
"id":182094,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"ZM nav VCM is niet aangevraagd",
"type":"End event"
}
]
}
,
"182070" : {
"id":182070,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Mededelen",
"type":"Choreography task"
}
]
}
,
"182109" : {
"id":182109,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182106" : {
"id":182106,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182107" : {
"id":182107,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Aanvraag is afgewezen",
"type":"End event"
}
]
}
,
"182124" : {
"id":182124,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"182141" : {
"id":182141,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"182102" : {
"id":182102,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182126" : {
"id":182126,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182132" : {
"id":182132,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182104" : {
"id":182104,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182113" : {
"id":182113,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182163" : {
"id":182163,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanwijzing ontvangen",
"type":"Lane"
}
]
}
,
"182108" : {
"id":182108,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182115" : {
"id":182115,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182139" : {
"id":182139,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aavragen",
"type":"Lane"
}
]
}
,
"182117" : {
"id":182117,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"182103" : {
"id":182103,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"182128" : {
"id":182128,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD170: Datumgebruik",
"type":"Enumeratie"
}
]
}
,
"182134" : {
"id":182134,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"182105" : {
"id":182105,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Voorbereiding ZM ambsthalve door OvJ gestart",
"type":"Start event"
}
]
}
,
"182110" : {
"id":182110,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding is beeindigd",
"type":"End event"
}
]
}
,
"182121" : {
"id":182121,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"182130" : {
"id":182130,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"182169" : {
"id":182169,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen beslissing",
"type":"Lane"
}
]
}
,
"182195" : {
"id":182195,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Lane"
}
]
}
,
"182179" : {
"id":182179,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"182251" : {
"id":182251,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Voorvoegsel",
"type":"Attribuut"
}
]
}
,
"182258" : {
"id":182258,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Geneesheer-directeur",
"type":"Resource role"
}
]
}
,
"182265" : {
"id":182265,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"182260" : {
"id":182260,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgverlener",
"type":"Resource role"
}
]
}
,
"182271" : {
"id":182271,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Mededelen",
"type":"Lane"
}
]
}
,
"182280" : {
"id":182280,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"182254" : {
"id":182254,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Achternaam",
"type":"Attribuut"
}
]
}
,
"182256" : {
"id":182256,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Resource role"
}
]
}
,
"182300" : {
"id":182300,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Lane"
}
]
}
,
"182313" : {
"id":182313,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beslissen",
"type":"Lane"
}
]
}
,
"182402" : {
"id":182402,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182403" : {
"id":182403,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Conform de regels van de iWvggz-standaarden",
"type":"Tekenvorm"
}
]
}
,
"182461" : {
"id":182461,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181286" : {
"id":181286,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding ZM gestopt",
"type":"End event"
}
]
}
,
"181292" : {
"id":181292,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Aanvraag ZM afgewezen?",
"type":"Gateway"
}
]
}
,
"181313" : {
"id":181313,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Persoonsgegevens betrokkene verzenden",
"type":"Task"
}
]
}
,
"181315" : {
"id":181315,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"181337" : {
"id":181337,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"181330" : {
"id":181330,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding is gestart",
"type":"End event"
}
]
}
,
"181341" : {
"id":181341,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181302" : {
"id":181302,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"181289" : {
"id":181289,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181297" : {
"id":181297,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181305" : {
"id":181305,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Verzoekschrift wordt ingediend",
"type":"End event"
}
]
}
,
"181307" : {
"id":181307,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181311" : {
"id":181311,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181321" : {
"id":181321,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181342" : {
"id":181342,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht MV opstellen",
"type":"Task"
}
]
}
,
"181340" : {
"id":181340,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"181344" : {
"id":181344,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD ontvangen",
"type":"Task"
}
]
}
,
"181335" : {
"id":181335,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD controleren",
"type":"Task"
}
]
}
,
"181301" : {
"id":181301,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181327" : {
"id":181327,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181291" : {
"id":181291,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181304" : {
"id":181304,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181309" : {
"id":181309,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht Persoonsgegevens betrokkene is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"181294" : {
"id":181294,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181323" : {
"id":181323,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Persoonsgegevens betrokkene opstellen",
"type":"Task"
}
]
}
,
"181325" : {
"id":181325,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Verstrekken  persoonsgegevens betrokkene is gestart",
"type":"Start event"
}
]
}
,
"181300" : {
"id":181300,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181329" : {
"id":181329,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"181334" : {
"id":181334,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181332" : {
"id":181332,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"ZM aanvragen",
"type":"Task"
}
]
}
,
"181333" : {
"id":181333,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM opstellen",
"type":"Task"
}
]
}
,
"181296" : {
"id":181296,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanvragen",
"type":"Choreography task"
}
]
}
,
"181288" : {
"id":181288,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beslissen",
"type":"Choreography task"
}
]
}
,
"181336" : {
"id":181336,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181338" : {
"id":181338,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181339" : {
"id":181339,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanwijzing GD valide?",
"type":"Gateway"
}
]
}
,
"181343" : {
"id":181343,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181345" : {
"id":181345,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181290" : {
"id":181290,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Choreography task"
}
]
}
,
"181293" : {
"id":181293,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181317" : {
"id":181317,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Persoonsgegevens verstrekken",
"type":"Task"
}
]
}
,
"181319" : {
"id":181319,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Versterkken",
"type":"Lane"
}
]
}
,
"181287" : {
"id":181287,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181283" : {
"id":181283,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beoordelen",
"type":"Choreography task"
}
]
}
,
"181328" : {
"id":181328,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181331" : {
"id":181331,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181346" : {
"id":181346,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD opstellen",
"type":"Task"
}
]
}
,
"181284" : {
"id":181284,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181295" : {
"id":181295,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"181285" : {
"id":181285,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Besloten tot indienen verzoekschrift?",
"type":"Gateway"
}
]
}
,
"181298" : {
"id":181298,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181299" : {
"id":181299,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Choreography task"
}
]
}
,
"181303" : {
"id":181303,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181409" : {
"id":181409,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht bevindingen GD",
"type":"Task"
}
]
}
,
"181382" : {
"id":181382,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"181400" : {
"id":181400,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Aanvraag afgewezen",
"type":"End event"
}
]
}
,
"181408" : {
"id":181408,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht bevindingen GD",
"type":"Task"
}
]
}
,
"181360" : {
"id":181360,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181407" : {
"id":181407,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181410" : {
"id":181410,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181404" : {
"id":181404,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181349" : {
"id":181349,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181356" : {
"id":181356,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181370" : {
"id":181370,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding  of indiening ZM niet valide",
"type":"End event"
}
]
}
,
"181405" : {
"id":181405,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"181357" : {
"id":181357,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding is beeindigd",
"type":"End event"
}
]
}
,
"181365" : {
"id":181365,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM ontvangen",
"type":"Task"
}
]
}
,
"181373" : {
"id":181373,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181383" : {
"id":181383,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181389" : {
"id":181389,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181387" : {
"id":181387,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanwijzing GD valide?",
"type":"Gateway"
}
]
}
,
"181366" : {
"id":181366,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181362" : {
"id":181362,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181388" : {
"id":181388,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"181385" : {
"id":181385,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"181393" : {
"id":181393,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"181401" : {
"id":181401,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181350" : {
"id":181350,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181364" : {
"id":181364,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181367" : {
"id":181367,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181391" : {
"id":181391,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"181390" : {
"id":181390,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"181392" : {
"id":181392,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181354" : {
"id":181354,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Pva, zorgplan en/of zorgkaart beoordelen",
"type":"Task"
}
]
}
,
"181377" : {
"id":181377,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181358" : {
"id":181358,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181394" : {
"id":181394,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht aanwijzing GD",
"type":"Task"
}
]
}
,
"181398" : {
"id":181398,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding beeindigd",
"type":"End event"
}
]
}
,
"181396" : {
"id":181396,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht beslissing tav aanvraag / voorbereiding ZM",
"type":"Task"
}
]
}
,
"181355" : {
"id":181355,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181368" : {
"id":181368,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM controleren",
"type":"Task"
}
]
}
,
"181363" : {
"id":181363,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181371" : {
"id":181371,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181351" : {
"id":181351,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181359" : {
"id":181359,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding  of indiening ZM valide?",
"type":"Gateway"
}
]
}
,
"181361" : {
"id":181361,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Aanvraag is afgewezen",
"type":"End event"
}
]
}
,
"181348" : {
"id":181348,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Psychiatrisch onderzoek uitvoeren",
"type":"Task"
}
]
}
,
"181374" : {
"id":181374,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181378" : {
"id":181378,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht  beslissing tav aanvraag / voorbereiding ZM",
"type":"Task"
}
]
}
,
"181379" : {
"id":181379,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht beslissing tav aanvraag / voorbereiding ZM",
"type":"Task"
}
]
}
,
"181380" : {
"id":181380,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181381" : {
"id":181381,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht beslissing tav  aanvraag / voorbereiding ZM valide?",
"type":"Gateway"
}
]
}
,
"181399" : {
"id":181399,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181402" : {
"id":181402,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"181384" : {
"id":181384,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM ontvangen",
"type":"Intermediate event"
}
]
}
,
"181352" : {
"id":181352,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Verzoekschrift is ingediend",
"type":"End event"
}
]
}
,
"181395" : {
"id":181395,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181403" : {
"id":181403,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanvragen ZM",
"type":"Task"
}
]
}
,
"181369" : {
"id":181369,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181375" : {
"id":181375,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181406" : {
"id":181406,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181372" : {
"id":181372,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181386" : {
"id":181386,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181353" : {
"id":181353,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181397" : {
"id":181397,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181376" : {
"id":181376,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD is niet valide",
"type":"End event"
}
]
}
,
"181347" : {
"id":181347,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181434" : {
"id":181434,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour MV",
"type":"Message"
}
]
}
,
"181452" : {
"id":181452,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"181459" : {
"id":181459,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"181460" : {
"id":181460,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181433" : {
"id":181433,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht MV ontvangen",
"type":"Intermediate event"
}
]
}
,
"181463" : {
"id":181463,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181465" : {
"id":181465,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181467" : {
"id":181467,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"181471" : {
"id":181471,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding is gestart",
"type":"End event"
}
]
}
,
"181469" : {
"id":181469,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181472" : {
"id":181472,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181468" : {
"id":181468,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181453" : {
"id":181453,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181473" : {
"id":181473,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanvragen",
"type":"Choreography task"
}
]
}
,
"181444" : {
"id":181444,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"181474" : {
"id":181474,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"181428" : {
"id":181428,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht beslissing tav  aanvraag / voorbereiding niet valide",
"type":"End event"
}
]
}
,
"181426" : {
"id":181426,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht beslissing tav indienen verzoekschrift ontvangen",
"type":"Intermediate event"
}
]
}
,
"181411" : {
"id":181411,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Verzoekschrift ingediend",
"type":"End event"
}
]
}
,
"181420" : {
"id":181420,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181413" : {
"id":181413,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beoordelen Pva, zorgplan en zorgkaart",
"type":"Task"
}
]
}
,
"181423" : {
"id":181423,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181436" : {
"id":181436,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"MV",
"type":"Message"
}
]
}
,
"181462" : {
"id":181462,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"181412" : {
"id":181412,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181464" : {
"id":181464,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181466" : {
"id":181466,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181470" : {
"id":181470,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Mededelen",
"type":"Choreography task"
}
]
}
,
"181419" : {
"id":181419,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181421" : {
"id":181421,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181430" : {
"id":181430,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181440" : {
"id":181440,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing tav aanvraag / voorbereiding ZM",
"type":"Message"
}
]
}
,
"181425" : {
"id":181425,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181432" : {
"id":181432,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181418" : {
"id":181418,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht bevindingen GD  ontvangen",
"type":"Intermediate event"
}
]
}
,
"181442" : {
"id":181442,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour bevindingen GD",
"type":"Message"
}
]
}
,
"181443" : {
"id":181443,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Bevindingen GD",
"type":"Message"
}
]
}
,
"181437" : {
"id":181437,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing tav aanvraag / voorbereiding ZM",
"type":"Message"
}
]
}
,
"181422" : {
"id":181422,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181431" : {
"id":181431,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD niet valide",
"type":"End event"
}
]
}
,
"181451" : {
"id":181451,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"181429" : {
"id":181429,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181457" : {
"id":181457,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181461" : {
"id":181461,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"181439" : {
"id":181439,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanwijzing GD",
"type":"Message"
}
]
}
,
"181427" : {
"id":181427,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181448" : {
"id":181448,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181417" : {
"id":181417,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181435" : {
"id":181435,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanvraag ZM",
"type":"Message"
}
]
}
,
"181414" : {
"id":181414,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181441" : {
"id":181441,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanvraag ZM",
"type":"Message"
}
]
}
,
"181438" : {
"id":181438,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanwijzing GD",
"type":"Message"
}
]
}
,
"181424" : {
"id":181424,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht MV",
"type":"Task"
}
]
}
,
"181416" : {
"id":181416,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht MV",
"type":"Task"
}
]
}
,
"181455" : {
"id":181455,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181445" : {
"id":181445,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS023: Maximale lengte 35 posities",
"type":"Beperking"
}
]
}
,
"181415" : {
"id":181415,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Uitvoeren psychiatrisch onderzoek",
"type":"Task"
}
]
}
,
"181478" : {
"id":181478,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181498" : {
"id":181498,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181528" : {
"id":181528,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM opstellen",
"type":"Task"
}
]
}
,
"181486" : {
"id":181486,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181494" : {
"id":181494,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181487" : {
"id":181487,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181520" : {
"id":181520,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181516" : {
"id":181516,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181530" : {
"id":181530,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM verzenden",
"type":"Task"
}
]
}
,
"181532" : {
"id":181532,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Medische verklaring is ontvangen",
"type":"Start event"
}
]
}
,
"181533" : {
"id":181533,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"181484" : {
"id":181484,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"181535" : {
"id":181535,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181491" : {
"id":181491,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181477" : {
"id":181477,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Aanvraag is afgewezen",
"type":"End event"
}
]
}
,
"181506" : {
"id":181506,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181489" : {
"id":181489,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"181502" : {
"id":181502,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beslissen",
"type":"Lane"
}
]
}
,
"181508" : {
"id":181508,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Bevindingen GD is ontvangen",
"type":"Start event"
}
]
}
,
"181512" : {
"id":181512,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181481" : {
"id":181481,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"181483" : {
"id":181483,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181504" : {
"id":181504,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht beslissing voorbereiding of indiening ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"181510" : {
"id":181510,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanvraag ZM is ontvangen",
"type":"Start event"
}
]
}
,
"181480" : {
"id":181480,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181514" : {
"id":181514,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181493" : {
"id":181493,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding is beeindigd",
"type":"End event"
}
]
}
,
"181482" : {
"id":181482,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Choreography task"
}
]
}
,
"181518" : {
"id":181518,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Aanvraag ZM afwijzen?",
"type":"Gateway"
}
]
}
,
"181522" : {
"id":181522,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding ZM is gestart",
"type":"End event"
}
]
}
,
"181524" : {
"id":181524,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beslissing over voorbereiding of indiening ZM nemen",
"type":"Task"
}
]
}
,
"181526" : {
"id":181526,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181479" : {
"id":181479,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beoordelen",
"type":"Choreography task"
}
]
}
,
"181485" : {
"id":181485,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Choreography task"
}
]
}
,
"181490" : {
"id":181490,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181495" : {
"id":181495,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Verzoekschrift is ingediend",
"type":"End event"
}
]
}
,
"181500" : {
"id":181500,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"181492" : {
"id":181492,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181475" : {
"id":181475,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181488" : {
"id":181488,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181476" : {
"id":181476,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181540" : {
"id":181540,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Opvolgen",
"type":"Lane"
}
]
}
,
"181544" : {
"id":181544,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"181572" : {
"id":181572,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aavragen",
"type":"Lane"
}
]
}
,
"181594" : {
"id":181594,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"181577" : {
"id":181577,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"181550" : {
"id":181550,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Lane"
}
]
}
,
"181622" : {
"id":181622,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"181625" : {
"id":181625,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beslissen",
"type":"Lane"
}
]
}
,
"181713" : {
"id":181713,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Lane"
}
]
}
,
"181738" : {
"id":181738,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"In behandeling nemen",
"type":"Lane"
}
]
}
,
"181786" : {
"id":181786,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beoordelen",
"type":"Lane"
}
]
}
,
"181758" : {
"id":181758,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"181761" : {
"id":181761,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aavragen",
"type":"Lane"
}
]
}
,
"181840" : {
"id":181840,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Opvolgen",
"type":"Lane"
}
]
}
,
"181801" : {
"id":181801,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Lane"
}
]
}
,
"181820" : {
"id":181820,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Kennisnemen",
"type":"Lane"
}
]
}
,
"181865" : {
"id":181865,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Conform de regels van de iWvggz-standaard",
"type":"Tekenvorm"
}
]
}
,
"181866" : {
"id":181866,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181893" : {
"id":181893,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Resource role"
}
]
}
,
"181864" : {
"id":181864,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"181897" : {
"id":181897,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Geneesheer-directeur",
"type":"Resource role"
}
]
}
,
"181895" : {
"id":181895,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgverlener",
"type":"Resource role"
}
]
}
,
"178258" : {
"id":178258,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178275" : {
"id":178275,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Huisletter",
"type":"Datatype"
}
]
}
,
"178260" : {
"id":178260,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR611: Soort moet overeenkomen met het soort document dat als Bestand is opgenomen.",
"type":"Beperking"
}
]
}
,
"178261" : {
"id":178261,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178251" : {
"id":178251,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178264" : {
"id":178264,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"ZmAanvraag",
"type":"Klasse"
}
]
}
,
"178253" : {
"id":178253,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG103",
"type":"Klasse"
}
]
}
,
"178262" : {
"id":178262,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178266" : {
"id":178266,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178268" : {
"id":178268,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS600: OrganisatieSoort bij Afzender vullen met '01' (Openbaar ministerie)",
"type":"Beperking"
}
]
}
,
"178250" : {
"id":178250,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Koppeling uitgangspunten",
"type":"Totaalview"
}
]
}
,
"178267" : {
"id":178267,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178270" : {
"id":178270,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178259" : {
"id":178259,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Soort",
"type":"Attribuut"
}
]
}
,
"178263" : {
"id":178263,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS604: OrganisatieSoort bij Ontvanger vullen met '03' (IGJ)",
"type":"Beperking"
}
]
}
,
"178271" : {
"id":178271,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178272" : {
"id":178272,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"VerleendeVerplichteZorg",
"type":"Klasse"
}
]
}
,
"178273" : {
"id":178273,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR101: Binnen een bestand zijn dubbele regels niet toegestaan.",
"type":"Beperking"
}
]
}
,
"178252" : {
"id":178252,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG107",
"type":"Klasse"
}
]
}
,
"178274" : {
"id":178274,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS033: Geen lege elementen in XML.",
"type":"Beperking"
}
]
}
,
"178265" : {
"id":178265,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"AanvraagVoortgezetteCm",
"type":"Klasse"
}
]
}
,
"178276" : {
"id":178276,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178277" : {
"id":178277,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BerichtSubversie",
"type":"Datatype"
}
]
}
,
"178295" : {
"id":178295,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG111",
"type":"Klasse"
}
]
}
,
"178278" : {
"id":178278,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS001: Minimale waarde 0",
"type":"Beperking"
}
]
}
,
"178301" : {
"id":178301,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG109",
"type":"Klasse"
}
]
}
,
"178304" : {
"id":178304,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178306" : {
"id":178306,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178308" : {
"id":178308,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178300" : {
"id":178300,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178303" : {
"id":178303,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Persoonsid",
"type":"Datatype"
}
]
}
,
"178287" : {
"id":178287,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Percentage",
"type":"Datatype"
}
]
}
,
"178307" : {
"id":178307,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG105",
"type":"Klasse"
}
]
}
,
"178309" : {
"id":178309,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_IdentificatieBericht",
"type":"Datatype"
}
]
}
,
"178296" : {
"id":178296,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP615x1: Het bericht Persoonsgegevens betrokkene bevat of het BRP-adres of het verblijfsadres van de betrokkene.",
"type":"Requirement"
}
]
}
,
"178298" : {
"id":178298,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Land",
"type":"Attribuut"
}
]
}
,
"178313" : {
"id":178313,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178315" : {
"id":178315,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR608: Er moet een Bijlage voorkomen waarin Soort de waarde 051, 053 of 054 heeft.",
"type":"Beperking"
}
]
}
,
"178318" : {
"id":178318,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178282" : {
"id":178282,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178286" : {
"id":178286,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178302" : {
"id":178302,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178293" : {
"id":178293,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178299" : {
"id":178299,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG101",
"type":"Klasse"
}
]
}
,
"178319" : {
"id":178319,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178292" : {
"id":178292,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces over voorbereiding ZM beslissen",
"type":"Collaboration"
}
]
}
,
"178294" : {
"id":178294,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178297" : {
"id":178297,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178314" : {
"id":178314,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Verklaring",
"type":"Klasse"
}
]
}
,
"178305" : {
"id":178305,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9611",
"type":"Enumeratiewaarde"
}
]
}
,
"178321" : {
"id":178321,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV603: Hoe moet Bijlage gevuld worden?",
"type":"Usecase"
}
]
}
,
"178335" : {
"id":178335,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178354" : {
"id":178354,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"BetrokkenePVP",
"type":"Klasse"
}
]
}
,
"178356" : {
"id":178356,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178357" : {
"id":178357,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Postcode",
"type":"Attribuut"
}
]
}
,
"178355" : {
"id":178355,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR617: Bij een betrokkene moet minimaal een BetrokkeneAdres opgenomen zijn waarvan Adressoort de waarde 01 (BRP-adres) of 03 (Verblijfadres) heeft.",
"type":"Beperking"
}
]
}
,
"178324" : {
"id":178324,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS064: Vullen met een bestaande datum die niet in de toekomst ligt.",
"type":"Beperking"
}
]
}
,
"178361" : {
"id":178361,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"178362" : {
"id":178362,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178322" : {
"id":178322,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178352" : {
"id":178352,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_IdentificatieBericht",
"type":"Klassendiagram"
}
]
}
,
"178358" : {
"id":178358,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178359" : {
"id":178359,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_IdentificatieBericht",
"type":"Datatype"
}
]
}
,
"178360" : {
"id":178360,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178345" : {
"id":178345,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS024: Maximale lengte 36 posities",
"type":"Beperking"
}
]
}
,
"178336" : {
"id":178336,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS009: Maximale lengte 2 posities",
"type":"Beperking"
}
]
}
,
"178327" : {
"id":178327,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_StatusAanlevering",
"type":"Klassendiagram"
}
]
}
,
"178323" : {
"id":178323,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Dagtekening",
"type":"Attribuut"
}
]
}
,
"178333" : {
"id":178333,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178328" : {
"id":178328,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS035: Vullen met 4 cijfers.",
"type":"Beperking"
}
]
}
,
"178329" : {
"id":178329,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0001",
"type":"Enumeratiewaarde"
}
]
}
,
"178343" : {
"id":178343,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS008: Maximale lengte 1 positie",
"type":"Beperking"
}
]
}
,
"178344" : {
"id":178344,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178346" : {
"id":178346,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Identificatie",
"type":"Attribuut"
}
]
}
,
"178340" : {
"id":178340,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178348" : {
"id":178348,
"typeIconPath":"data/icons/UML/UMLMM_Model.png",
"data" : [
{
"name":"Oude scripts UML",
"type":"UML-model"
}
]
}
,
"178334" : {
"id":178334,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Nadeel",
"type":"Klasse"
}
]
}
,
"178349" : {
"id":178349,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS037: Vullen met 9 cijfers.",
"type":"Beperking"
}
]
}
,
"178342" : {
"id":178342,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178353" : {
"id":178353,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178332" : {
"id":178332,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_DatumTijd",
"type":"Klassendiagram"
}
]
}
,
"178320" : {
"id":178320,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Bijlage",
"type":"Klasse"
}
]
}
,
"178341" : {
"id":178341,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS012: Maximale lengte 5 posities",
"type":"Beperking"
}
]
}
,
"178366" : {
"id":178366,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS005: Aaneengesloten vullen met cijfers.",
"type":"Beperking"
}
]
}
,
"178383" : {
"id":178383,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Huisnummer",
"type":"Attribuut"
}
]
}
,
"178404" : {
"id":178404,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178370" : {
"id":178370,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Organisatie",
"type":"Attribuut"
}
]
}
,
"178377" : {
"id":178377,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178369" : {
"id":178369,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178386" : {
"id":178386,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces gegevens geleverde verplichte zorg aanleveren",
"type":"Collaboration"
}
]
}
,
"178382" : {
"id":178382,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178401" : {
"id":178401,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS300: Vullen met een bestaande gemeentecode uit het overzicht van CBS.",
"type":"Beperking"
}
]
}
,
"178363" : {
"id":178363,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS044: Maximale waarde 225 posities",
"type":"Beperking"
}
]
}
,
"178392" : {
"id":178392,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Begindatum",
"type":"Attribuut"
}
]
}
,
"178405" : {
"id":178405,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Aanlevering",
"type":"Klasse"
}
]
}
,
"178372" : {
"id":178372,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178381" : {
"id":178381,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Invulinstructies",
"type":"Totaalview"
}
]
}
,
"178396" : {
"id":178396,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Communicatievorm",
"type":"Datatype"
}
]
}
,
"178365" : {
"id":178365,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Telefoonnummer",
"type":"Datatype"
}
]
}
,
"178402" : {
"id":178402,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178371" : {
"id":178371,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV002: Hoe om te gaan met de adressering indien er sprake is van een organisatie?",
"type":"Usecase"
}
]
}
,
"178391" : {
"id":178391,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178378" : {
"id":178378,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS002: De waarde moet voldoen aan de 11-proef.",
"type":"Beperking"
}
]
}
,
"178375" : {
"id":178375,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178394" : {
"id":178394,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Aanleiding",
"type":"Attribuut"
}
]
}
,
"178395" : {
"id":178395,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV601: Hoe moet Aanleiding gevuld worden?",
"type":"Usecase"
}
]
}
,
"178399" : {
"id":178399,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process"
}
]
}
,
"178387" : {
"id":178387,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178403" : {
"id":178403,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS036: Vullen met 8 cijfers.",
"type":"Beperking"
}
]
}
,
"178390" : {
"id":178390,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"CD generiek",
"type":"Totaalview"
}
]
}
,
"178393" : {
"id":178393,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178400" : {
"id":178400,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178376" : {
"id":178376,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS023: Vullen met een bestaande datum die niet groter is dan de Dagtekening van het bestand.",
"type":"Beperking"
}
]
}
,
"178364" : {
"id":178364,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178413" : {
"id":178413,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration"
}
]
}
,
"178423" : {
"id":178423,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR101: Binnen een bestand zijn dubbele regels niet toegestaan.",
"type":"Beperking"
}
]
}
,
"178406" : {
"id":178406,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178420" : {
"id":178420,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR097: Voor Geboortedatum geldt dat DatumGebruik en Datum met elkaar in overeenstemming moeten zijn.",
"type":"Beperking"
}
]
}
,
"178426" : {
"id":178426,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Taal",
"type":"Attribuut"
}
]
}
,
"178441" : {
"id":178441,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process"
}
]
}
,
"178427" : {
"id":178427,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD007: Als Communicatie / Vorm de waarde 1 (tolk taal) heeft, dan verplicht vullen, anders leeglaten.",
"type":"Beperking"
}
]
}
,
"178432" : {
"id":178432,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178446" : {
"id":178446,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178422" : {
"id":178422,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV604: Hoe moet omgegaan worden met moment- vs duurregistratie",
"type":"Usecase"
}
]
}
,
"178433" : {
"id":178433,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178421" : {
"id":178421,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178431" : {
"id":178431,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS028: Maximale lengte 200 posities",
"type":"Beperking"
}
]
}
,
"178415" : {
"id":178415,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Plaatsnaam",
"type":"Attribuut"
}
]
}
,
"178409" : {
"id":178409,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS019: Maximale lengte 20 posities",
"type":"Beperking"
}
]
}
,
"178414" : {
"id":178414,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178434" : {
"id":178434,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS108: Vullen met een waarde die groter is dan, of gelijk is aan de Begindatum van de aangeduide periode én die niet groter is dan de Dagtekening van het bericht.",
"type":"Beperking"
}
]
}
,
"178407" : {
"id":178407,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178425" : {
"id":178425,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178447" : {
"id":178447,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV602: Hoe moet AanvraagNummer gevuld worden in een AanwijzingGD?",
"type":"Usecase"
}
]
}
,
"178408" : {
"id":178408,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178438" : {
"id":178438,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Versie",
"type":"Klassendiagram"
}
]
}
,
"178410" : {
"id":178410,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178416" : {
"id":178416,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178417" : {
"id":178417,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Identificatie",
"type":"Attribuut"
}
]
}
,
"178418" : {
"id":178418,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR616: Identificatie moet per verzonden iWvggz bericht uniek zijn voor de verzendende partij.",
"type":"Beperking"
}
]
}
,
"178435" : {
"id":178435,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Einddatum",
"type":"Attribuut"
}
]
}
,
"178424" : {
"id":178424,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Relatie",
"type":"Klasse"
}
]
}
,
"178419" : {
"id":178419,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178430" : {
"id":178430,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR600: Als AmbsthalveAangewezenIndicatie de waarde 2 (nee) bevat, dan moet ZmAanvraagNummer voorkomen in een eerder bericht Aanvraag zorgmachtiging.",
"type":"Beperking"
}
]
}
,
"178428" : {
"id":178428,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178429" : {
"id":178429,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZmAanvraagNummer",
"type":"Attribuut"
}
]
}
,
"178463" : {
"id":178463,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178464" : {
"id":178464,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS605: OrganisatieSoort bij Ontvanger vullen met '04' (Stichting PVP)",
"type":"Beperking"
}
]
}
,
"178479" : {
"id":178479,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178481" : {
"id":178481,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BerichtCode",
"type":"Datatype"
}
]
}
,
"178484" : {
"id":178484,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178485" : {
"id":178485,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BerichtVersie",
"type":"Datatype"
}
]
}
,
"178462" : {
"id":178462,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178486" : {
"id":178486,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178457" : {
"id":178457,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178451" : {
"id":178451,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS023: Vullen met een bestaande datum die niet groter is dan de Dagtekening van het bericht.",
"type":"Beperking"
}
]
}
,
"178472" : {
"id":178472,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178468" : {
"id":178468,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG113",
"type":"Klasse"
}
]
}
,
"178474" : {
"id":178474,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178458" : {
"id":178458,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Betrokkene",
"type":"Klasse"
}
]
}
,
"178478" : {
"id":178478,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS010: Maximale lengte 3 posities",
"type":"Beperking"
}
]
}
,
"178448" : {
"id":178448,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Straatnaam",
"type":"Datatype"
}
]
}
,
"178454" : {
"id":178454,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"ZM voorbereiden",
"type":"Choreography"
}
]
}
,
"178487" : {
"id":178487,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178459" : {
"id":178459,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178449" : {
"id":178449,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178477" : {
"id":178477,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178456" : {
"id":178456,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS014: Maximale lengte 8 posities",
"type":"Beperking"
}
]
}
,
"178465" : {
"id":178465,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178469" : {
"id":178469,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS013: Maximale lengte 6 posities",
"type":"Beperking"
}
]
}
,
"178473" : {
"id":178473,
"typeIconPath":"data/icons/ArchiMate/BusinessObject.png",
"data" : [
{
"name":"Basisregistratie Personen",
"type":"Bedrijfsobject"
}
]
}
,
"178450" : {
"id":178450,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ondertekeningsdatum",
"type":"Attribuut"
}
]
}
,
"178466" : {
"id":178466,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178467" : {
"id":178467,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9600",
"type":"Enumeratiewaarde"
}
]
}
,
"178475" : {
"id":178475,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS017: Maximale lengte 12 posities",
"type":"Beperking"
}
]
}
,
"178476" : {
"id":178476,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178480" : {
"id":178480,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS126: Vullen met BerichtCode volgens de specificatie",
"type":"Beperking"
}
]
}
,
"178455" : {
"id":178455,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178489" : {
"id":178489,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178492" : {
"id":178492,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Bevindingen",
"type":"Klasse"
}
]
}
,
"178514" : {
"id":178514,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"178521" : {
"id":178521,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178524" : {
"id":178524,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178502" : {
"id":178502,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178495" : {
"id":178495,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Commentaar",
"type":"Datatype"
}
]
}
,
"178493" : {
"id":178493,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR603: Als Aanleiding de waarde 01 (Reguliere ZM) heeft, dient een BelastZorgaanbieder aanwezig te zijn, anders niet.",
"type":"Beperking"
}
]
}
,
"178522" : {
"id":178522,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZmAanvraagNummer",
"type":"Attribuut"
}
]
}
,
"178488" : {
"id":178488,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178507" : {
"id":178507,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178530" : {
"id":178530,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BerichtCode",
"type":"Klassendiagram"
}
]
}
,
"178531" : {
"id":178531,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178496" : {
"id":178496,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS031: Commentaarvelden niet leeg.",
"type":"Beperking"
}
]
}
,
"178504" : {
"id":178504,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178497" : {
"id":178497,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178498" : {
"id":178498,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Wvg retour",
"type":"Klasse"
}
]
}
,
"178490" : {
"id":178490,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Motivering",
"type":"Attribuut"
}
]
}
,
"178508" : {
"id":178508,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9601",
"type":"Enumeratiewaarde"
}
]
}
,
"178494" : {
"id":178494,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178503" : {
"id":178503,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR615: Er moet een Bijlage voorkomen waarin Soort de waarde 053 of 054 heeft.",
"type":"Beperking"
}
]
}
,
"178510" : {
"id":178510,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ondertekeningsdatum",
"type":"Attribuut"
}
]
}
,
"178506" : {
"id":178506,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR601: ZmAanvraagNummer moet voorkomen in een eerder bericht Aanwijzing GD.",
"type":"Beperking"
}
]
}
,
"178515" : {
"id":178515,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178516" : {
"id":178516,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZmAanvraagNummer",
"type":"Attribuut"
}
]
}
,
"178517" : {
"id":178517,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178518" : {
"id":178518,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Emailadres",
"type":"Datatype"
}
]
}
,
"178519" : {
"id":178519,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178523" : {
"id":178523,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR609: ZmAanvraag heeft een uniek ZmAanvraagNummer.",
"type":"Beperking"
}
]
}
,
"178526" : {
"id":178526,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Postcode",
"type":"Attribuut"
}
]
}
,
"178505" : {
"id":178505,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZmAanvraagNummer",
"type":"Attribuut"
}
]
}
,
"178501" : {
"id":178501,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178513" : {
"id":178513,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178527" : {
"id":178527,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD034: Als Soort adres de waarde 1 (BRP-adres) of 3 (verblijfadres) heeft, dan verplicht vullen.",
"type":"Beperking"
}
]
}
,
"178525" : {
"id":178525,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178520" : {
"id":178520,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR605: Er moet een Bijlage voorkomen waarin Soort de waarde 007 heeft.",
"type":"Beperking"
}
]
}
,
"178499" : {
"id":178499,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV028: Hoe wordt een retourbericht opgesteld?",
"type":"Usecase"
}
]
}
,
"178509" : {
"id":178509,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178491" : {
"id":178491,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178546" : {
"id":178546,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS005: Maximale waarde 99999999 (8*9)",
"type":"Beperking"
}
]
}
,
"178556" : {
"id":178556,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"178559" : {
"id":178559,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178562" : {
"id":178562,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"NaamGebruik",
"type":"Attribuut"
}
]
}
,
"178542" : {
"id":178542,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178536" : {
"id":178536,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178551" : {
"id":178551,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"178566" : {
"id":178566,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS128: Vullen met een versienummer bestaande uit drie gehele getallen, gescheiden met punten.",
"type":"Beperking"
}
]
}
,
"178548" : {
"id":178548,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"AanwijzingGD",
"type":"Klasse"
}
]
}
,
"178555" : {
"id":178555,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178573" : {
"id":178573,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178535" : {
"id":178535,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178537" : {
"id":178537,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178554" : {
"id":178554,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV606: Hoe moet BetrokkeneAdres gevuld worden?",
"type":"Usecase"
}
]
}
,
"178557" : {
"id":178557,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS015: BerichtSubversie vullen met 0.",
"type":"Beperking"
}
]
}
,
"178563" : {
"id":178563,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS050: Als Partnernaam gevuld is, dan NaamGebruik vullen met waarde 1, 2, 3 of 4. Anders waarde 1 vullen.",
"type":"Beperking"
}
]
}
,
"178547" : {
"id":178547,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178543" : {
"id":178543,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"178558" : {
"id":178558,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178541" : {
"id":178541,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Motivering",
"type":"Attribuut"
}
]
}
,
"178552" : {
"id":178552,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178560" : {
"id":178560,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"BetrokkeneIGJ",
"type":"Klasse"
}
]
}
,
"178539" : {
"id":178539,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS043: DatumTijd vullen zonder tijdzone",
"type":"Beperking"
}
]
}
,
"178561" : {
"id":178561,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178565" : {
"id":178565,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178550" : {
"id":178550,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178544" : {
"id":178544,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV007: Hoe wordt de naam van een client of relatie vastgelegd?`",
"type":"Usecase"
}
]
}
,
"178540" : {
"id":178540,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178549" : {
"id":178549,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR606: Er moet een Bijlage voorkomen waarin Soort de waarde 009 heeft.",
"type":"Beperking"
}
]
}
,
"178553" : {
"id":178553,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"BetrokkeneAdres",
"type":"Klasse"
}
]
}
,
"178545" : {
"id":178545,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178564" : {
"id":178564,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178538" : {
"id":178538,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_DatumTijd",
"type":"Datatype"
}
]
}
,
"178532" : {
"id":178532,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Dagtekening",
"type":"Attribuut"
}
]
}
,
"178598" : {
"id":178598,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS011: Maximale lengte 4 posities",
"type":"Beperking"
}
]
}
,
"178608" : {
"id":178608,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178591" : {
"id":178591,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178607" : {
"id":178607,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Constraints",
"type":"Totaalview"
}
]
}
,
"178578" : {
"id":178578,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178589" : {
"id":178589,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"178590" : {
"id":178590,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR612: Naam moet overeenkomen met de naam van het document dat als Bestand is opgenomen",
"type":"Beperking"
}
]
}
,
"178584" : {
"id":178584,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178588" : {
"id":178588,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178601" : {
"id":178601,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV009: Hoe moet worden omgegaan met een geboortedatum?",
"type":"Usecase"
}
]
}
,
"178602" : {
"id":178602,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178574" : {
"id":178574,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Straatnaam",
"type":"Attribuut"
}
]
}
,
"178609" : {
"id":178609,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Client",
"type":"Klasse"
}
]
}
,
"178586" : {
"id":178586,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178613" : {
"id":178613,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsltVersie",
"type":"Attribuut"
}
]
}
,
"178610" : {
"id":178610,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178614" : {
"id":178614,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV033: Hoe moet XsltVersie gevuld worden?",
"type":"Usecase"
}
]
}
,
"178599" : {
"id":178599,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178583" : {
"id":178583,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178579" : {
"id":178579,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"178595" : {
"id":178595,
"typeIconPath":"data/icons/UML/UML_PrimitiveType.png",
"data" : [
{
"name":"string",
"type":"Primitief type"
}
]
}
,
"178577" : {
"id":178577,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BerichtType",
"type":"Datatype"
}
]
}
,
"178600" : {
"id":178600,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178603" : {
"id":178603,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"EinddatumTijd",
"type":"Attribuut"
}
]
}
,
"178604" : {
"id":178604,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS026: Maximale lengte 80 posities",
"type":"Beperking"
}
]
}
,
"178582" : {
"id":178582,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboortedatum",
"type":"Attribuut"
}
]
}
,
"178594" : {
"id":178594,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178611" : {
"id":178611,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Taal",
"type":"Datatype"
}
]
}
,
"178612" : {
"id":178612,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178575" : {
"id":178575,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178580" : {
"id":178580,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS025: BerichtVersie vullen met 1.",
"type":"Beperking"
}
]
}
,
"178597" : {
"id":178597,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178576" : {
"id":178576,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178593" : {
"id":178593,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"VoorstelVerplichteZorg",
"type":"Klasse"
}
]
}
,
"178596" : {
"id":178596,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS007: Minimale lengte 1 positie",
"type":"Beperking"
}
]
}
,
"178592" : {
"id":178592,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178581" : {
"id":178581,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178587" : {
"id":178587,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS002: Maximale waarde 99",
"type":"Beperking"
}
]
}
,
"178585" : {
"id":178585,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Landnummer",
"type":"Datatype"
}
]
}
,
"178646" : {
"id":178646,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process"
}
]
}
,
"178653" : {
"id":178653,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178628" : {
"id":178628,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178656" : {
"id":178656,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178643" : {
"id":178643,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtXsdVersie",
"type":"Attribuut"
}
]
}
,
"178642" : {
"id":178642,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV034: Hoe moet XsdVersie gevuld worden?",
"type":"Usecase"
}
]
}
,
"178649" : {
"id":178649,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178618" : {
"id":178618,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178621" : {
"id":178621,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178620" : {
"id":178620,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS003: Indien van toepassing vullen met een waarde die groter is dan, of gelijk is aan de Begindatum (of Ingangsdatum) van de aangeduide periode.",
"type":"Beperking"
}
]
}
,
"178624" : {
"id":178624,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Adres",
"type":"Datatype"
}
]
}
,
"178637" : {
"id":178637,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR607: Er moet een Bijlage voorkomen waarin Soort de waarde 032 heeft.",
"type":"Beperking"
}
]
}
,
"178631" : {
"id":178631,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS601: OrganisatieSoort bij Afzender vullen met '02' (Zorgaanbieder)",
"type":"Beperking"
}
]
}
,
"178650" : {
"id":178650,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Constraints - CS Gedeeld Wlz-Wmo-Jw",
"type":"Motivatie-elementen"
}
]
}
,
"178651" : {
"id":178651,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178634" : {
"id":178634,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178619" : {
"id":178619,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Einddatum",
"type":"Attribuut"
}
]
}
,
"178629" : {
"id":178629,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178659" : {
"id":178659,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178648" : {
"id":178648,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS089: Als LandCode de waarde NL (Nederland) heeft, dan moet het formaat overeenkomen met dat van een Nederlandse postcode.",
"type":"Beperking"
}
]
}
,
"178622" : {
"id":178622,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS021: Maximale lengte 25 posities",
"type":"Beperking"
}
]
}
,
"178640" : {
"id":178640,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process"
}
]
}
,
"178623" : {
"id":178623,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178636" : {
"id":178636,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178635" : {
"id":178635,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR602: Als Aanleiding de waarde 01 (Reguliere ZM) heeft, dan dient ZmAanvraagNummer voor te komen in een bericht Aanwijzing GD.",
"type":"Beperking"
}
]
}
,
"178626" : {
"id":178626,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178641" : {
"id":178641,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178627" : {
"id":178627,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS602: OrganisatieSoort bij Ontvanger vullen met '01' (Openbaar ministerie)",
"type":"Beperking"
}
]
}
,
"178647" : {
"id":178647,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178652" : {
"id":178652,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS004: Maximale waarde 99999 (5*9)",
"type":"Beperking"
}
]
}
,
"178630" : {
"id":178630,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178625" : {
"id":178625,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178690" : {
"id":178690,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Organisatie",
"type":"Attribuut"
}
]
}
,
"178663" : {
"id":178663,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178683" : {
"id":178683,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178671" : {
"id":178671,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Aanvraagdatum",
"type":"Attribuut"
}
]
}
,
"178675" : {
"id":178675,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178676" : {
"id":178676,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178679" : {
"id":178679,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_StatusAanlevering",
"type":"Datatype"
}
]
}
,
"178687" : {
"id":178687,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178680" : {
"id":178680,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178662" : {
"id":178662,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources"
}
]
}
,
"178696" : {
"id":178696,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178697" : {
"id":178697,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Aanwijsdatum",
"type":"Attribuut"
}
]
}
,
"178698" : {
"id":178698,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178669" : {
"id":178669,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178672" : {
"id":178672,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178666" : {
"id":178666,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178678" : {
"id":178678,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178677" : {
"id":178677,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178681" : {
"id":178681,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Datum",
"type":"Datatype"
}
]
}
,
"178684" : {
"id":178684,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178682" : {
"id":178682,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS032: Datum vullen zonder tijdzone.",
"type":"Beperking"
}
]
}
,
"178667" : {
"id":178667,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178668" : {
"id":178668,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BasisschemaXsdVersie",
"type":"Attribuut"
}
]
}
,
"178686" : {
"id":178686,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"WVG115",
"type":"Klasse"
}
]
}
,
"178685" : {
"id":178685,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178688" : {
"id":178688,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178689" : {
"id":178689,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178670" : {
"id":178670,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178693" : {
"id":178693,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces GD aanwijzen",
"type":"Collaboration"
}
]
}
,
"178694" : {
"id":178694,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178695" : {
"id":178695,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9609",
"type":"Enumeratiewaarde"
}
]
}
,
"178702" : {
"id":178702,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR610: Formaat moet overeenkomen het het documentformaat van het Bestand.",
"type":"Beperking"
}
]
}
,
"178711" : {
"id":178711,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS603: OrganisatieSoort bij Ontvanger vullen met '02' (Zorgaanbieder)",
"type":"Beperking"
}
]
}
,
"178712" : {
"id":178712,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178713" : {
"id":178713,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_JaNee",
"type":"Datatype"
}
]
}
,
"178706" : {
"id":178706,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Oude scripts Archimate",
"type":"ArchiMate-model"
}
]
}
,
"178710" : {
"id":178710,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178729" : {
"id":178729,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178735" : {
"id":178735,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178737" : {
"id":178737,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178704" : {
"id":178704,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZMOndertekeningsdatum",
"type":"Attribuut"
}
]
}
,
"178709" : {
"id":178709,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178730" : {
"id":178730,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR097: Voor een Geboortedatum geldt dat DatumGebruik en Datum met elkaar in overeenstemming moeten zijn.",
"type":"Beperking"
}
]
}
,
"178707" : {
"id":178707,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178738" : {
"id":178738,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178703" : {
"id":178703,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178739" : {
"id":178739,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178717" : {
"id":178717,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178740" : {
"id":178740,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZmAanvraagNummer",
"type":"Attribuut"
}
]
}
,
"178741" : {
"id":178741,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV600: Hoe kan het bericht Bevindingen GD gebruikt worden?",
"type":"Usecase"
}
]
}
,
"178736" : {
"id":178736,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV032: Welke retourcode moet gevuld worden in het retourbericht?",
"type":"Usecase"
}
]
}
,
"178701" : {
"id":178701,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9610",
"type":"Enumeratiewaarde"
}
]
}
,
"178733" : {
"id":178733,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178715" : {
"id":178715,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"178718" : {
"id":178718,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178714" : {
"id":178714,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178700" : {
"id":178700,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178716" : {
"id":178716,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV605: Hoe moet de header worden gevuld?",
"type":"Usecase"
}
]
}
,
"178734" : {
"id":178734,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178699" : {
"id":178699,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Versie",
"type":"Datatype"
}
]
}
,
"178776" : {
"id":178776,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178768" : {
"id":178768,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178762" : {
"id":178762,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178778" : {
"id":178778,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD025: Als Adres / LandCode de waarde NL (Nederland) heeft, dan verplicht vullen.",
"type":"Beperking"
}
]
}
,
"178760" : {
"id":178760,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178747" : {
"id":178747,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"178774" : {
"id":178774,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"Berichten werkwijze",
"type":"Klassendiagram"
}
]
}
,
"178761" : {
"id":178761,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178744" : {
"id":178744,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Versie",
"type":"Attribuut"
}
]
}
,
"178751" : {
"id":178751,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Telefoonnummers",
"type":"Datatype"
}
]
}
,
"178777" : {
"id":178777,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Huis",
"type":"Attribuut"
}
]
}
,
"178779" : {
"id":178779,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178748" : {
"id":178748,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178752" : {
"id":178752,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178754" : {
"id":178754,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD005: Als Postcode gevuld is, dan verplicht vullen, anders leeg laten.",
"type":"Beperking"
}
]
}
,
"178769" : {
"id":178769,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178780" : {
"id":178780,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Plaatsnaam",
"type":"Datatype"
}
]
}
,
"178749" : {
"id":178749,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Formaat",
"type":"Attribuut"
}
]
}
,
"178746" : {
"id":178746,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178745" : {
"id":178745,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CS606: Vullen met een versienummer bestaande uit twee gehele getallen, gescheiden met een punt.",
"type":"Beperking"
}
]
}
,
"178742" : {
"id":178742,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP047: Als een bericht niet aan de geldende standaard voldoet, mag het bericht afgekeurd worden.",
"type":"Requirement"
}
]
}
,
"178750" : {
"id":178750,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178753" : {
"id":178753,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"LandCode",
"type":"Attribuut"
}
]
}
,
"178757" : {
"id":178757,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_BerichtIdentificatie",
"type":"Klassendiagram"
}
]
}
,
"178765" : {
"id":178765,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178743" : {
"id":178743,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178770" : {
"id":178770,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178764" : {
"id":178764,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"178763" : {
"id":178763,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"178794" : {
"id":178794,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Postcode",
"type":"Datatype"
}
]
}
,
"178782" : {
"id":178782,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Huisnummer",
"type":"Datatype"
}
]
}
,
"178810" : {
"id":178810,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Vul-, label- en controlescripts",
"type":"Totaalview"
}
]
}
,
"178811" : {
"id":178811,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS006: Maximale waarde 999999999 (9*9)",
"type":"Beperking"
}
]
}
,
"178795" : {
"id":178795,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Nummer",
"type":"Datatype"
}
]
}
,
"178801" : {
"id":178801,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process"
}
]
}
,
"178802" : {
"id":178802,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Stoornis",
"type":"Klasse"
}
]
}
,
"178786" : {
"id":178786,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Technische regels",
"type":"Totaalview"
}
]
}
,
"178804" : {
"id":178804,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"StoornisScore",
"type":"Klasse"
}
]
}
,
"178789" : {
"id":178789,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178790" : {
"id":178790,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_AdresSoort",
"type":"Datatype"
}
]
}
,
"178791" : {
"id":178791,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_AanduidingWoonadres",
"type":"Datatype"
}
]
}
,
"178798" : {
"id":178798,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Relatie",
"type":"Klasse"
}
]
}
,
"178803" : {
"id":178803,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_HuisnummerToevoeging",
"type":"Datatype"
}
]
}
,
"178796" : {
"id":178796,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Contact",
"type":"Klasse"
}
]
}
,
"178797" : {
"id":178797,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Contact",
"type":"Klasse"
}
]
}
,
"178783" : {
"id":178783,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS020: Maximale lengte 24 posities",
"type":"Beperking"
}
]
}
,
"178817" : {
"id":178817,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR614: Er moet een Bijlage voorkomen waarin Soort de waarde 090 heeft.",
"type":"Beperking"
}
]
}
,
"178826" : {
"id":178826,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources"
}
]
}
,
"178836" : {
"id":178836,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources"
}
]
}
,
"178823" : {
"id":178823,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS015: Maximale lengte 9 posities",
"type":"Beperking"
}
]
}
,
"178816" : {
"id":178816,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_XsdVersie",
"type":"Klassendiagram"
}
]
}
,
"178839" : {
"id":178839,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BerichtSubversie",
"type":"Klassendiagram"
}
]
}
,
"178830" : {
"id":178830,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Werkwijze processen",
"type":"Totaalview"
}
]
}
,
"178833" : {
"id":178833,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography"
}
]
}
,
"178842" : {
"id":178842,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Codelijst",
"type":"Totaalview"
}
]
}
,
"178870" : {
"id":178870,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Tijd",
"type":"Datatype"
}
]
}
,
"178853" : {
"id":178853,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process"
}
]
}
,
"178875" : {
"id":178875,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Werkwijze regels",
"type":"Totaalview"
}
]
}
,
"178868" : {
"id":178868,
"typeIconPath":"data/icons/ArchiMate/AllExtendedView.png",
"data" : [
{
"name":"Genereer documentatie scripts",
"type":"Totaalview uitgebreid"
}
]
}
,
"178872" : {
"id":178872,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Client",
"type":"Klasse"
}
]
}
,
"178864" : {
"id":178864,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178858" : {
"id":178858,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_LandCode",
"type":"Datatype"
}
]
}
,
"178861" : {
"id":178861,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources"
}
]
}
,
"178865" : {
"id":178865,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Beperking",
"type":"Klasse"
}
]
}
,
"178848" : {
"id":178848,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS018: Maximale lengte 15 posities",
"type":"Beperking"
}
]
}
,
"178869" : {
"id":178869,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS034: Tijd vullen zonder tijdszone.",
"type":"Beperking"
}
]
}
,
"178847" : {
"id":178847,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"ZM voorbereiden - Procesmodel",
"type":"Collaboration"
}
]
}
,
"178871" : {
"id":178871,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Client",
"type":"Klasse"
}
]
}
,
"178892" : {
"id":178892,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Aanvrager",
"type":"Process"
}
]
}
,
"178898" : {
"id":178898,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"TR generiek",
"type":"Totaalview"
}
]
}
,
"178893" : {
"id":178893,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9602",
"type":"Enumeratiewaarde"
}
]
}
,
"178906" : {
"id":178906,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"Toezicht houden",
"type":"Choreography"
}
]
}
,
"178901" : {
"id":178901,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process"
}
]
}
,
"178889" : {
"id":178889,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS016: Maximale lengte 10 posities",
"type":"Beperking"
}
]
}
,
"178885" : {
"id":178885,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178888" : {
"id":178888,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_UUID",
"type":"Klassendiagram"
}
]
}
,
"178880" : {
"id":178880,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"190993" : {
"id":190993,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1002",
"type":"Enumeratiewaarde"
}
]
}
,
"190992" : {
"id":190992,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2200",
"type":"Enumeratiewaarde"
}
]
}
,
"190994" : {
"id":190994,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1220",
"type":"Enumeratiewaarde"
}
]
}
,
"190995" : {
"id":190995,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0770",
"type":"Enumeratiewaarde"
}
]
}
,
"190991" : {
"id":190991,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S122",
"type":"Enumeratiewaarde"
}
]
}
,
"190987" : {
"id":190987,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0310",
"type":"Enumeratiewaarde"
}
]
}
,
"190990" : {
"id":190990,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0383",
"type":"Enumeratiewaarde"
}
]
}
,
"190989" : {
"id":190989,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3200",
"type":"Enumeratiewaarde"
}
]
}
,
"190988" : {
"id":190988,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1119",
"type":"Enumeratiewaarde"
}
]
}
,
"190986" : {
"id":190986,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0820",
"type":"Enumeratiewaarde"
}
]
}
,
"191008" : {
"id":191008,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0026",
"type":"Enumeratiewaarde"
}
]
}
,
"191009" : {
"id":191009,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0310",
"type":"Enumeratiewaarde"
}
]
}
,
"190996" : {
"id":190996,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0428",
"type":"Enumeratiewaarde"
}
]
}
,
"191006" : {
"id":191006,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0011",
"type":"Enumeratiewaarde"
}
]
}
,
"191000" : {
"id":191000,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"14",
"type":"Enumeratiewaarde"
}
]
}
,
"191010" : {
"id":191010,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0312",
"type":"Enumeratiewaarde"
}
]
}
,
"191011" : {
"id":191011,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0350",
"type":"Enumeratiewaarde"
}
]
}
,
"191012" : {
"id":191012,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0351",
"type":"Enumeratiewaarde"
}
]
}
,
"191014" : {
"id":191014,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0387",
"type":"Enumeratiewaarde"
}
]
}
,
"191015" : {
"id":191015,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0388",
"type":"Enumeratiewaarde"
}
]
}
,
"191007" : {
"id":191007,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0025",
"type":"Enumeratiewaarde"
}
]
}
,
"191013" : {
"id":191013,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0354",
"type":"Enumeratiewaarde"
}
]
}
,
"190998" : {
"id":190998,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S300",
"type":"Enumeratiewaarde"
}
]
}
,
"191004" : {
"id":191004,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1920",
"type":"Enumeratiewaarde"
}
]
}
,
"191016" : {
"id":191016,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0397",
"type":"Enumeratiewaarde"
}
]
}
,
"191017" : {
"id":191017,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0398",
"type":"Enumeratiewaarde"
}
]
}
,
"191018" : {
"id":191018,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0399",
"type":"Enumeratiewaarde"
}
]
}
,
"191019" : {
"id":191019,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0403",
"type":"Enumeratiewaarde"
}
]
}
,
"191020" : {
"id":191020,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0404",
"type":"Enumeratiewaarde"
}
]
}
,
"190997" : {
"id":190997,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0402",
"type":"Enumeratiewaarde"
}
]
}
,
"190999" : {
"id":190999,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"191001" : {
"id":191001,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"82",
"type":"Enumeratiewaarde"
}
]
}
,
"191002" : {
"id":191002,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0800",
"type":"Enumeratiewaarde"
}
]
}
,
"191003" : {
"id":191003,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1100",
"type":"Enumeratiewaarde"
}
]
}
,
"191005" : {
"id":191005,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0010",
"type":"Enumeratiewaarde"
}
]
}
,
"191042" : {
"id":191042,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1065",
"type":"Enumeratiewaarde"
}
]
}
,
"191069" : {
"id":191069,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1213",
"type":"Enumeratiewaarde"
}
]
}
,
"191030" : {
"id":191030,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0452",
"type":"Enumeratiewaarde"
}
]
}
,
"191075" : {
"id":191075,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8901",
"type":"Enumeratiewaarde"
}
]
}
,
"191080" : {
"id":191080,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9058",
"type":"Enumeratiewaarde"
}
]
}
,
"191081" : {
"id":191081,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9086",
"type":"Enumeratiewaarde"
}
]
}
,
"191070" : {
"id":191070,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1214",
"type":"Enumeratiewaarde"
}
]
}
,
"191082" : {
"id":191082,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D041",
"type":"Enumeratiewaarde"
}
]
}
,
"191053" : {
"id":191053,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1143",
"type":"Enumeratiewaarde"
}
]
}
,
"191045" : {
"id":191045,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1089",
"type":"Enumeratiewaarde"
}
]
}
,
"191026" : {
"id":191026,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0426",
"type":"Enumeratiewaarde"
}
]
}
,
"191031" : {
"id":191031,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0540",
"type":"Enumeratiewaarde"
}
]
}
,
"191062" : {
"id":191062,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1190",
"type":"Enumeratiewaarde"
}
]
}
,
"191066" : {
"id":191066,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1208",
"type":"Enumeratiewaarde"
}
]
}
,
"191073" : {
"id":191073,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4703",
"type":"Enumeratiewaarde"
}
]
}
,
"191078" : {
"id":191078,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8906",
"type":"Enumeratiewaarde"
}
]
}
,
"191043" : {
"id":191043,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1075",
"type":"Enumeratiewaarde"
}
]
}
,
"191054" : {
"id":191054,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1145",
"type":"Enumeratiewaarde"
}
]
}
,
"191038" : {
"id":191038,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1000",
"type":"Enumeratiewaarde"
}
]
}
,
"191057" : {
"id":191057,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1173",
"type":"Enumeratiewaarde"
}
]
}
,
"191083" : {
"id":191083,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D044",
"type":"Enumeratiewaarde"
}
]
}
,
"191021" : {
"id":191021,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0406",
"type":"Enumeratiewaarde"
}
]
}
,
"191029" : {
"id":191029,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0430",
"type":"Enumeratiewaarde"
}
]
}
,
"191037" : {
"id":191037,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0806",
"type":"Enumeratiewaarde"
}
]
}
,
"191023" : {
"id":191023,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0409",
"type":"Enumeratiewaarde"
}
]
}
,
"191036" : {
"id":191036,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0803",
"type":"Enumeratiewaarde"
}
]
}
,
"191050" : {
"id":191050,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1120",
"type":"Enumeratiewaarde"
}
]
}
,
"191052" : {
"id":191052,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1124",
"type":"Enumeratiewaarde"
}
]
}
,
"191040" : {
"id":191040,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1062",
"type":"Enumeratiewaarde"
}
]
}
,
"191058" : {
"id":191058,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1174",
"type":"Enumeratiewaarde"
}
]
}
,
"191067" : {
"id":191067,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1210",
"type":"Enumeratiewaarde"
}
]
}
,
"191068" : {
"id":191068,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1211",
"type":"Enumeratiewaarde"
}
]
}
,
"191074" : {
"id":191074,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8027",
"type":"Enumeratiewaarde"
}
]
}
,
"191076" : {
"id":191076,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8902",
"type":"Enumeratiewaarde"
}
]
}
,
"191077" : {
"id":191077,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8905",
"type":"Enumeratiewaarde"
}
]
}
,
"191084" : {
"id":191084,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D045",
"type":"Enumeratiewaarde"
}
]
}
,
"191055" : {
"id":191055,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1154",
"type":"Enumeratiewaarde"
}
]
}
,
"191041" : {
"id":191041,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1064",
"type":"Enumeratiewaarde"
}
]
}
,
"191046" : {
"id":191046,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1114",
"type":"Enumeratiewaarde"
}
]
}
,
"191056" : {
"id":191056,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1158",
"type":"Enumeratiewaarde"
}
]
}
,
"191063" : {
"id":191063,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1193",
"type":"Enumeratiewaarde"
}
]
}
,
"191079" : {
"id":191079,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9011",
"type":"Enumeratiewaarde"
}
]
}
,
"191039" : {
"id":191039,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1040",
"type":"Enumeratiewaarde"
}
]
}
,
"191032" : {
"id":191032,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0546",
"type":"Enumeratiewaarde"
}
]
}
,
"191044" : {
"id":191044,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1081",
"type":"Enumeratiewaarde"
}
]
}
,
"191025" : {
"id":191025,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0415",
"type":"Enumeratiewaarde"
}
]
}
,
"191024" : {
"id":191024,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0411",
"type":"Enumeratiewaarde"
}
]
}
,
"191047" : {
"id":191047,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1115",
"type":"Enumeratiewaarde"
}
]
}
,
"191049" : {
"id":191049,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1117",
"type":"Enumeratiewaarde"
}
]
}
,
"191060" : {
"id":191060,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1187",
"type":"Enumeratiewaarde"
}
]
}
,
"191034" : {
"id":191034,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0677",
"type":"Enumeratiewaarde"
}
]
}
,
"191072" : {
"id":191072,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4702",
"type":"Enumeratiewaarde"
}
]
}
,
"191033" : {
"id":191033,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0565",
"type":"Enumeratiewaarde"
}
]
}
,
"191022" : {
"id":191022,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0407",
"type":"Enumeratiewaarde"
}
]
}
,
"191048" : {
"id":191048,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1116",
"type":"Enumeratiewaarde"
}
]
}
,
"191028" : {
"id":191028,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0429",
"type":"Enumeratiewaarde"
}
]
}
,
"191027" : {
"id":191027,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0427",
"type":"Enumeratiewaarde"
}
]
}
,
"191051" : {
"id":191051,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1123",
"type":"Enumeratiewaarde"
}
]
}
,
"191035" : {
"id":191035,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0682",
"type":"Enumeratiewaarde"
}
]
}
,
"191064" : {
"id":191064,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1201",
"type":"Enumeratiewaarde"
}
]
}
,
"191065" : {
"id":191065,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1206",
"type":"Enumeratiewaarde"
}
]
}
,
"191059" : {
"id":191059,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1175",
"type":"Enumeratiewaarde"
}
]
}
,
"191071" : {
"id":191071,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1215",
"type":"Enumeratiewaarde"
}
]
}
,
"191061" : {
"id":191061,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1188",
"type":"Enumeratiewaarde"
}
]
}
,
"191092" : {
"id":191092,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S318",
"type":"Enumeratiewaarde"
}
]
}
,
"191090" : {
"id":191090,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S119",
"type":"Enumeratiewaarde"
}
]
}
,
"191098" : {
"id":191098,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2400",
"type":"Enumeratiewaarde"
}
]
}
,
"191097" : {
"id":191097,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0720",
"type":"Enumeratiewaarde"
}
]
}
,
"191094" : {
"id":191094,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D049",
"type":"Enumeratiewaarde"
}
]
}
,
"191087" : {
"id":191087,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S073",
"type":"Enumeratiewaarde"
}
]
}
,
"191095" : {
"id":191095,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D023",
"type":"Enumeratiewaarde"
}
]
}
,
"191088" : {
"id":191088,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S086",
"type":"Enumeratiewaarde"
}
]
}
,
"191086" : {
"id":191086,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S071",
"type":"Enumeratiewaarde"
}
]
}
,
"191096" : {
"id":191096,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S124",
"type":"Enumeratiewaarde"
}
]
}
,
"191089" : {
"id":191089,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S114",
"type":"Enumeratiewaarde"
}
]
}
,
"191091" : {
"id":191091,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S317",
"type":"Enumeratiewaarde"
}
]
}
,
"191093" : {
"id":191093,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D054",
"type":"Enumeratiewaarde"
}
]
}
,
"191085" : {
"id":191085,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D046",
"type":"Enumeratiewaarde"
}
]
}
,
"191099" : {
"id":191099,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2620",
"type":"Enumeratiewaarde"
}
]
}
,
"191100" : {
"id":191100,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0520",
"type":"Enumeratiewaarde"
}
]
}
,
"191103" : {
"id":191103,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2810",
"type":"Enumeratiewaarde"
}
]
}
,
"191102" : {
"id":191102,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1720",
"type":"Enumeratiewaarde"
}
]
}
,
"191101" : {
"id":191101,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2630",
"type":"Enumeratiewaarde"
}
]
}
,
"190910" : {
"id":190910,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"188",
"type":"Enumeratiewaarde"
}
]
}
,
"190920" : {
"id":190920,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"405",
"type":"Enumeratiewaarde"
}
]
}
,
"190925" : {
"id":190925,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"412",
"type":"Enumeratiewaarde"
}
]
}
,
"190927" : {
"id":190927,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"391",
"type":"Enumeratiewaarde"
}
]
}
,
"190917" : {
"id":190917,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"396",
"type":"Enumeratiewaarde"
}
]
}
,
"190931" : {
"id":190931,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0400",
"type":"Enumeratiewaarde"
}
]
}
,
"190926" : {
"id":190926,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"413",
"type":"Enumeratiewaarde"
}
]
}
,
"190930" : {
"id":190930,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1400",
"type":"Enumeratiewaarde"
}
]
}
,
"190932" : {
"id":190932,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1216",
"type":"Enumeratiewaarde"
}
]
}
,
"190933" : {
"id":190933,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0970",
"type":"Enumeratiewaarde"
}
]
}
,
"190913" : {
"id":190913,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"354",
"type":"Enumeratiewaarde"
}
]
}
,
"190934" : {
"id":190934,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"83",
"type":"Enumeratiewaarde"
}
]
}
,
"190918" : {
"id":190918,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"398",
"type":"Enumeratiewaarde"
}
]
}
,
"190916" : {
"id":190916,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"394",
"type":"Enumeratiewaarde"
}
]
}
,
"190923" : {
"id":190923,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"410",
"type":"Enumeratiewaarde"
}
]
}
,
"190919" : {
"id":190919,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"404",
"type":"Enumeratiewaarde"
}
]
}
,
"190921" : {
"id":190921,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"406",
"type":"Enumeratiewaarde"
}
]
}
,
"190929" : {
"id":190929,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1074",
"type":"Enumeratiewaarde"
}
]
}
,
"190907" : {
"id":190907,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"445",
"type":"Enumeratiewaarde"
}
]
}
,
"190906" : {
"id":190906,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"444",
"type":"Enumeratiewaarde"
}
]
}
,
"190924" : {
"id":190924,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"411",
"type":"Enumeratiewaarde"
}
]
}
,
"190928" : {
"id":190928,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0990",
"type":"Enumeratiewaarde"
}
]
}
,
"190908" : {
"id":190908,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"448",
"type":"Enumeratiewaarde"
}
]
}
,
"190914" : {
"id":190914,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"359",
"type":"Enumeratiewaarde"
}
]
}
,
"190912" : {
"id":190912,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"353",
"type":"Enumeratiewaarde"
}
]
}
,
"190911" : {
"id":190911,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"352",
"type":"Enumeratiewaarde"
}
]
}
,
"190915" : {
"id":190915,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"393",
"type":"Enumeratiewaarde"
}
]
}
,
"190922" : {
"id":190922,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"407",
"type":"Enumeratiewaarde"
}
]
}
,
"190909" : {
"id":190909,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"187",
"type":"Enumeratiewaarde"
}
]
}
,
"190939" : {
"id":190939,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1300",
"type":"Enumeratiewaarde"
}
]
}
,
"190942" : {
"id":190942,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"190941" : {
"id":190941,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0141",
"type":"Enumeratiewaarde"
}
]
}
,
"190937" : {
"id":190937,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"07",
"type":"Enumeratiewaarde"
}
]
}
,
"190936" : {
"id":190936,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0910",
"type":"Enumeratiewaarde"
}
]
}
,
"190935" : {
"id":190935,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1840",
"type":"Enumeratiewaarde"
}
]
}
,
"190940" : {
"id":190940,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1054",
"type":"Enumeratiewaarde"
}
]
}
,
"190944" : {
"id":190944,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0431",
"type":"Enumeratiewaarde"
}
]
}
,
"190952" : {
"id":190952,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2100",
"type":"Enumeratiewaarde"
}
]
}
,
"190949" : {
"id":190949,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0630",
"type":"Enumeratiewaarde"
}
]
}
,
"190953" : {
"id":190953,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD327: Code verwijzer - Vervallen codes",
"type":"Enumeratie"
}
]
}
,
"190947" : {
"id":190947,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0320",
"type":"Enumeratiewaarde"
}
]
}
,
"190950" : {
"id":190950,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0500",
"type":"Enumeratiewaarde"
}
]
}
,
"190954" : {
"id":190954,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3110",
"type":"Enumeratiewaarde"
}
]
}
,
"190951" : {
"id":190951,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9052",
"type":"Enumeratiewaarde"
}
]
}
,
"190955" : {
"id":190955,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"16",
"type":"Enumeratiewaarde"
}
]
}
,
"190946" : {
"id":190946,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0311",
"type":"Enumeratiewaarde"
}
]
}
,
"190948" : {
"id":190948,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1092",
"type":"Enumeratiewaarde"
}
]
}
,
"190945" : {
"id":190945,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1010",
"type":"Enumeratiewaarde"
}
]
}
,
"190956" : {
"id":190956,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S121",
"type":"Enumeratiewaarde"
}
]
}
,
"190958" : {
"id":190958,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1710",
"type":"Enumeratiewaarde"
}
]
}
,
"190959" : {
"id":190959,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8904",
"type":"Enumeratiewaarde"
}
]
}
,
"190961" : {
"id":190961,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2530",
"type":"Enumeratiewaarde"
}
]
}
,
"190963" : {
"id":190963,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D018",
"type":"Enumeratiewaarde"
}
]
}
,
"190967" : {
"id":190967,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4",
"type":"Enumeratiewaarde"
}
]
}
,
"190969" : {
"id":190969,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WJ002: Reden wijziging toewijzing - Vervallen",
"type":"Enumeratie"
}
]
}
,
"190968" : {
"id":190968,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1320",
"type":"Enumeratiewaarde"
}
]
}
,
"190964" : {
"id":190964,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD981: Extra kosten thuis - Vervallen codes",
"type":"Enumeratie"
}
]
}
,
"190970" : {
"id":190970,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"190965" : {
"id":190965,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"190971" : {
"id":190971,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"190972" : {
"id":190972,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"190962" : {
"id":190962,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"190957" : {
"id":190957,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S120",
"type":"Enumeratiewaarde"
}
]
}
,
"190966" : {
"id":190966,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"190960" : {
"id":190960,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WMO756: Eenheid - Vervallen",
"type":"Enumeratie"
}
]
}
,
"190974" : {
"id":190974,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"190977" : {
"id":190977,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"09",
"type":"Enumeratiewaarde"
}
]
}
,
"190985" : {
"id":190985,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2500",
"type":"Enumeratiewaarde"
}
]
}
,
"190979" : {
"id":190979,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D042",
"type":"Enumeratiewaarde"
}
]
}
,
"190983" : {
"id":190983,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1191",
"type":"Enumeratiewaarde"
}
]
}
,
"190981" : {
"id":190981,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1310",
"type":"Enumeratiewaarde"
}
]
}
,
"190982" : {
"id":190982,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1700",
"type":"Enumeratiewaarde"
}
]
}
,
"190980" : {
"id":190980,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S115",
"type":"Enumeratiewaarde"
}
]
}
,
"190976" : {
"id":190976,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"07",
"type":"Enumeratiewaarde"
}
]
}
,
"190975" : {
"id":190975,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"06",
"type":"Enumeratiewaarde"
}
]
}
,
"190973" : {
"id":190973,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"190978" : {
"id":190978,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"10",
"type":"Enumeratiewaarde"
}
]
}
,
"190984" : {
"id":190984,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4",
"type":"Enumeratiewaarde"
}
]
}
,
"185077" : {
"id":185077,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of  indiening is niet valide",
"type":"End event"
}
]
}
,
"185055" : {
"id":185055,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"185038" : {
"id":185038,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185039" : {
"id":185039,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185058" : {
"id":185058,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"185071" : {
"id":185071,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM ontvangen",
"type":"Task"
}
]
}
,
"185051" : {
"id":185051,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of  indiening valide?",
"type":"Gateway"
}
]
}
,
"185048" : {
"id":185048,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185062" : {
"id":185062,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185065" : {
"id":185065,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185068" : {
"id":185068,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185074" : {
"id":185074,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"185084" : {
"id":185084,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Verzoekschrift is ingediend",
"type":"End event"
}
]
}
,
"185091" : {
"id":185091,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht beslissing voorbereiding of indiening verzenden",
"type":"Task"
}
]
}
,
"185145" : {
"id":185145,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"185119" : {
"id":185119,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"185116" : {
"id":185116,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"185112" : {
"id":185112,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185152" : {
"id":185152,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht VCM verzenden",
"type":"Task"
}
]
}
,
"185125" : {
"id":185125,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185131" : {
"id":185131,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening controleren",
"type":"Task"
}
]
}
,
"185138" : {
"id":185138,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185097" : {
"id":185097,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding is beeindigd",
"type":"End event"
}
]
}
,
"185128" : {
"id":185128,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185149" : {
"id":185149,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"185155" : {
"id":185155,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht VCM controleren",
"type":"Task"
}
]
}
,
"185122" : {
"id":185122,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"185134" : {
"id":185134,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185110" : {
"id":185110,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185102" : {
"id":185102,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Aanvraag is afgewezen",
"type":"End event"
}
]
}
,
"185141" : {
"id":185141,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"185205" : {
"id":185205,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185183" : {
"id":185183,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185206" : {
"id":185206,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185209" : {
"id":185209,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185218" : {
"id":185218,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185220" : {
"id":185220,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185164" : {
"id":185164,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"185221" : {
"id":185221,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185200" : {
"id":185200,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Condities tabel 2.0 (fix iwvggz)",
"type":"Grafiek"
}
]
}
,
"185208" : {
"id":185208,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185219" : {
"id":185219,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185177" : {
"id":185177,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht VCM is niet valide",
"type":"End event"
}
]
}
,
"185161" : {
"id":185161,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185196" : {
"id":185196,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"185174" : {
"id":185174,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht VCM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"185204" : {
"id":185204,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185180" : {
"id":185180,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht VCM valide?",
"type":"Gateway"
}
]
}
,
"185212" : {
"id":185212,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185216" : {
"id":185216,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185158" : {
"id":185158,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185214" : {
"id":185214,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185167" : {
"id":185167,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht VCM ontvangen",
"type":"Task"
}
]
}
,
"185171" : {
"id":185171,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht VCM is ontvangen",
"type":"End event"
}
]
}
,
"185184" : {
"id":185184,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185213" : {
"id":185213,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185217" : {
"id":185217,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185273" : {
"id":185273,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"De regels uit de iWvggz-standaard moeten zowel aan de verzendende- als    de ontvangende zijde worden gecontroleerd (geen conrtole door Vecozo)",
"type":"Tekenvorm"
}
]
}
,
"185222" : {
"id":185222,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185229" : {
"id":185229,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Geneesheer-directeur",
"type":"Resource role"
}
]
}
,
"185233" : {
"id":185233,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"185223" : {
"id":185223,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185272" : {
"id":185272,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185225" : {
"id":185225,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Resource role"
}
]
}
,
"185227" : {
"id":185227,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceRole.png",
"data" : [
{
"name":"Zorgverlener",
"type":"Resource role"
}
]
}
,
"185286" : {
"id":185286,
"typeIconPath":"data/icons/BPMN/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185386" : {
"id":185386,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Emailadres",
"type":"Attribuut"
}
]
}
,
"185407" : {
"id":185407,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185413" : {
"id":185413,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185388" : {
"id":185388,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Telefoon",
"type":"Attribuut"
}
]
}
,
"185398" : {
"id":185398,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185395" : {
"id":185395,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185391" : {
"id":185391,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185394" : {
"id":185394,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185399" : {
"id":185399,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185401" : {
"id":185401,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185402" : {
"id":185402,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185392" : {
"id":185392,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185400" : {
"id":185400,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185404" : {
"id":185404,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersieRetour",
"type":"Attribuut"
}
]
}
,
"185406" : {
"id":185406,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185390" : {
"id":185390,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185405" : {
"id":185405,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185409" : {
"id":185409,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185393" : {
"id":185393,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185410" : {
"id":185410,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185408" : {
"id":185408,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185411" : {
"id":185411,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185412" : {
"id":185412,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185389" : {
"id":185389,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185397" : {
"id":185397,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"RetourCode",
"type":"Attribuut"
}
]
}
,
"185447" : {
"id":185447,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185452" : {
"id":185452,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG116 - Retour Bericht VCM",
"type":"Message"
}
]
}
,
"185461" : {
"id":185461,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Aanlevering verplichte zorg controleren",
"type":"Task"
}
]
}
,
"185467" : {
"id":185467,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185443" : {
"id":185443,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185469" : {
"id":185469,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185471" : {
"id":185471,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht Aanlevering verplichte zorg is niet valide",
"type":"End event"
}
]
}
,
"185463" : {
"id":185463,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Aanlevering gegevens verplichte zorg ontvangen",
"type":"End event"
}
]
}
,
"185436" : {
"id":185436,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185432" : {
"id":185432,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185438" : {
"id":185438,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"185423" : {
"id":185423,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185475" : {
"id":185475,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"185457" : {
"id":185457,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"185477" : {
"id":185477,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185439" : {
"id":185439,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DagtekeningRetour",
"type":"Attribuut"
}
]
}
,
"185465" : {
"id":185465,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht Aanlevering verplichte zorg valide?",
"type":"Gateway"
}
]
}
,
"185473" : {
"id":185473,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"185427" : {
"id":185427,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185434" : {
"id":185434,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"RetourCodes",
"type":"Klasse"
}
]
}
,
"185422" : {
"id":185422,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185416" : {
"id":185416,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185431" : {
"id":185431,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185451" : {
"id":185451,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG112 - Retour persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"185455" : {
"id":185455,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Aanlevering verplichte zorg ontvangen",
"type":"Task"
}
]
}
,
"185429" : {
"id":185429,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185430" : {
"id":185430,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185424" : {
"id":185424,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185415" : {
"id":185415,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185414" : {
"id":185414,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185419" : {
"id":185419,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Berichttype",
"type":"Attribuut"
}
]
}
,
"185459" : {
"id":185459,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"185449" : {
"id":185449,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185421" : {
"id":185421,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsltVersie",
"type":"Attribuut"
}
]
}
,
"185425" : {
"id":185425,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185428" : {
"id":185428,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185453" : {
"id":185453,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG115 - Bericht VCM",
"type":"Message"
}
]
}
,
"185441" : {
"id":185441,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"IdentificatieRetour",
"type":"Attribuut"
}
]
}
,
"185426" : {
"id":185426,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185445" : {
"id":185445,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Berichtklassen",
"type":"Klasse"
}
]
}
,
"185450" : {
"id":185450,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG111 - Persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"185485" : {
"id":185485,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG109 - Beslissing voorbereiding of indiening ZM",
"type":"Message"
}
]
}
,
"185487" : {
"id":185487,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Pool"
}
]
}
,
"185479" : {
"id":185479,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht Aanlevering verplichte zorg verzenden",
"type":"Task"
}
]
}
,
"185490" : {
"id":185490,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"185529" : {
"id":185529,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185526" : {
"id":185526,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG104- Retour aanwijzing GD",
"type":"Message"
}
]
}
,
"185484" : {
"id":185484,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG110 - Retour beslissing voorbereiding of indiening ZM",
"type":"Message"
}
]
}
,
"185528" : {
"id":185528,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185489" : {
"id":185489,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG113 - Aanlevering verplichte zorg",
"type":"Message"
}
]
}
,
"185539" : {
"id":185539,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185536" : {
"id":185536,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185541" : {
"id":185541,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185524" : {
"id":185524,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG106 - Retour Medische Verklaring",
"type":"Message"
}
]
}
,
"185530" : {
"id":185530,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185481" : {
"id":185481,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht Aanlevering verplichte zorg is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"185491" : {
"id":185491,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG114 - Retour aanlevering verplichte zorg",
"type":"Message"
}
]
}
,
"185523" : {
"id":185523,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG105 - Medische verklaring",
"type":"Message"
}
]
}
,
"185525" : {
"id":185525,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"WVG103 - Aanwijzing GD",
"type":"Message"
}
]
}
,
"185483" : {
"id":185483,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"185488" : {
"id":185488,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"185486" : {
"id":185486,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"IGJ",
"type":"Pool"
}
]
}
,
"185579" : {
"id":185579,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185554" : {
"id":185554,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185549" : {
"id":185549,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185569" : {
"id":185569,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185572" : {
"id":185572,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185581" : {
"id":185581,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185562" : {
"id":185562,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"141950" : {
"id":141950,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Processen",
"type":"Totaalview"
}
]
}
,
"185559" : {
"id":185559,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185560" : {
"id":185560,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185566" : {
"id":185566,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185580" : {
"id":185580,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185591" : {
"id":185591,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"185551" : {
"id":185551,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185652" : {
"id":185652,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185654" : {
"id":185654,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185656" : {
"id":185656,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185662" : {
"id":185662,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185668" : {
"id":185668,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185658" : {
"id":185658,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185613" : {
"id":185613,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"185664" : {
"id":185664,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185666" : {
"id":185666,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185660" : {
"id":185660,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185684" : {
"id":185684,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185720" : {
"id":185720,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185702" : {
"id":185702,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185682" : {
"id":185682,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185698" : {
"id":185698,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185674" : {
"id":185674,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185686" : {
"id":185686,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185696" : {
"id":185696,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185712" : {
"id":185712,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185688" : {
"id":185688,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185718" : {
"id":185718,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185692" : {
"id":185692,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185678" : {
"id":185678,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185704" : {
"id":185704,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185710" : {
"id":185710,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185672" : {
"id":185672,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185680" : {
"id":185680,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185700" : {
"id":185700,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185670" : {
"id":185670,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185706" : {
"id":185706,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185708" : {
"id":185708,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185714" : {
"id":185714,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185676" : {
"id":185676,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185690" : {
"id":185690,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185694" : {
"id":185694,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185716" : {
"id":185716,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185764" : {
"id":185764,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Adres",
"type":"Attribuut"
}
]
}
,
"185750" : {
"id":185750,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Bsn",
"type":"Attribuut"
}
]
}
,
"185752" : {
"id":185752,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboorteplaats",
"type":"Attribuut"
}
]
}
,
"185772" : {
"id":185772,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"185780" : {
"id":185780,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"185782" : {
"id":185782,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"185784" : {
"id":185784,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"185768" : {
"id":185768,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185785" : {
"id":185785,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185757" : {
"id":185757,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Beslissing",
"type":"Attribuut"
}
]
}
,
"185786" : {
"id":185786,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185788" : {
"id":185788,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185790" : {
"id":185790,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185792" : {
"id":185792,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185793" : {
"id":185793,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185755" : {
"id":185755,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"BeslissingOvJ",
"type":"Klasse"
}
]
}
,
"185758" : {
"id":185758,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185751" : {
"id":185751,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboorteland",
"type":"Attribuut"
}
]
}
,
"185770" : {
"id":185770,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185787" : {
"id":185787,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185776" : {
"id":185776,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"185789" : {
"id":185789,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185791" : {
"id":185791,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185794" : {
"id":185794,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185766" : {
"id":185766,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"OrganisatieContactgegevens",
"type":"Attribuut"
}
]
}
,
"185795" : {
"id":185795,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185749" : {
"id":185749,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslacht",
"type":"Attribuut"
}
]
}
,
"185778" : {
"id":185778,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"185754" : {
"id":185754,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Contactgegevens",
"type":"Attribuut"
}
]
}
,
"142083" : {
"id":142083,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Berichten",
"type":"Totaalview"
}
]
}
,
"185762" : {
"id":185762,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"OrganisatieNaam",
"type":"Attribuut"
}
]
}
,
"185759" : {
"id":185759,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185756" : {
"id":185756,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZMOndertekeningsdatum",
"type":"Attribuut"
}
]
}
,
"185801" : {
"id":185801,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185840" : {
"id":185840,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Rechtbank",
"type":"Attribuut"
}
]
}
,
"185843" : {
"id":185843,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"VoortgezetteCmAanvraagNummer",
"type":"Attribuut"
}
]
}
,
"185819" : {
"id":185819,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185847" : {
"id":185847,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"185853" : {
"id":185853,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"185798" : {
"id":185798,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185859" : {
"id":185859,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"185816" : {
"id":185816,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185796" : {
"id":185796,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185805" : {
"id":185805,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185807" : {
"id":185807,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185813" : {
"id":185813,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185857" : {
"id":185857,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"185812" : {
"id":185812,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185808" : {
"id":185808,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185810" : {
"id":185810,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185815" : {
"id":185815,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185809" : {
"id":185809,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185800" : {
"id":185800,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185818" : {
"id":185818,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185817" : {
"id":185817,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185799" : {
"id":185799,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185803" : {
"id":185803,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185837" : {
"id":185837,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185845" : {
"id":185845,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185814" : {
"id":185814,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185849" : {
"id":185849,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"185802" : {
"id":185802,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185804" : {
"id":185804,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185806" : {
"id":185806,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185821" : {
"id":185821,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"185851" : {
"id":185851,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"185797" : {
"id":185797,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185811" : {
"id":185811,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185883" : {
"id":185883,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185867" : {
"id":185867,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185886" : {
"id":185886,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185893" : {
"id":185893,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185889" : {
"id":185889,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185870" : {
"id":185870,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185866" : {
"id":185866,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185873" : {
"id":185873,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185894" : {
"id":185894,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185881" : {
"id":185881,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185860" : {
"id":185860,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185892" : {
"id":185892,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185871" : {
"id":185871,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185877" : {
"id":185877,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185864" : {
"id":185864,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185882" : {
"id":185882,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185868" : {
"id":185868,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185887" : {
"id":185887,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185890" : {
"id":185890,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185879" : {
"id":185879,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185876" : {
"id":185876,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185880" : {
"id":185880,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185863" : {
"id":185863,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185861" : {
"id":185861,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185862" : {
"id":185862,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185865" : {
"id":185865,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185869" : {
"id":185869,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185874" : {
"id":185874,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185875" : {
"id":185875,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185888" : {
"id":185888,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185878" : {
"id":185878,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185884" : {
"id":185884,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185872" : {
"id":185872,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185885" : {
"id":185885,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185891" : {
"id":185891,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185981" : {
"id":185981,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185983" : {
"id":185983,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185985" : {
"id":185985,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185987" : {
"id":185987,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185979" : {
"id":185979,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186051" : {
"id":186051,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"186001" : {
"id":186001,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186011" : {
"id":186011,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186035" : {
"id":186035,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186039" : {
"id":186039,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186033" : {
"id":186033,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186047" : {
"id":186047,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186031" : {
"id":186031,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185993" : {
"id":185993,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186025" : {
"id":186025,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186023" : {
"id":186023,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186017" : {
"id":186017,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186003" : {
"id":186003,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186049" : {
"id":186049,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG101 - Aanvraag zorgmachtiging",
"type":"Tekenvorm"
}
]
}
,
"186007" : {
"id":186007,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186041" : {
"id":186041,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185999" : {
"id":185999,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186015" : {
"id":186015,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185989" : {
"id":185989,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185995" : {
"id":185995,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186009" : {
"id":186009,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186013" : {
"id":186013,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"185997" : {
"id":185997,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186005" : {
"id":186005,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186027" : {
"id":186027,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186029" : {
"id":186029,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186021" : {
"id":186021,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186037" : {
"id":186037,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"185991" : {
"id":185991,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186043" : {
"id":186043,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186019" : {
"id":186019,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186045" : {
"id":186045,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186057" : {
"id":186057,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"186093" : {
"id":186093,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"186053" : {
"id":186053,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"186091" : {
"id":186091,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"186097" : {
"id":186097,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"186095" : {
"id":186095,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"186089" : {
"id":186089,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG111 - Persoonsgegevens betrokkene",
"type":"Tekenvorm"
}
]
}
,
"186099" : {
"id":186099,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"186055" : {
"id":186055,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"186059" : {
"id":186059,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"186140" : {
"id":186140,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186160" : {
"id":186160,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186168" : {
"id":186168,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186170" : {
"id":186170,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186152" : {
"id":186152,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186138" : {
"id":186138,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186156" : {
"id":186156,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186176" : {
"id":186176,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186178" : {
"id":186178,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186142" : {
"id":186142,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186162" : {
"id":186162,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186172" : {
"id":186172,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186144" : {
"id":186144,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186134" : {
"id":186134,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186136" : {
"id":186136,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186158" : {
"id":186158,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186164" : {
"id":186164,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186166" : {
"id":186166,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186132" : {
"id":186132,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186146" : {
"id":186146,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186174" : {
"id":186174,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"142312" : {
"id":142312,
"typeIconPath":"data/icons/ArchiMate/AllExtendedView.png",
"data" : [
{
"name":"iWvggz",
"type":"Totaalview uitgebreid"
}
]
}
,
"186148" : {
"id":186148,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186150" : {
"id":186150,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186154" : {
"id":186154,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186198" : {
"id":186198,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186188" : {
"id":186188,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186229" : {
"id":186229,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Grondslag",
"type":"Klasse"
}
]
}
,
"186230" : {
"id":186230,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Plaats",
"type":"Attribuut"
}
]
}
,
"186200" : {
"id":186200,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186184" : {
"id":186184,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186196" : {
"id":186196,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186192" : {
"id":186192,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186194" : {
"id":186194,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186182" : {
"id":186182,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186180" : {
"id":186180,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186190" : {
"id":186190,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186186" : {
"id":186186,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"26795" : {
"id":26795,
"typeIconPath":"data/icons/MM_ModelPackage/MM_ModelPackage.png",
"data" : [
{
"name":"Modelpackage",
"type":"Modelpackage"
}
]
}
,
"114200" : {
"id":114200,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS022: Maximale lengte 32 posities",
"type":"Beperking"
}
]
}
,
"113885" : {
"id":113885,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"min/max restricties",
"type":"Motivatie-elementen"
}
]
}
,
"113988" : {
"id":113988,
"typeIconPath":"data/icons/UML/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"113993" : {
"id":113993,
"typeIconPath":"data/icons/UML/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"113954" : {
"id":113954,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Generieke Berichtklassen",
"type":"Model"
}
]
}
,
"104705" : {
"id":104705,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Professional",
"type":"Datatype"
}
]
}
,
"104733" : {
"id":104733,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG617: Rechtbank",
"type":"Enumeratie"
}
]
}
,
"104912" : {
"id":104912,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP017: De gestructureerde informatieuitwisseling in de iWvggz is gebaseerd op gestandaardiseerd berichtenverkeer (iStandaarden).",
"type":"Principe"
}
]
}
,
"105835" : {
"id":105835,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Diagnose",
"type":"Datatype"
}
]
}
,
"106398" : {
"id":106398,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Constraints - CS WvGGZ",
"type":"Motivatie-elementen"
}
]
}
,
"106491" : {
"id":106491,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Geboortedatum",
"type":"Datatype"
}
]
}
,
"102917" : {
"id":102917,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP603: De in het bericht opgenomen gestructureerde gegevens zijn in overeenstemming met de ongestructureerde gegevens in de bijlagen",
"type":"Requirement"
}
]
}
,
"102916" : {
"id":102916,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102923" : {
"id":102923,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102937" : {
"id":102937,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_AgbCode",
"type":"Datatype"
}
]
}
,
"102915" : {
"id":102915,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP615: Van iedere betrokkene moet het BRP-adres en/of het veblijfsadres worden opgegeven.",
"type":"Requirement"
}
]
}
,
"102920" : {
"id":102920,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP286: Als de ontvanger een technische fout constateert, keurt hij het bericht in zijn geheel af en laat hij dit weten aan de verzender. Het bericht kan daarmee functioneel als niet-ontvangen worden beschouwd",
"type":"Requirement"
}
]
}
,
"102919" : {
"id":102919,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102926" : {
"id":102926,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102986" : {
"id":102986,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102987" : {
"id":102987,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102954" : {
"id":102954,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102950" : {
"id":102950,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Organisatienaam",
"type":"Datatype"
}
]
}
,
"102942" : {
"id":102942,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102971" : {
"id":102971,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102978" : {
"id":102978,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Bedrag",
"type":"Datatype"
}
]
}
,
"102970" : {
"id":102970,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102980" : {
"id":102980,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102948" : {
"id":102948,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102993" : {
"id":102993,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103018" : {
"id":103018,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102998" : {
"id":102998,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103001" : {
"id":103001,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103025" : {
"id":103025,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Bedrag",
"type":"Klassendiagram"
}
]
}
,
"103029" : {
"id":103029,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103021" : {
"id":103021,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103026" : {
"id":103026,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102995" : {
"id":102995,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103003" : {
"id":103003,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102999" : {
"id":102999,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103031" : {
"id":103031,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103013" : {
"id":103013,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"102997" : {
"id":102997,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BeperkingScore",
"type":"Datatype"
}
]
}
,
"103011" : {
"id":103011,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103048" : {
"id":103048,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD606: Als Voornamen niet gevuld is, dan Voorletters vullen",
"type":"Beperking"
}
]
}
,
"103052" : {
"id":103052,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103054" : {
"id":103054,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103033" : {
"id":103033,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103063" : {
"id":103063,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Gemeente",
"type":"Datatype"
}
]
}
,
"103040" : {
"id":103040,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BurgerServicenummer",
"type":"Datatype"
}
]
}
,
"103072" : {
"id":103072,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103077" : {
"id":103077,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103038" : {
"id":103038,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103075" : {
"id":103075,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103076" : {
"id":103076,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_DatumGebruik",
"type":"Datatype"
}
]
}
,
"103035" : {
"id":103035,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103060" : {
"id":103060,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD605: Als Voorletters niet gevuld is, dan Voornamen vullen",
"type":"Beperking"
}
]
}
,
"103061" : {
"id":103061,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103059" : {
"id":103059,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103071" : {
"id":103071,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP606: Als een bijlage wordt ontvangen met een hoger versienummer, dan vervangt deze een eerder ontvangen bijlage met dezelfde naam van hetzelfde soort.",
"type":"Requirement"
}
]
}
,
"103045" : {
"id":103045,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103047" : {
"id":103047,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103116" : {
"id":103116,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103079" : {
"id":103079,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103119" : {
"id":103119,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Duur",
"type":"Datatype"
}
]
}
,
"103106" : {
"id":103106,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_VolledigeNaam",
"type":"Datatype"
}
]
}
,
"103108" : {
"id":103108,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Voorvoegsel",
"type":"Datatype"
}
]
}
,
"103084" : {
"id":103084,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103090" : {
"id":103090,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103086" : {
"id":103086,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103097" : {
"id":103097,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103096" : {
"id":103096,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Voorletters",
"type":"Datatype"
}
]
}
,
"103109" : {
"id":103109,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103118" : {
"id":103118,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103120" : {
"id":103120,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103091" : {
"id":103091,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Geslacht",
"type":"Datatype"
}
]
}
,
"103094" : {
"id":103094,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103103" : {
"id":103103,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP601: Alleen de geneesheer-directeur die voor de zorgmachtiging is aangesteld mag Bevindingen GD en Medische Verklaring versturen.",
"type":"Requirement"
}
]
}
,
"103110" : {
"id":103110,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP079x2: Als het bsn niet beschikbaar is of niet gebruikt mag worden, dan moet de naam worden gebruikt om de betrokkene te identificeren.",
"type":"Requirement"
}
]
}
,
"103102" : {
"id":103102,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103107" : {
"id":103107,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103080" : {
"id":103080,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_RelatieVolgorde",
"type":"Datatype"
}
]
}
,
"103134" : {
"id":103134,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_DocumentSoort",
"type":"Datatype"
}
]
}
,
"103145" : {
"id":103145,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103126" : {
"id":103126,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_ArrondissementsParket",
"type":"Datatype"
}
]
}
,
"103137" : {
"id":103137,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_KvkNummer",
"type":"Datatype"
}
]
}
,
"103141" : {
"id":103141,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103160" : {
"id":103160,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103161" : {
"id":103161,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP079: Het is verplicht om gebruik te maken van het bsn van de betrokkene in de onderlinge uitwisseling van gegevens indien het bsn bekend is.",
"type":"Requirement"
}
]
}
,
"103165" : {
"id":103165,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103146" : {
"id":103146,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP611: Bij een Medische Verklaring bericht moet het document \"Medische Verklaring ZM\" als bijlage worden meegestuurd.",
"type":"Requirement"
}
]
}
,
"103129" : {
"id":103129,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Voorvoegsel",
"type":"Klassendiagram"
}
]
}
,
"103144" : {
"id":103144,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_NadeelSoort",
"type":"Datatype"
}
]
}
,
"103180" : {
"id":103180,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Aantal",
"type":"Datatype"
}
]
}
,
"103190" : {
"id":103190,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Referentie",
"type":"Datatype"
}
]
}
,
"103193" : {
"id":103193,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103200" : {
"id":103200,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD600: Als Beslissing gevuld is met 01, dan vullen, anders leeg laten.",
"type":"Beperking"
}
]
}
,
"103204" : {
"id":103204,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103206" : {
"id":103206,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103207" : {
"id":103207,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP076: Van iedere contactpersoon (relatie) moet worden opgegeven in welke relatie deze tot de betrokkene staat.",
"type":"Requirement"
}
]
}
,
"103188" : {
"id":103188,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Eenheid",
"type":"Datatype"
}
]
}
,
"103175" : {
"id":103175,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BurgerServicenummer",
"type":"Klassendiagram"
}
]
}
,
"103250" : {
"id":103250,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103219" : {
"id":103219,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103234" : {
"id":103234,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_DocumentFormaat",
"type":"Datatype"
}
]
}
,
"103256" : {
"id":103256,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_MomentDuur",
"type":"Datatype"
}
]
}
,
"103222" : {
"id":103222,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_GrondslagSoort",
"type":"Datatype"
}
]
}
,
"103218" : {
"id":103218,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Achternaam",
"type":"Klassendiagram"
}
]
}
,
"103224" : {
"id":103224,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP612: Iedere levering van gegevens over het verlenen van verplichte zorg heeft een unieke identificatie op instellingsniveau die gebruikt kan worden voor referentie.",
"type":"Requirement"
}
]
}
,
"103260" : {
"id":103260,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103276" : {
"id":103276,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_ReferentieNummer",
"type":"Datatype"
}
]
}
,
"103271" : {
"id":103271,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_AgbCode",
"type":"Klassendiagram"
}
]
}
,
"103274" : {
"id":103274,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD607: Als Soort adres de waarde 1 (BRP-adres), 3 (verblijfadres) of 5 (werkadres) heeft, dan verplicht vullen.",
"type":"Beperking"
}
]
}
,
"103281" : {
"id":103281,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103282" : {
"id":103282,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP609: Bij een Aanwijzing GD bericht moet het document \"Aanwijzing GD en aanlevering gegevens\" als bijlage worden meegestuurd.",
"type":"Requirement"
}
]
}
,
"103280" : {
"id":103280,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_RelatieVolgorde",
"type":"Klassendiagram"
}
]
}
,
"103327" : {
"id":103327,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103313" : {
"id":103313,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103338" : {
"id":103338,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103317" : {
"id":103317,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Motivering",
"type":"Datatype"
}
]
}
,
"103331" : {
"id":103331,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103337" : {
"id":103337,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_KvkNummer",
"type":"Klassendiagram"
}
]
}
,
"103344" : {
"id":103344,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103307" : {
"id":103307,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Datum",
"type":"Attribuut"
}
]
}
,
"103321" : {
"id":103321,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_RolProfessional",
"type":"Datatype"
}
]
}
,
"103345" : {
"id":103345,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP604: Het aanvraagtraject voor een zorgmachtiging voor een betrokkene wordt steeds geindentificeerd door middel van een specifiek uniek nummer.",
"type":"Requirement"
}
]
}
,
"103340" : {
"id":103340,
"typeIconPath":"data/icons/MM_ModelPackage/MM_Folder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"103304" : {
"id":103304,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Bronnen en registers",
"type":"ArchiMate-model"
}
]
}
,
"103367" : {
"id":103367,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103389" : {
"id":103389,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103368" : {
"id":103368,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_ZorgkantoorCode",
"type":"Datatype"
}
]
}
,
"103379" : {
"id":103379,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103349" : {
"id":103349,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_RetourCode",
"type":"Datatype"
}
]
}
,
"103359" : {
"id":103359,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103361" : {
"id":103361,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103375" : {
"id":103375,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103376" : {
"id":103376,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Naam",
"type":"Datatype"
}
]
}
,
"103377" : {
"id":103377,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103356" : {
"id":103356,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103365" : {
"id":103365,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103384" : {
"id":103384,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103378" : {
"id":103378,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BeperkingCategorie",
"type":"Datatype"
}
]
}
,
"103400" : {
"id":103400,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103404" : {
"id":103404,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103416" : {
"id":103416,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103396" : {
"id":103396,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103395" : {
"id":103395,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103419" : {
"id":103419,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD602: Als MomentDuurIndicatie 1 is, dan leeg laten",
"type":"Beperking"
}
]
}
,
"103398" : {
"id":103398,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103397" : {
"id":103397,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103405" : {
"id":103405,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BeperkingVraag",
"type":"Datatype"
}
]
}
,
"103450" : {
"id":103450,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103463" : {
"id":103463,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_NaamGebruik",
"type":"Datatype"
}
]
}
,
"103454" : {
"id":103454,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_SoortRelatie",
"type":"Datatype"
}
]
}
,
"103453" : {
"id":103453,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103462" : {
"id":103462,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103460" : {
"id":103460,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103495" : {
"id":103495,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103514" : {
"id":103514,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103477" : {
"id":103477,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103515" : {
"id":103515,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP610: Bij een Bevindingen GD bericht moet het document \"Bevindingen GD tav zorgplan\" als bijlage worden meegestuurd.",
"type":"Requirement"
}
]
}
,
"103490" : {
"id":103490,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_VestigingsNummer",
"type":"Datatype"
}
]
}
,
"103488" : {
"id":103488,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Beslissing",
"type":"Datatype"
}
]
}
,
"103499" : {
"id":103499,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_RelatieOmgeving",
"type":"Datatype"
}
]
}
,
"103491" : {
"id":103491,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103497" : {
"id":103497,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP079x1: Als het bsn niet beschikbaar is of niet gebruikt mag worden, dan moet de “alternatieve set identificerende gegevens” uit de privacy handreiking Wvggz (zie par 4.3)” worden gebruikt om de betrokkene te identificeren.",
"type":"Requirement"
}
]
}
,
"103505" : {
"id":103505,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103478" : {
"id":103478,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103484" : {
"id":103484,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_VerkorteNaam",
"type":"Klassendiagram"
}
]
}
,
"103496" : {
"id":103496,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103509" : {
"id":103509,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103485" : {
"id":103485,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"76285" : {
"id":76285,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"76330" : {
"id":76330,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Technische regels - TR Generiek",
"type":"Motivatie-elementen"
}
]
}
,
"75988" : {
"id":75988,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Generieke berichtklassen",
"type":"Model"
}
]
}
,
"75992" : {
"id":75992,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Wvggz berichtklassen",
"type":"Model"
}
]
}
,
"107209" : {
"id":107209,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Achternaam",
"type":"Datatype"
}
]
}
,
"107739" : {
"id":107739,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG611: Rol professional",
"type":"Enumeratie"
}
]
}
,
"107861" : {
"id":107861,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG609: Relatie omgeving",
"type":"Enumeratie"
}
]
}
,
"107950" : {
"id":107950,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG614: Zorgvorm",
"type":"Enumeratie"
}
]
}
,
"107951" : {
"id":107951,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG615: Zorgvormcategorie",
"type":"Enumeratie"
}
]
}
,
"107952" : {
"id":107952,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG618: BerichtType",
"type":"Enumeratie"
}
]
}
,
"107944" : {
"id":107944,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG605: Eenheid",
"type":"Enumeratie"
}
]
}
,
"107953" : {
"id":107953,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG619: Grondslag soort",
"type":"Enumeratie"
}
]
}
,
"107943" : {
"id":107943,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG604: Documentformaat",
"type":"Enumeratie"
}
]
}
,
"107949" : {
"id":107949,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG613: Soort nadeel",
"type":"Enumeratie"
}
]
}
,
"107941" : {
"id":107941,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG602: Beslissing",
"type":"Enumeratie"
}
]
}
,
"107945" : {
"id":107945,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG606: Indicatie moment duur",
"type":"Enumeratie"
}
]
}
,
"107947" : {
"id":107947,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG608: Organisatiesoort",
"type":"Enumeratie"
}
]
}
,
"107948" : {
"id":107948,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG612: Soort document",
"type":"Enumeratie"
}
]
}
,
"107946" : {
"id":107946,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG607: Juridische titel",
"type":"Enumeratie"
}
]
}
,
"107067" : {
"id":107067,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG616: Aanleiding Bevindingen",
"type":"Enumeratie"
}
]
}
,
"108274" : {
"id":108274,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG601: Arrondissementsparket",
"type":"Enumeratie"
}
]
}
,
"108317" : {
"id":108317,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_VerkorteNaam",
"type":"Datatype"
}
]
}
,
"108641" : {
"id":108641,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP602: De Officier van Justitie bepaalt of de voorbereiding van een zorgmachtiging gestart wordt.",
"type":"Principe"
}
]
}
,
"108644" : {
"id":108644,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP605: Gestructureerde berichten bevatten mogelijk bijlagen waarin relevante documenten worden meegestuurd",
"type":"Principe"
}
]
}
,
"108637" : {
"id":108637,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP016: In de iWvggz-berichten wordt de toegestane verplichte zorg uitgedrukt in vorm(en) van verplichte zorg in artikel 3:2 van de Wvggz en in de Regeling Wvggz.",
"type":"Principe"
}
]
}
,
"108636" : {
"id":108636,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP006: De betrokkene wordt in de informatievoorziening Wvggz bij voorkeur geidentificeerd met zijn of haar BSN.",
"type":"Principe"
}
]
}
,
"108687" : {
"id":108687,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP065: Een retourbericht bevat alleen informatie over klassen die zijn afgekeurd en hun bovenliggende klassen.",
"type":"Requirement"
}
]
}
,
"108643" : {
"id":108643,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP604: De verstrekker van de informatie stuurt de laatst bekende informatie mee.",
"type":"Principe"
}
]
}
,
"108639" : {
"id":108639,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP600: Gegevens in iWvggz berichten hebben de EIDAS classificatie Substantieel.",
"type":"Principe"
}
]
}
,
"108638" : {
"id":108638,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP024: De informatievoorziening Wvggz conformeert zich aan de wet- en regelgeving uit de Wvggz van 19-3-2020 en de Rvggz van 01-01-2020.",
"type":"Principe"
}
]
}
,
"108640" : {
"id":108640,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP601: De geneesheer-directeur levert diens bevindingen op aan de Officier van Justitie.",
"type":"Principe"
}
]
}
,
"108634" : {
"id":108634,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Uitgangspunten - UP WvGGZ",
"type":"Motivatie-elementen"
}
]
}
,
"108642" : {
"id":108642,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP603: De privacy van de betrokkene is in de iWvggz geborgd doordat aangesloten ketenpartijen zich conformeren aan de Algemene Verordening Gegevensbescherming (AVG) en aanvullend daarop de Privacy handreiking Wvggz.",
"type":"Principe"
}
]
}
,
"108688" : {
"id":108688,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP080: Aan het tijdstip waarop en de volgorde waarin berichten worden ontvangen en verwerkt kunnen ketenpartijen geen betekenis hechten.",
"type":"Requirement"
}
]
}
,
"108635" : {
"id":108635,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP001: De Wvggz berichtenfamilie ondersteunt de voorbereiding, uitvoering en toezicht van de zorgmachtiging en de crisismaatregel (ZIN).",
"type":"Principe"
}
]
}
,
"108667" : {
"id":108667,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_AfzenderOntvanger",
"type":"Datatype"
}
]
}
,
"108902" : {
"id":108902,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Grondslagen",
"type":"Datatype"
}
]
}
,
"146321" : {
"id":146321,
"typeIconPath":"data/icons/ArchiMate/RSThreatEvent.png",
"data" : [
{
"name":"Release: iWvggz 1.0.0-rc1",
"type":"Bedreigingsevent"
}
]
}
,
"104151" : {
"id":104151,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BeperkingScore",
"type":"Klassendiagram"
}
]
}
,
"104154" : {
"id":104154,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Organisatienaam",
"type":"Klassendiagram"
}
]
}
,
"104142" : {
"id":104142,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Taal",
"type":"Klassendiagram"
}
]
}
,
"104157" : {
"id":104157,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Communicatievorm",
"type":"Klassendiagram"
}
]
}
,
"104148" : {
"id":104148,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Voorletters",
"type":"Klassendiagram"
}
]
}
,
"152308" : {
"id":152308,
"typeIconPath":"data/icons/ArchiMate/BusinessScheme.png",
"data" : [
{
"name":"Bedrijfslaag",
"type":"Bedrijfslaag"
}
]
}
,
"152339" : {
"id":152339,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"152383" : {
"id":152383,
"typeIconPath":"data/icons/ArchiMate/CompositeScheme.png",
"data" : [
{
"name":"Samengestelde elementen",
"type":"Samengestelde elementen"
}
]
}
,
"152366" : {
"id":152366,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"152374" : {
"id":152374,
"typeIconPath":"data/icons/ArchiMate/ApplicationScheme.png",
"data" : [
{
"name":"Applicatielaag",
"type":"Applicatielaag"
}
]
}
,
"109821" : {
"id":109821,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_JuridischeTitel",
"type":"Datatype"
}
]
}
,
"110216" : {
"id":110216,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Condities - CD WvGGZ",
"type":"Motivatie-elementen"
}
]
}
,
"110401" : {
"id":110401,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Contactgegevens",
"type":"Datatype"
}
]
}
,
"109485" : {
"id":109485,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Invulinstructies - IV WvGGZ",
"type":"Motivatie-elementen"
}
]
}
,
"112310" : {
"id":112310,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG600: Retourcode",
"type":"Enumeratie"
}
]
}
,
"112436" : {
"id":112436,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Client",
"type":"Package"
}
]
}
,
"112438" : {
"id":112438,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Algemene datatypes",
"type":"Package"
}
]
}
,
"112440" : {
"id":112440,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Persoon",
"type":"Package"
}
]
}
,
"112442" : {
"id":112442,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Primitive type",
"type":"Package"
}
]
}
,
"112444" : {
"id":112444,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Contactgegevens",
"type":"Package"
}
]
}
,
"112491" : {
"id":112491,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_AdresWvggz",
"type":"Datatype"
}
]
}
,
"112432" : {
"id":112432,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Berichtinformatie",
"type":"Package"
}
]
}
,
"112434" : {
"id":112434,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Adres",
"type":"Package"
}
]
}
,
"112568" : {
"id":112568,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BEP_BEW_VRIJHEID",
"type":"Enumeratiewaarde"
}
]
}
,
"112570" : {
"id":112570,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TOED_VOCHT_VOED",
"type":"Enumeratiewaarde"
}
]
}
,
"112573" : {
"id":112573,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"OND_KLED_LICH",
"type":"Enumeratiewaarde"
}
]
}
,
"112569" : {
"id":112569,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AANB_BEP_VRIJHEID",
"type":"Enumeratiewaarde"
}
]
}
,
"112574" : {
"id":112574,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"OND_WOON_VERBLIJF",
"type":"Enumeratiewaarde"
}
]
}
,
"112571" : {
"id":112571,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BEP_RECHT_BEZOEK",
"type":"Enumeratiewaarde"
}
]
}
,
"112572" : {
"id":112572,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"CONTR_MIDDELEN",
"type":"Enumeratiewaarde"
}
]
}
,
"112578" : {
"id":112578,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TOED_MED",
"type":"Enumeratiewaarde"
}
]
}
,
"112575" : {
"id":112575,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"INSLUITEN",
"type":"Enumeratiewaarde"
}
]
}
,
"112580" : {
"id":112580,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"VERR_MED_CONTR_EN_MED_HAND",
"type":"Enumeratiewaarde"
}
]
}
,
"112576" : {
"id":112576,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TOEZICHT",
"type":"Enumeratiewaarde"
}
]
}
,
"192195" : {
"id":192195,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"192154" : {
"id":192154,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD609: als Organisatiesoort gevuld is met '01', dan Identificatie vullen met 'OM'.",
"type":"Beperking"
}
]
}
,
"192152" : {
"id":192152,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"UP606: Een aanvraag voor een zorgmachtiging kan worden ingediend door verschillende partijen, zoals benoemd in de wet.",
"type":"Principe"
}
]
}
,
"192196" : {
"id":192196,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"192197" : {
"id":192197,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"192155" : {
"id":192155,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD610: als Organisatiesoort gevuld is met '02', dan Identificatie vullen met het handelsregisternummer (KVK-nummer) van de zorg leverende zorgaanbieder.",
"type":"Beperking"
}
]
}
,
"117053" : {
"id":117053,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP616: Het nummer van de aanvraag voor een Zorgmachtiging wordt uitgegeven door de partij die de aanvraag indient.",
"type":"Requirement"
}
]
}
,
"192157" : {
"id":192157,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD612: als Organisatiesoort gevuld is met '04', dan Identificatie vullen met 'PVP'.",
"type":"Beperking"
}
]
}
,
"192156" : {
"id":192156,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD611: als Organisatiesoort gevuld is met '03,'dan Identificatie vullen met 'IGJ'.",
"type":"Beperking"
}
]
}
,
"192158" : {
"id":192158,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP617: Iedere aanvraag voor een Zorgmachtiging heeft een uniek identificerend aanvraagnummer.",
"type":"Requirement"
}
]
}
,
"26861" : {
"id":26861,
"typeIconPath":"data/icons/BPMN/BPMNMM_Model.png",
"data" : [
{
"name":"Processen WvGGZ",
"type":"BPMN-model"
}
]
}
,
"26889" : {
"id":26889,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Identificatie",
"type":"Klassendiagram"
}
]
}
,
"26871" : {
"id":26871,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_ArrondissementsParket",
"type":"Klassendiagram"
}
]
}
,
"26924" : {
"id":26924,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Koppelviews",
"type":"ArchiMate-model"
}
]
}
,
"26935" : {
"id":26935,
"typeIconPath":"data/icons/UML/UMLMM_Model.png",
"data" : [
{
"name":"Gegevens WvGGZ",
"type":"UML-model"
}
]
}
,
"26904" : {
"id":26904,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG101",
"type":"Klassendiagram"
}
]
}
,
"26973" : {
"id":26973,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG103",
"type":"Klassendiagram"
}
]
}
,
"26952" : {
"id":26952,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Viewpoints",
"type":"ArchiMate-model"
}
]
}
,
"26976" : {
"id":26976,
"typeIconPath":"data/icons/UML/UMLMM_Model.png",
"data" : [
{
"name":"Berichten en datatypen",
"type":"UML-model"
}
]
}
,
"26999" : {
"id":26999,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_GrondslagSoort",
"type":"Klassendiagram"
}
]
}
,
"27052" : {
"id":27052,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Views inSite rapportage",
"type":"ArchiMate-model"
}
]
}
,
"27051" : {
"id":27051,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Koppelingen iWvggz 1.0",
"type":"Totaalview"
}
]
}
,
"66118" : {
"id":66118,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG111",
"type":"Klassendiagram"
}
]
}
,
"26845" : {
"id":26845,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Processen en regels",
"type":"ArchiMate-model"
}
]
}
,
"27246" : {
"id":27246,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Contactgegevens",
"type":"Klassendiagram"
}
]
}
,
"27223" : {
"id":27223,
"typeIconPath":"data/icons/MM_ModelPackage/MM_Folder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"27243" : {
"id":27243,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Professional",
"type":"Klassendiagram"
}
]
}
,
"27263" : {
"id":27263,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Regels generiek",
"type":"ArchiMate-model"
}
]
}
,
"27288" : {
"id":27288,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Insite Wvggz",
"type":"ArchiMate-model"
}
]
}
,
"27323" : {
"id":27323,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_OrganisatieSoort",
"type":"Klassendiagram"
}
]
}
,
"27343" : {
"id":27343,
"typeIconPath":"data/icons/UML/UMLMM_Model.png",
"data" : [
{
"name":"Berichten in ontwikkeling",
"type":"UML-model"
}
]
}
,
"27341" : {
"id":27341,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Regels WvGGZ",
"type":"ArchiMate-model"
}
]
}
,
"27399" : {
"id":27399,
"typeIconPath":"data/icons/UML/UMLMM_Model.png",
"data" : [
{
"name":"Berichten generiek",
"type":"UML-model"
}
]
}
,
"27436" : {
"id":27436,
"typeIconPath":"data/icons/UML/UMLMM_Model.png",
"data" : [
{
"name":"Gegevens domeinoverstijgend",
"type":"UML-model"
}
]
}
,
"27506" : {
"id":27506,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_DocumentNaam",
"type":"Klassendiagram"
}
]
}
,
"27511" : {
"id":27511,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Zorgvorm",
"type":"Klassendiagram"
}
]
}
,
"27534" : {
"id":27534,
"typeIconPath":"data/icons/UML/UMLMM_Model.png",
"data" : [
{
"name":"Berichten Wvggz",
"type":"UML-model"
}
]
}
,
"27679" : {
"id":27679,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG113",
"type":"Klassendiagram"
}
]
}
,
"27682" : {
"id":27682,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_DocumentVersie",
"type":"Klassendiagram"
}
]
}
,
"27706" : {
"id":27706,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_RelatieOmgeving",
"type":"Klassendiagram"
}
]
}
,
"27743" : {
"id":27743,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG115",
"type":"Klassendiagram"
}
]
}
,
"27808" : {
"id":27808,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Eenheid",
"type":"Klassendiagram"
}
]
}
,
"27775" : {
"id":27775,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Motivering",
"type":"Klassendiagram"
}
]
}
,
"27860" : {
"id":27860,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_RolProfessional",
"type":"Klassendiagram"
}
]
}
,
"27863" : {
"id":27863,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Aantal",
"type":"Klassendiagram"
}
]
}
,
"27866" : {
"id":27866,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_RetourCode",
"type":"Klassendiagram"
}
]
}
,
"27887" : {
"id":27887,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_AfzenderOntvanger",
"type":"Klassendiagram"
}
]
}
,
"27901" : {
"id":27901,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Beslissing",
"type":"Klassendiagram"
}
]
}
,
"27907" : {
"id":27907,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_AanleidingBevindingen",
"type":"Klassendiagram"
}
]
}
,
"27881" : {
"id":27881,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_ZorgvormCategorie",
"type":"Klassendiagram"
}
]
}
,
"27872" : {
"id":27872,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_NadeelSoort",
"type":"Klassendiagram"
}
]
}
,
"27875" : {
"id":27875,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Diagnose",
"type":"Klassendiagram"
}
]
}
,
"27892" : {
"id":27892,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_VestigingsNummer",
"type":"Klassendiagram"
}
]
}
,
"27869" : {
"id":27869,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG Retour",
"type":"Klassendiagram"
}
]
}
,
"27904" : {
"id":27904,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_AdresWvggz",
"type":"Klassendiagram"
}
]
}
,
"27895" : {
"id":27895,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Rechtbank",
"type":"Klassendiagram"
}
]
}
,
"27910" : {
"id":27910,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_DocumentSoort",
"type":"Klassendiagram"
}
]
}
,
"27878" : {
"id":27878,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_MomentDuur",
"type":"Klassendiagram"
}
]
}
,
"27884" : {
"id":27884,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_DocumentFormaat",
"type":"Klassendiagram"
}
]
}
,
"27095" : {
"id":27095,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_JuridischeTitel",
"type":"Klassendiagram"
}
]
}
,
"27110" : {
"id":27110,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Vervallen regels",
"type":"ArchiMate-model"
}
]
}
,
"27916" : {
"id":27916,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG105",
"type":"Klassendiagram"
}
]
}
,
"27932" : {
"id":27932,
"typeIconPath":"data/icons/MM_ModelPackage/MM_Folder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"27919" : {
"id":27919,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"WVG107",
"type":"Klassendiagram"
}
]
}
,
"70604" : {
"id":70604,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Technische regels - TR WvGGZ",
"type":"Motivatie-elementen"
}
]
}
,
"190584" : {
"id":190584,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190582" : {
"id":190582,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190591" : {
"id":190591,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190581" : {
"id":190581,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190588" : {
"id":190588,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190578" : {
"id":190578,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190579" : {
"id":190579,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190589" : {
"id":190589,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190597" : {
"id":190597,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190598" : {
"id":190598,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190602" : {
"id":190602,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190617" : {
"id":190617,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190609" : {
"id":190609,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190604" : {
"id":190604,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190610" : {
"id":190610,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190600" : {
"id":190600,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190606" : {
"id":190606,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190612" : {
"id":190612,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190616" : {
"id":190616,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190613" : {
"id":190613,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190630" : {
"id":190630,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190638" : {
"id":190638,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190642" : {
"id":190642,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190625" : {
"id":190625,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190627" : {
"id":190627,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190623" : {
"id":190623,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190621" : {
"id":190621,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190639" : {
"id":190639,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190632" : {
"id":190632,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190634" : {
"id":190634,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190557" : {
"id":190557,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190554" : {
"id":190554,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190564" : {
"id":190564,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190571" : {
"id":190571,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190560" : {
"id":190560,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190562" : {
"id":190562,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190572" : {
"id":190572,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190568" : {
"id":190568,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190574" : {
"id":190574,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190565" : {
"id":190565,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190569" : {
"id":190569,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"179210" : {
"id":179210,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BinaireInhoud",
"type":"Klassendiagram"
}
]
}
,
"178930" : {
"id":178930,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces persoonsgegevens betrokkene verstrekken",
"type":"Collaboration"
}
]
}
,
"178935" : {
"id":178935,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Vul 'waar gebruikt' voor rapportage",
"type":"Totaalview"
}
]
}
,
"178921" : {
"id":178921,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178927" : {
"id":178927,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene  verstrekken",
"type":"Choreography"
}
]
}
,
"178918" : {
"id":178918,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9616",
"type":"Enumeratiewaarde"
}
]
}
,
"178913" : {
"id":178913,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Stichting PVP",
"type":"Process"
}
]
}
,
"178917" : {
"id":178917,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"BeperkingScore",
"type":"Klasse"
}
]
}
,
"178924" : {
"id":178924,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"TR056: Identificatie moet per berichtsoort uniek zijn voor de verzendende partij.",
"type":"Beperking"
}
]
}
,
"178916" : {
"id":178916,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces indiening VCM mededelen",
"type":"Collaboration"
}
]
}
,
"178976" : {
"id":178976,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces ZM aanragen",
"type":"Collaboration"
}
]
}
,
"178964" : {
"id":178964,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process"
}
]
}
,
"178967" : {
"id":178967,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178981" : {
"id":178981,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"IGJ",
"type":"Process"
}
]
}
,
"178941" : {
"id":178941,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Aanvrager",
"type":"Process"
}
]
}
,
"178956" : {
"id":178956,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178953" : {
"id":178953,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178959" : {
"id":178959,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process"
}
]
}
,
"178944" : {
"id":178944,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration"
}
]
}
,
"178947" : {
"id":178947,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Process"
}
]
}
,
"178938" : {
"id":178938,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources"
}
]
}
,
"178970" : {
"id":178970,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography"
}
]
}
,
"178973" : {
"id":178973,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces medisch onderzoeken",
"type":"Collaboration"
}
]
}
,
"178950" : {
"id":178950,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration"
}
]
}
,
"179027" : {
"id":179027,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography"
}
]
}
,
"178997" : {
"id":178997,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (procesmodel)",
"type":"Collaboration"
}
]
}
,
"179003" : {
"id":179003,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"name":"proces bevindingen beoordelen",
"type":"Collaboration"
}
]
}
,
"178989" : {
"id":178989,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Datatypen",
"type":"Totaalview"
}
]
}
,
"179000" : {
"id":179000,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"178992" : {
"id":178992,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"Waardeketen iWvggz",
"type":"Choreography"
}
]
}
,
"179010" : {
"id":179010,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"OM",
"type":"Process"
}
]
}
,
"179016" : {
"id":179016,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography"
}
]
}
,
"179019" : {
"id":179019,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"name":"iWvGGZ-rollen",
"type":"Resources"
}
]
}
,
"179022" : {
"id":179022,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"name":"Zorgaanbieder",
"type":"Process"
}
]
}
,
"179013" : {
"id":179013,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"name":"ZM voorbereiden - Choreografiemodel",
"type":"Choreography"
}
]
}
,
"179104" : {
"id":179104,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"CS generiek",
"type":"Totaalview"
}
]
}
,
"179107" : {
"id":179107,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Opmaak rapportage werkwijze",
"type":"Totaalview"
}
]
}
,
"179110" : {
"id":179110,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Bronnen en registers",
"type":"Totaalview"
}
]
}
,
"179078" : {
"id":179078,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Uitgangspunten",
"type":"Totaalview"
}
]
}
,
"179075" : {
"id":179075,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Condities",
"type":"Totaalview"
}
]
}
,
"179083" : {
"id":179083,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Bedrijfsregels",
"type":"Totaalview"
}
]
}
,
"179149" : {
"id":179149,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BerichtVersie",
"type":"Klassendiagram"
}
]
}
,
"179141" : {
"id":179141,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_IdentificatieBerichtWvg",
"type":"Klassendiagram"
}
]
}
,
"179113" : {
"id":179113,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"XLS output tabellen J/N=N",
"type":"Totaalview"
}
]
}
,
"179136" : {
"id":179136,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_ReferentieNummer",
"type":"Klassendiagram"
}
]
}
,
"179120" : {
"id":179120,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"Datatype werkwijze",
"type":"Klassendiagram"
}
]
}
,
"179125" : {
"id":179125,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"name":"Landingspagina",
"type":"Totaalview"
}
]
}
,
"179144" : {
"id":179144,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BerichtType",
"type":"Klassendiagram"
}
]
}
,
"183248" : {
"id":183248,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"053",
"type":"Enumeratiewaarde"
}
]
}
,
"183256" : {
"id":183256,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"058",
"type":"Enumeratiewaarde"
}
]
}
,
"183268" : {
"id":183268,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"072",
"type":"Enumeratiewaarde"
}
]
}
,
"183244" : {
"id":183244,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"049",
"type":"Enumeratiewaarde"
}
]
}
,
"183264" : {
"id":183264,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"068",
"type":"Enumeratiewaarde"
}
]
}
,
"183270" : {
"id":183270,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"073",
"type":"Enumeratiewaarde"
}
]
}
,
"183250" : {
"id":183250,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"055",
"type":"Enumeratiewaarde"
}
]
}
,
"183254" : {
"id":183254,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"057",
"type":"Enumeratiewaarde"
}
]
}
,
"183252" : {
"id":183252,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"056",
"type":"Enumeratiewaarde"
}
]
}
,
"183276" : {
"id":183276,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"077",
"type":"Enumeratiewaarde"
}
]
}
,
"183240" : {
"id":183240,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"047",
"type":"Enumeratiewaarde"
}
]
}
,
"183224" : {
"id":183224,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"038",
"type":"Enumeratiewaarde"
}
]
}
,
"183238" : {
"id":183238,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"046",
"type":"Enumeratiewaarde"
}
]
}
,
"183222" : {
"id":183222,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"037",
"type":"Enumeratiewaarde"
}
]
}
,
"183228" : {
"id":183228,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"040",
"type":"Enumeratiewaarde"
}
]
}
,
"183274" : {
"id":183274,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"076",
"type":"Enumeratiewaarde"
}
]
}
,
"183266" : {
"id":183266,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"069",
"type":"Enumeratiewaarde"
}
]
}
,
"183278" : {
"id":183278,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"079",
"type":"Enumeratiewaarde"
}
]
}
,
"183218" : {
"id":183218,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"034",
"type":"Enumeratiewaarde"
}
]
}
,
"183226" : {
"id":183226,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"039",
"type":"Enumeratiewaarde"
}
]
}
,
"183272" : {
"id":183272,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"074",
"type":"Enumeratiewaarde"
}
]
}
,
"183230" : {
"id":183230,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"041",
"type":"Enumeratiewaarde"
}
]
}
,
"183258" : {
"id":183258,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"059",
"type":"Enumeratiewaarde"
}
]
}
,
"183260" : {
"id":183260,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"060",
"type":"Enumeratiewaarde"
}
]
}
,
"183220" : {
"id":183220,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"035",
"type":"Enumeratiewaarde"
}
]
}
,
"183232" : {
"id":183232,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"042",
"type":"Enumeratiewaarde"
}
]
}
,
"183236" : {
"id":183236,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"044",
"type":"Enumeratiewaarde"
}
]
}
,
"183242" : {
"id":183242,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"048",
"type":"Enumeratiewaarde"
}
]
}
,
"183262" : {
"id":183262,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"067",
"type":"Enumeratiewaarde"
}
]
}
,
"183234" : {
"id":183234,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"043",
"type":"Enumeratiewaarde"
}
]
}
,
"183246" : {
"id":183246,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"050",
"type":"Enumeratiewaarde"
}
]
}
,
"183216" : {
"id":183216,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"033",
"type":"Enumeratiewaarde"
}
]
}
,
"183287" : {
"id":183287,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"43",
"type":"Enumeratiewaarde"
}
]
}
,
"183311" : {
"id":183311,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183341" : {
"id":183341,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Soort",
"type":"Attribuut"
}
]
}
,
"183326" : {
"id":183326,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Commentaar",
"type":"Attribuut"
}
]
}
,
"183327" : {
"id":183327,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183332" : {
"id":183332,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersieRetour",
"type":"Attribuut"
}
]
}
,
"183334" : {
"id":183334,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Soort",
"type":"Attribuut"
}
]
}
,
"183338" : {
"id":183338,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_BerichtIdentificatie",
"type":"Datatype"
}
]
}
,
"183302" : {
"id":183302,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"40",
"type":"Enumeratiewaarde"
}
]
}
,
"183291" : {
"id":183291,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183336" : {
"id":183336,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslacht",
"type":"Attribuut"
}
]
}
,
"183339" : {
"id":183339,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Periode",
"type":"Attribuut"
}
]
}
,
"183342" : {
"id":183342,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"183298" : {
"id":183298,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"42",
"type":"Enumeratiewaarde"
}
]
}
,
"183320" : {
"id":183320,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BetalingAanID",
"type":"Attribuut"
}
]
}
,
"183333" : {
"id":183333,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183308" : {
"id":183308,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183282" : {
"id":183282,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"46",
"type":"Enumeratiewaarde"
}
]
}
,
"183305" : {
"id":183305,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183323" : {
"id":183323,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183324" : {
"id":183324,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"183325" : {
"id":183325,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183313" : {
"id":183313,
"typeIconPath":"data/icons/UML/UML_PrimitiveType.png",
"data" : [
{
"name":"time",
"type":"Primitief type"
}
]
}
,
"183322" : {
"id":183322,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DagtekeningRetour",
"type":"Attribuut"
}
]
}
,
"183337" : {
"id":183337,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"183285" : {
"id":183285,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"41",
"type":"Enumeratiewaarde"
}
]
}
,
"183317" : {
"id":183317,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183328" : {
"id":183328,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"183280" : {
"id":183280,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"49",
"type":"Enumeratiewaarde"
}
]
}
,
"183289" : {
"id":183289,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"50",
"type":"Enumeratiewaarde"
}
]
}
,
"183294" : {
"id":183294,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"47",
"type":"Enumeratiewaarde"
}
]
}
,
"183315" : {
"id":183315,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DeclaratieFactuurIdentificatie",
"type":"Attribuut"
}
]
}
,
"183300" : {
"id":183300,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"48",
"type":"Enumeratiewaarde"
}
]
}
,
"183318" : {
"id":183318,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Volgorde",
"type":"Attribuut"
}
]
}
,
"183296" : {
"id":183296,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"45",
"type":"Enumeratiewaarde"
}
]
}
,
"183331" : {
"id":183331,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Adres",
"type":"Attribuut"
}
]
}
,
"183329" : {
"id":183329,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"RetourBedragen",
"type":"Attribuut"
}
]
}
,
"183319" : {
"id":183319,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Nummer",
"type":"Attribuut"
}
]
}
,
"183335" : {
"id":183335,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboortedatum",
"type":"Attribuut"
}
]
}
,
"183340" : {
"id":183340,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_OpenPeriode",
"type":"Datatype"
}
]
}
,
"183380" : {
"id":183380,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183346" : {
"id":183346,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"RetourCodes",
"type":"Klasse"
}
]
}
,
"183364" : {
"id":183364,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Commentaar",
"type":"Attribuut"
}
]
}
,
"183377" : {
"id":183377,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183368" : {
"id":183368,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboortedatum",
"type":"Attribuut"
}
]
}
,
"183384" : {
"id":183384,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183400" : {
"id":183400,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BetalingAanID",
"type":"Attribuut"
}
]
}
,
"183373" : {
"id":183373,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Emailadres",
"type":"Attribuut"
}
]
}
,
"183367" : {
"id":183367,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Soort",
"type":"Attribuut"
}
]
}
,
"183374" : {
"id":183374,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Servicebureau",
"type":"Attribuut"
}
]
}
,
"183387" : {
"id":183387,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183389" : {
"id":183389,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183402" : {
"id":183402,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DeclaratieFactuurIdentificatie",
"type":"Attribuut"
}
]
}
,
"183366" : {
"id":183366,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Volgorde",
"type":"Attribuut"
}
]
}
,
"183392" : {
"id":183392,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"183371" : {
"id":183371,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Soort",
"type":"Attribuut"
}
]
}
,
"183349" : {
"id":183349,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"183358" : {
"id":183358,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Relatie Wlz",
"type":"Package"
}
]
}
,
"183378" : {
"id":183378,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Voorbeeld klassen",
"type":"Package"
}
]
}
,
"183379" : {
"id":183379,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Client",
"type":"Klasse"
}
]
}
,
"183382" : {
"id":183382,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Score",
"type":"Attribuut"
}
]
}
,
"183345" : {
"id":183345,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"183376" : {
"id":183376,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Commentaar",
"type":"Attribuut"
}
]
}
,
"183369" : {
"id":183369,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslacht",
"type":"Attribuut"
}
]
}
,
"183390" : {
"id":183390,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183395" : {
"id":183395,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183372" : {
"id":183372,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Telefoon",
"type":"Attribuut"
}
]
}
,
"183359" : {
"id":183359,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Emailadres",
"type":"Attribuut"
}
]
}
,
"183361" : {
"id":183361,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183343" : {
"id":183343,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Nummer",
"type":"Attribuut"
}
]
}
,
"183370" : {
"id":183370,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183388" : {
"id":183388,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183352" : {
"id":183352,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Prognose",
"type":"Attribuut"
}
]
}
,
"183391" : {
"id":183391,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Retourberichtklassen",
"type":"Package"
}
]
}
,
"183356" : {
"id":183356,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Telefoon",
"type":"Attribuut"
}
]
}
,
"183350" : {
"id":183350,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Bsn",
"type":"Attribuut"
}
]
}
,
"183357" : {
"id":183357,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183351" : {
"id":183351,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183354" : {
"id":183354,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Categorie",
"type":"Attribuut"
}
]
}
,
"183375" : {
"id":183375,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Duur",
"type":"Attribuut"
}
]
}
,
"183393" : {
"id":183393,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DiagnoseSubcodelijst",
"type":"Attribuut"
}
]
}
,
"183355" : {
"id":183355,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboortedatum",
"type":"Attribuut"
}
]
}
,
"183362" : {
"id":183362,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"RetourCode",
"type":"Attribuut"
}
]
}
,
"183398" : {
"id":183398,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Gemeente",
"type":"Attribuut"
}
]
}
,
"183383" : {
"id":183383,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Commentaar",
"type":"Attribuut"
}
]
}
,
"183360" : {
"id":183360,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Periode",
"type":"Attribuut"
}
]
}
,
"183399" : {
"id":183399,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Aanbieder",
"type":"Attribuut"
}
]
}
,
"183403" : {
"id":183403,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DeclaratieFactuurBedragen",
"type":"Attribuut"
}
]
}
,
"183386" : {
"id":183386,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"183405" : {
"id":183405,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183396" : {
"id":183396,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183406" : {
"id":183406,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Gemeente",
"type":"Attribuut"
}
]
}
,
"183348" : {
"id":183348,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"183401" : {
"id":183401,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183381" : {
"id":183381,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Vraag",
"type":"Attribuut"
}
]
}
,
"183385" : {
"id":183385,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"183347" : {
"id":183347,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"IdentificatieRetour",
"type":"Attribuut"
}
]
}
,
"183344" : {
"id":183344,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183397" : {
"id":183397,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183365" : {
"id":183365,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Adres",
"type":"Attribuut"
}
]
}
,
"183412" : {
"id":183412,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersieRetour",
"type":"Attribuut"
}
]
}
,
"183437" : {
"id":183437,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183438" : {
"id":183438,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"ClientClass",
"type":"Klasse"
}
]
}
,
"183460" : {
"id":183460,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"183425" : {
"id":183425,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Commentaar",
"type":"Attribuut"
}
]
}
,
"183434" : {
"id":183434,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslacht",
"type":"Attribuut"
}
]
}
,
"183407" : {
"id":183407,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Servicebureau",
"type":"Attribuut"
}
]
}
,
"183442" : {
"id":183442,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183440" : {
"id":183440,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Contactgegevens Wlz",
"type":"Package"
}
]
}
,
"183431" : {
"id":183431,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183416" : {
"id":183416,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"183446" : {
"id":183446,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183455" : {
"id":183455,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Relatie Wmo/Jw",
"type":"Package"
}
]
}
,
"183465" : {
"id":183465,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183458" : {
"id":183458,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"183466" : {
"id":183466,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Contactgegevens Wmo/Jw",
"type":"Package"
}
]
}
,
"183467" : {
"id":183467,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183469" : {
"id":183469,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183439" : {
"id":183439,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183468" : {
"id":183468,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Overige_berichtklassen",
"type":"Klasse"
}
]
}
,
"183450" : {
"id":183450,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslacht",
"type":"Attribuut"
}
]
}
,
"183452" : {
"id":183452,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183463" : {
"id":183463,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183470" : {
"id":183470,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header Zorgkantoor - Zorgkantoor",
"type":"Package"
}
]
}
,
"183411" : {
"id":183411,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsltVersie",
"type":"Attribuut"
}
]
}
,
"183426" : {
"id":183426,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Grondslag",
"type":"Attribuut"
}
]
}
,
"183414" : {
"id":183414,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183444" : {
"id":183444,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"183424" : {
"id":183424,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Client CA317/319",
"type":"Package"
}
]
}
,
"183432" : {
"id":183432,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183417" : {
"id":183417,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183447" : {
"id":183447,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183436" : {
"id":183436,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboortedatum",
"type":"Attribuut"
}
]
}
,
"183449" : {
"id":183449,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboortedatum",
"type":"Attribuut"
}
]
}
,
"183454" : {
"id":183454,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183423" : {
"id":183423,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183415" : {
"id":183415,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"183421" : {
"id":183421,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Score",
"type":"Attribuut"
}
]
}
,
"183409" : {
"id":183409,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"RetourHeader",
"type":"Attribuut"
}
]
}
,
"183418" : {
"id":183418,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Vraag",
"type":"Attribuut"
}
]
}
,
"183413" : {
"id":183413,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183429" : {
"id":183429,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZiektebeeldStoornis",
"type":"Attribuut"
}
]
}
,
"183433" : {
"id":183433,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Bsn",
"type":"Attribuut"
}
]
}
,
"183443" : {
"id":183443,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"183445" : {
"id":183445,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtCode",
"type":"Attribuut"
}
]
}
,
"183435" : {
"id":183435,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"183441" : {
"id":183441,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"183420" : {
"id":183420,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183448" : {
"id":183448,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Bsn",
"type":"Attribuut"
}
]
}
,
"183451" : {
"id":183451,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183408" : {
"id":183408,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Aanbieder",
"type":"Attribuut"
}
]
}
,
"183427" : {
"id":183427,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DiagnoseCodelijst",
"type":"Attribuut"
}
]
}
,
"183453" : {
"id":183453,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"183456" : {
"id":183456,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"183457" : {
"id":183457,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183461" : {
"id":183461,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"183462" : {
"id":183462,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"183464" : {
"id":183464,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"183478" : {
"id":183478,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WMO/JW Retour",
"type":"Package"
}
]
}
,
"183499" : {
"id":183499,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"Technische regel",
"type":"Beperking"
}
]
}
,
"183486" : {
"id":183486,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"BeperkingScore generiek",
"type":"Package"
}
]
}
,
"183477" : {
"id":183477,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183493" : {
"id":183493,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_RetourCode",
"type":"Datatype"
}
]
}
,
"183495" : {
"id":183495,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"IV",
"type":"Associatierelatie"
}
]
}
,
"183498" : {
"id":183498,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"TR",
"type":"Associatierelatie"
}
]
}
,
"183475" : {
"id":183475,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183512" : {
"id":183512,
"typeIconPath":"data/icons/ArchiMate/BusinessProcess.png",
"data" : [
{
"name":"Proces",
"type":"Bedrijfsproces"
}
]
}
,
"183476" : {
"id":183476,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183509" : {
"id":183509,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"Bedrijfsregel",
"type":"Requirement"
}
]
}
,
"183515" : {
"id":183515,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"IV",
"type":"Associatierelatie"
}
]
}
,
"183517" : {
"id":183517,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"Uitzondering",
"type":"Requirement"
}
]
}
,
"183520" : {
"id":183520,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"OP",
"type":"Associatierelatie"
}
]
}
,
"183524" : {
"id":183524,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183471" : {
"id":183471,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"183529" : {
"id":183529,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD controleren",
"type":"Task"
}
]
}
,
"183491" : {
"id":183491,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183481" : {
"id":183481,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Beperking generiek",
"type":"Package"
}
]
}
,
"183502" : {
"id":183502,
"typeIconPath":"data/icons/ArchiMate/BusinessObject.png",
"data" : [
{
"name":"Berichtklasse inhoud",
"type":"Bedrijfsobject"
}
]
}
,
"183504" : {
"id":183504,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"CS",
"type":"Associatierelatie"
}
]
}
,
"183511" : {
"id":183511,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"OP",
"type":"Associatierelatie"
}
]
}
,
"183525" : {
"id":183525,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"183483" : {
"id":183483,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"RootClass",
"type":"Klasse"
}
]
}
,
"183485" : {
"id":183485,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183503" : {
"id":183503,
"typeIconPath":"data/icons/ArchiMate/RelationElementAssociation.png",
"data" : [
{
"name":"CS/RS",
"type":"Associatierelatie"
}
]
}
,
"183514" : {
"id":183514,
"typeIconPath":"data/icons/ArchiMate/MotivationPrinciple.png",
"data" : [
{
"name":"Uitgangspunt",
"type":"Principe"
}
]
}
,
"183530" : {
"id":183530,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht bevindingen GD verzenden",
"type":"Task"
}
]
}
,
"183526" : {
"id":183526,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht bevindingen GD valide?",
"type":"Gateway"
}
]
}
,
"183492" : {
"id":183492,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"RetourCode",
"type":"Attribuut"
}
]
}
,
"183472" : {
"id":183472,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183490" : {
"id":183490,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"MessageClass",
"type":"Klasse"
}
]
}
,
"183480" : {
"id":183480,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183496" : {
"id":183496,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"Invulinstructie",
"type":"Usecase"
}
]
}
,
"183510" : {
"id":183510,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"Constraint",
"type":"Beperking"
}
]
}
,
"183482" : {
"id":183482,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183474" : {
"id":183474,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Rootklasse",
"type":"Klasse"
}
]
}
,
"183487" : {
"id":183487,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183513" : {
"id":183513,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatie",
"type":"Realisatierelatie"
}
]
}
,
"183488" : {
"id":183488,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"RetourCodes",
"type":"Klasse"
}
]
}
,
"183484" : {
"id":183484,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183516" : {
"id":183516,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationRequirementSpecialization.png",
"data" : [
{
"name":"Specialisatie",
"type":"Specialisatierelatie"
}
]
}
,
"183518" : {
"id":183518,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationRequirementSpecialization.png",
"data" : [
{
"name":"Specialisatierelatie",
"type":"Specialisatierelatie"
}
]
}
,
"183519" : {
"id":183519,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"xsd restrictie",
"type":"Beperking"
}
]
}
,
"183527" : {
"id":183527,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD is niet valide",
"type":"End event"
}
]
}
,
"183505" : {
"id":183505,
"typeIconPath":"data/icons/ArchiMate/BusinessObject.png",
"data" : [
{
"name":"Datatype",
"type":"Bedrijfsobject"
}
]
}
,
"183528" : {
"id":183528,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183489" : {
"id":183489,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183531" : {
"id":183531,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"183508" : {
"id":183508,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatie",
"type":"Associatierelatie"
}
]
}
,
"183532" : {
"id":183532,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bevindingen GD is ontvangen",
"type":"End event"
}
]
}
,
"183533" : {
"id":183533,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183534" : {
"id":183534,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD Ontvangen",
"type":"Task"
}
]
}
,
"183473" : {
"id":183473,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"183501" : {
"id":183501,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"TR",
"type":"Associatierelatie"
}
]
}
,
"183507" : {
"id":183507,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"Conditie",
"type":"Beperking"
}
]
}
,
"183535" : {
"id":183535,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183500" : {
"id":183500,
"typeIconPath":"data/icons/ArchiMate/BusinessObject.png",
"data" : [
{
"name":"Berichtelement of Attribuut binnen CDT",
"type":"Bedrijfsobject"
}
]
}
,
"183479" : {
"id":183479,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"183497" : {
"id":183497,
"typeIconPath":"data/icons/ArchiMate/BusinessObject.png",
"data" : [
{
"name":"Berichtklasse root",
"type":"Bedrijfsobject"
}
]
}
,
"183506" : {
"id":183506,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"CD",
"type":"Associatierelatie"
}
]
}
,
"183539" : {
"id":183539,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183575" : {
"id":183575,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183586" : {
"id":183586,
"typeIconPath":"data/icons/ArchiMate/BusinessActivity.png",
"data" : [
{
"name":"Processtap",
"type":"Bedrijfsactiviteit"
}
]
}
,
"183592" : {
"id":183592,
"typeIconPath":"data/icons/ArchiMate/BusinessProcess.png",
"data" : [
{
"name":"Subproces",
"type":"Bedrijfsproces"
}
]
}
,
"183595" : {
"id":183595,
"typeIconPath":"data/icons/ArchiMate/TriggeringRelation.png",
"data" : [
{
"name":"Triggeringrelatie",
"type":"Triggeringrelatie"
}
]
}
,
"183597" : {
"id":183597,
"typeIconPath":"data/icons/ArchiMate/ApplicationDataObject.png",
"data" : [
{
"name":"Bestand",
"type":"Dataobject"
}
]
}
,
"183579" : {
"id":183579,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183599" : {
"id":183599,
"typeIconPath":"data/icons/ArchiMate/BusinessEventBusinessProcessTriggering.png",
"data" : [
{
"name":"Triggeringrelatie",
"type":"Triggeringrelatie"
}
]
}
,
"183536" : {
"id":183536,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183537" : {
"id":183537,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"183547" : {
"id":183547,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183582" : {
"id":183582,
"typeIconPath":"data/icons/ArchiMate/BusinessProcessBusinessProcessTriggering.png",
"data" : [
{
"name":"Triggeringrelatie",
"type":"Triggeringrelatie"
}
]
}
,
"183584" : {
"id":183584,
"typeIconPath":"data/icons/ArchiMate/Junction.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183588" : {
"id":183588,
"typeIconPath":"data/icons/ArchiMate/BusinessEvent.png",
"data" : [
{
"name":"Trigger",
"type":"Bedrijfsevent"
}
]
}
,
"183590" : {
"id":183590,
"typeIconPath":"data/icons/ArchiMate/TriggeringRelation.png",
"data" : [
{
"name":"Triggeringrelatie",
"type":"Triggeringrelatie"
}
]
}
,
"183649" : {
"id":183649,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183650" : {
"id":183650,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183652" : {
"id":183652,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183653" : {
"id":183653,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183609" : {
"id":183609,
"typeIconPath":"data/icons/ArchiMate/BusinessProcessApplicationDataObjectAccess.png",
"data" : [
{
"name":"Toegangsrelatie",
"type":"Toegangsrelatie"
}
]
}
,
"183654" : {
"id":183654,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183655" : {
"id":183655,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183656" : {
"id":183656,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183658" : {
"id":183658,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183627" : {
"id":183627,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"183659" : {
"id":183659,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183657" : {
"id":183657,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183661" : {
"id":183661,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Organisatiesoort",
"type":"Attribuut"
}
]
}
,
"183634" : {
"id":183634,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Telefoon02",
"type":"Attribuut"
}
]
}
,
"183623" : {
"id":183623,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183601" : {
"id":183601,
"typeIconPath":"data/icons/ArchiMate/BusinessProcessApplicationDataObjectAccess.png",
"data" : [
{
"name":"Toegangsrelatie",
"type":"Toegangsrelatie"
}
]
}
,
"183611" : {
"id":183611,
"typeIconPath":"data/icons/ArchiMate/BusinessRoleBusinessProcessAssignment.png",
"data" : [
{
"name":"Toekenningsrelatie",
"type":"Toekenningsrelatie"
}
]
}
,
"183631" : {
"id":183631,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0",
"type":"Enumeratiewaarde"
}
]
}
,
"183617" : {
"id":183617,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"183640" : {
"id":183640,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"183637" : {
"id":183637,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183603" : {
"id":183603,
"typeIconPath":"data/icons/ArchiMate/BusinessRole.png",
"data" : [
{
"name":"Bedrijfsrol",
"type":"Bedrijfsrol"
}
]
}
,
"183607" : {
"id":183607,
"typeIconPath":"data/icons/ArchiMate/BusinessRoleBusinessProcessAssignment.png",
"data" : [
{
"name":"Toekenningsrelatie",
"type":"Toekenningsrelatie"
}
]
}
,
"183605" : {
"id":183605,
"typeIconPath":"data/icons/ArchiMate/BusinessRoleBusinessProcessAssignment.png",
"data" : [
{
"name":"Toekenningsrelatie",
"type":"Toekenningsrelatie"
}
]
}
,
"183614" : {
"id":183614,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"183621" : {
"id":183621,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183636" : {
"id":183636,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Telefoon01",
"type":"Attribuut"
}
]
}
,
"183629" : {
"id":183629,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"183639" : {
"id":183639,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183642" : {
"id":183642,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183646" : {
"id":183646,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183647" : {
"id":183647,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183648" : {
"id":183648,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183692" : {
"id":183692,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183721" : {
"id":183721,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"183725" : {
"id":183725,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aavragen",
"type":"Lane"
}
]
}
,
"183710" : {
"id":183710,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BY",
"type":"Enumeratiewaarde"
}
]
}
,
"183706" : {
"id":183706,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WW",
"type":"Enumeratiewaarde"
}
]
}
,
"183713" : {
"id":183713,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"TO",
"type":"Enumeratiewaarde"
}
]
}
,
"183678" : {
"id":183678,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183667" : {
"id":183667,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183673" : {
"id":183673,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"183676" : {
"id":183676,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"183684" : {
"id":183684,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183700" : {
"id":183700,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183698" : {
"id":183698,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183686" : {
"id":183686,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183708" : {
"id":183708,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183671" : {
"id":183671,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD747: Communicatievorm",
"type":"Enumeratie"
}
]
}
,
"183683" : {
"id":183683,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183690" : {
"id":183690,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183680" : {
"id":183680,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Bedrijfsregels tabel 2.0 (fix iwvggz)",
"type":"Grafiek"
}
]
}
,
"183694" : {
"id":183694,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183693" : {
"id":183693,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183665" : {
"id":183665,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"183689" : {
"id":183689,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183695" : {
"id":183695,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183685" : {
"id":183685,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183701" : {
"id":183701,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183703" : {
"id":183703,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AB",
"type":"Enumeratiewaarde"
}
]
}
,
"183669" : {
"id":183669,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183715" : {
"id":183715,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183688" : {
"id":183688,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183687" : {
"id":183687,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183784" : {
"id":183784,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183789" : {
"id":183789,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"183741" : {
"id":183741,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183791" : {
"id":183791,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"183762" : {
"id":183762,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"183730" : {
"id":183730,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM opstellen",
"type":"Task"
}
]
}
,
"183738" : {
"id":183738,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanvraag ZM versturen",
"type":"Task"
}
]
}
,
"183752" : {
"id":183752,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183759" : {
"id":183759,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"183785" : {
"id":183785,
"typeIconPath":"data/icons/BPMN/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"183733" : {
"id":183733,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanvragen ZM is gestart",
"type":"Start event"
}
]
}
,
"183787" : {
"id":183787,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD749: Duur",
"type":"Enumeratie"
}
]
}
,
"183749" : {
"id":183749,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183744" : {
"id":183744,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183810" : {
"id":183810,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183795" : {
"id":183795,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"183825" : {
"id":183825,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"183797" : {
"id":183797,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183836" : {
"id":183836,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183838" : {
"id":183838,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM verzenden",
"type":"Task"
}
]
}
,
"183806" : {
"id":183806,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Voorletters",
"type":"Attribuut"
}
]
}
,
"183808" : {
"id":183808,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslachtsnaam",
"type":"Attribuut"
}
]
}
,
"183841" : {
"id":183841,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM ontvangen",
"type":"Task"
}
]
}
,
"183847" : {
"id":183847,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medische Verklaring verzenden",
"type":"Task"
}
]
}
,
"183853" : {
"id":183853,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD is niet valide",
"type":"End event"
}
]
}
,
"183793" : {
"id":183793,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4",
"type":"Enumeratiewaarde"
}
]
}
,
"183828" : {
"id":183828,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD opstellen",
"type":"Task"
}
]
}
,
"183848" : {
"id":183848,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183835" : {
"id":183835,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Psychiatrisch onderzoek uitvoeren",
"type":"Task"
}
]
}
,
"183854" : {
"id":183854,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183823" : {
"id":183823,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"183831" : {
"id":183831,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183837" : {
"id":183837,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"183824" : {
"id":183824,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanwijzing GD valide?",
"type":"Gateway"
}
]
}
,
"183801" : {
"id":183801,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183815" : {
"id":183815,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183830" : {
"id":183830,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD verzenden",
"type":"Task"
}
]
}
,
"183839" : {
"id":183839,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183842" : {
"id":183842,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183849" : {
"id":183849,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht bevindingen GD verzenden",
"type":"Task"
}
]
}
,
"183845" : {
"id":183845,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183804" : {
"id":183804,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Voornamen",
"type":"Attribuut"
}
]
}
,
"183827" : {
"id":183827,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Pva, zorgplan en/of zorgkaart beoordelen",
"type":"Task"
}
]
}
,
"183817" : {
"id":183817,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"183818" : {
"id":183818,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding  of indiening ZM valide?",
"type":"Gateway"
}
]
}
,
"183819" : {
"id":183819,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding  of indiening ZM niet valide",
"type":"End event"
}
]
}
,
"183820" : {
"id":183820,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183822" : {
"id":183822,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD controleren",
"type":"Task"
}
]
}
,
"183826" : {
"id":183826,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183832" : {
"id":183832,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"183833" : {
"id":183833,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183834" : {
"id":183834,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183840" : {
"id":183840,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"183821" : {
"id":183821,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD ontvangen",
"type":"Task"
}
]
}
,
"183843" : {
"id":183843,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht beslissing voorbereiding of indiening ZM controleren",
"type":"Task"
}
]
}
,
"183844" : {
"id":183844,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183846" : {
"id":183846,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht Medische Verklaring is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"183850" : {
"id":183850,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183829" : {
"id":183829,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183851" : {
"id":183851,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht Medische Verklaring opstellen",
"type":"Task"
}
]
}
,
"183852" : {
"id":183852,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"183890" : {
"id":183890,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183909" : {
"id":183909,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"183911" : {
"id":183911,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"183883" : {
"id":183883,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183856" : {
"id":183856,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht beslissing tav aanvraag / voorbereiding ZM verzenden",
"type":"Task"
}
]
}
,
"183875" : {
"id":183875,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"183862" : {
"id":183862,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding is beeindigd",
"type":"End event"
}
]
}
,
"183886" : {
"id":183886,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Communicatie",
"type":"Datatype"
}
]
}
,
"183917" : {
"id":183917,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183873" : {
"id":183873,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"ZM aanvragen",
"type":"Task"
}
]
}
,
"183901" : {
"id":183901,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0",
"type":"Enumeratiewaarde"
}
]
}
,
"183861" : {
"id":183861,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183865" : {
"id":183865,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183895" : {
"id":183895,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Grondslag02",
"type":"Attribuut"
}
]
}
,
"183899" : {
"id":183899,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183905" : {
"id":183905,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD828: Score beperking",
"type":"Enumeratie"
}
]
}
,
"183866" : {
"id":183866,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Aanvraag is afgewezen",
"type":"End event"
}
]
}
,
"183864" : {
"id":183864,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Verzoekschrift is ingediend",
"type":"End event"
}
]
}
,
"183903" : {
"id":183903,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9",
"type":"Enumeratiewaarde"
}
]
}
,
"183913" : {
"id":183913,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183858" : {
"id":183858,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"183867" : {
"id":183867,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183872" : {
"id":183872,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183897" : {
"id":183897,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Grondslag01",
"type":"Attribuut"
}
]
}
,
"183860" : {
"id":183860,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht bevindingen GD  is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"183907" : {
"id":183907,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"183855" : {
"id":183855,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183863" : {
"id":183863,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183869" : {
"id":183869,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183870" : {
"id":183870,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183879" : {
"id":183879,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183868" : {
"id":183868,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Voorbereiding is gestart",
"type":"End event"
}
]
}
,
"183857" : {
"id":183857,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"183871" : {
"id":183871,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM opstellen",
"type":"Task"
}
]
}
,
"183859" : {
"id":183859,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183874" : {
"id":183874,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"183888" : {
"id":183888,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Vorm",
"type":"Attribuut"
}
]
}
,
"183955" : {
"id":183955,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Telefoonnummer",
"type":"Attribuut"
}
]
}
,
"183969" : {
"id":183969,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"183973" : {
"id":183973,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183979" : {
"id":183979,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183981" : {
"id":183981,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183953" : {
"id":183953,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Landnummer",
"type":"Attribuut"
}
]
}
,
"183957" : {
"id":183957,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183962" : {
"id":183962,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183965" : {
"id":183965,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD467: Status aanlevering",
"type":"Enumeratie"
}
]
}
,
"183943" : {
"id":183943,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Voorletters",
"type":"Attribuut"
}
]
}
,
"183945" : {
"id":183945,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslachtsnaam",
"type":"Attribuut"
}
]
}
,
"183949" : {
"id":183949,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Voornamen",
"type":"Attribuut"
}
]
}
,
"183931" : {
"id":183931,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"183947" : {
"id":183947,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Partnernaam",
"type":"Attribuut"
}
]
}
,
"183927" : {
"id":183927,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4",
"type":"Enumeratiewaarde"
}
]
}
,
"183921" : {
"id":183921,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD539: Beperking",
"type":"Enumeratie"
}
]
}
,
"183935" : {
"id":183935,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183951" : {
"id":183951,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Telefoon",
"type":"Datatype"
}
]
}
,
"183959" : {
"id":183959,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"183919" : {
"id":183919,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"183929" : {
"id":183929,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5",
"type":"Enumeratiewaarde"
}
]
}
,
"183923" : {
"id":183923,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"6",
"type":"Enumeratiewaarde"
}
]
}
,
"183971" : {
"id":183971,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"183925" : {
"id":183925,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"183937" : {
"id":183937,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183967" : {
"id":183967,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9",
"type":"Enumeratiewaarde"
}
]
}
,
"182830" : {
"id":182830,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5513",
"type":"Enumeratiewaarde"
}
]
}
,
"182832" : {
"id":182832,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5518",
"type":"Enumeratiewaarde"
}
]
}
,
"182786" : {
"id":182786,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"17",
"type":"Enumeratiewaarde"
}
]
}
,
"182799" : {
"id":182799,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM is niet valide",
"type":"End event"
}
]
}
,
"182836" : {
"id":182836,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182808" : {
"id":182808,
"typeIconPath":"data/icons/ArchiMate/BusinessObject.png",
"data" : [
{
"name":"Wlz Indicatieregister",
"type":"Bedrijfsobject"
}
]
}
,
"182804" : {
"id":182804,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182818" : {
"id":182818,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5504",
"type":"Enumeratiewaarde"
}
]
}
,
"182824" : {
"id":182824,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5527",
"type":"Enumeratiewaarde"
}
]
}
,
"182828" : {
"id":182828,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5514",
"type":"Enumeratiewaarde"
}
]
}
,
"182795" : {
"id":182795,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Aanvraag ZM is ontvangen",
"type":"End event"
}
]
}
,
"182838" : {
"id":182838,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5510",
"type":"Enumeratiewaarde"
}
]
}
,
"182840" : {
"id":182840,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5507",
"type":"Enumeratiewaarde"
}
]
}
,
"182798" : {
"id":182798,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"182788" : {
"id":182788,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182826" : {
"id":182826,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5516",
"type":"Enumeratiewaarde"
}
]
}
,
"182784" : {
"id":182784,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"16",
"type":"Enumeratiewaarde"
}
]
}
,
"182822" : {
"id":182822,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5501",
"type":"Enumeratiewaarde"
}
]
}
,
"182780" : {
"id":182780,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"09",
"type":"Enumeratiewaarde"
}
]
}
,
"182801" : {
"id":182801,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182800" : {
"id":182800,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182792" : {
"id":182792,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM Ontvangen",
"type":"Task"
}
]
}
,
"182816" : {
"id":182816,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5520",
"type":"Enumeratiewaarde"
}
]
}
,
"182793" : {
"id":182793,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"182796" : {
"id":182796,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182797" : {
"id":182797,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanvraag ZM controleren",
"type":"Task"
}
]
}
,
"182794" : {
"id":182794,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanvraag ZM valide?",
"type":"Gateway"
}
]
}
,
"182782" : {
"id":182782,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"13",
"type":"Enumeratiewaarde"
}
]
}
,
"182814" : {
"id":182814,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182820" : {
"id":182820,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5515",
"type":"Enumeratiewaarde"
}
]
}
,
"182834" : {
"id":182834,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5511",
"type":"Enumeratiewaarde"
}
]
}
,
"182791" : {
"id":182791,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"182778" : {
"id":182778,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"08",
"type":"Enumeratiewaarde"
}
]
}
,
"182810" : {
"id":182810,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5517",
"type":"Enumeratiewaarde"
}
]
}
,
"182812" : {
"id":182812,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD001: Zorgkantoor",
"type":"Enumeratie"
}
]
}
,
"182860" : {
"id":182860,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5525",
"type":"Enumeratiewaarde"
}
]
}
,
"182852" : {
"id":182852,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5508",
"type":"Enumeratiewaarde"
}
]
}
,
"182879" : {
"id":182879,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5532",
"type":"Enumeratiewaarde"
}
]
}
,
"182842" : {
"id":182842,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5533",
"type":"Enumeratiewaarde"
}
]
}
,
"182882" : {
"id":182882,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182846" : {
"id":182846,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5528",
"type":"Enumeratiewaarde"
}
]
}
,
"182854" : {
"id":182854,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5512",
"type":"Enumeratiewaarde"
}
]
}
,
"182892" : {
"id":182892,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"06",
"type":"Enumeratiewaarde"
}
]
}
,
"182848" : {
"id":182848,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5529",
"type":"Enumeratiewaarde"
}
]
}
,
"182850" : {
"id":182850,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5506",
"type":"Enumeratiewaarde"
}
]
}
,
"182844" : {
"id":182844,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5505",
"type":"Enumeratiewaarde"
}
]
}
,
"182902" : {
"id":182902,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"07",
"type":"Enumeratiewaarde"
}
]
}
,
"182872" : {
"id":182872,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5523",
"type":"Enumeratiewaarde"
}
]
}
,
"182904" : {
"id":182904,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"182868" : {
"id":182868,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5530",
"type":"Enumeratiewaarde"
}
]
}
,
"182866" : {
"id":182866,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5509",
"type":"Enumeratiewaarde"
}
]
}
,
"182870" : {
"id":182870,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5526",
"type":"Enumeratiewaarde"
}
]
}
,
"182862" : {
"id":182862,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5503",
"type":"Enumeratiewaarde"
}
]
}
,
"182877" : {
"id":182877,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5531",
"type":"Enumeratiewaarde"
}
]
}
,
"182885" : {
"id":182885,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"08",
"type":"Enumeratiewaarde"
}
]
}
,
"182864" : {
"id":182864,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5519",
"type":"Enumeratiewaarde"
}
]
}
,
"182896" : {
"id":182896,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"182888" : {
"id":182888,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"12",
"type":"Enumeratiewaarde"
}
]
}
,
"182894" : {
"id":182894,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"182898" : {
"id":182898,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"11",
"type":"Enumeratiewaarde"
}
]
}
,
"182858" : {
"id":182858,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5502",
"type":"Enumeratiewaarde"
}
]
}
,
"182890" : {
"id":182890,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182900" : {
"id":182900,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"182874" : {
"id":182874,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5524",
"type":"Enumeratiewaarde"
}
]
}
,
"182856" : {
"id":182856,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"5521",
"type":"Enumeratiewaarde"
}
]
}
,
"182915" : {
"id":182915,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"182958" : {
"id":182958,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"182959" : {
"id":182959,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD046: Geslacht",
"type":"Enumeratie"
}
]
}
,
"182906" : {
"id":182906,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"182909" : {
"id":182909,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"13",
"type":"Enumeratiewaarde"
}
]
}
,
"182937" : {
"id":182937,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Attribute (2)",
"type":"Attribuut"
}
]
}
,
"182931" : {
"id":182931,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Berichtklasse root",
"type":"Klasse"
}
]
}
,
"182955" : {
"id":182955,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182957" : {
"id":182957,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_2",
"type":"Datatype"
}
]
}
,
"182961" : {
"id":182961,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD757: Soort adres",
"type":"Enumeratie"
}
]
}
,
"182939" : {
"id":182939,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182962" : {
"id":182962,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"NUM061: Aanduiding woonadres",
"type":"Enumeratie"
}
]
}
,
"182945" : {
"id":182945,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT",
"type":"Datatype"
}
]
}
,
"182917" : {
"id":182917,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"UML views per bericht  De XSD van een bericht wordt afgeleid van de UML view. Dit is nodig zodat generieke berichtklassen op meerdere berichtviews geplaatst kunnen worden. Afhankelijk van de getoonde relaties op de view wordt het bericht afgeleid.",
"type":"Package"
}
]
}
,
"182941" : {
"id":182941,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"Codelijst",
"type":"Enumeratie"
}
]
}
,
"182921" : {
"id":182921,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"UML model (bijv. Berichten Wmo)  Domeininformatie wordt hier opgenomen: * Standaard (bijv. iWmo) * Release (bijv. 2.1) * Publicatieversie (bijv. 1.1)",
"type":"Package"
}
]
}
,
"182919" : {
"id":182919,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Model domein berichtklassen (bijv. Wmo berichtklassen)",
"type":"Package"
}
]
}
,
"182966" : {
"id":182966,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182968" : {
"id":182968,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"182949" : {
"id":182949,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"Code",
"type":"Enumeratiewaarde"
}
]
}
,
"182960" : {
"id":182960,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD260: Ja of nee",
"type":"Enumeratie"
}
]
}
,
"182933" : {
"id":182933,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"182951" : {
"id":182951,
"typeIconPath":"data/icons/UML/UML_PrimitiveType.png",
"data" : [
{
"name":"Primitive type",
"type":"Primitief type"
}
]
}
,
"182925" : {
"id":182925,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Berichtklasse inhoud (header)",
"type":"Klasse"
}
]
}
,
"182927" : {
"id":182927,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Berichtklasse inhoud",
"type":"Klasse"
}
]
}
,
"182943" : {
"id":182943,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182935" : {
"id":182935,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT",
"type":"Datatype"
}
]
}
,
"182947" : {
"id":182947,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Attribute",
"type":"Attribuut"
}
]
}
,
"182929" : {
"id":182929,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Berichtelement ",
"type":"Attribuut"
}
]
}
,
"182911" : {
"id":182911,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"09",
"type":"Enumeratiewaarde"
}
]
}
,
"182923" : {
"id":182923,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Package per bericht  Berichtklassen die alleen binnen dit bericht gebruikt worden, worden hier gedefinieerd.   Indien dezelfde berichtklasse (exact hetzelfde incl datatypen en regels) in 3 of meer berichten gebruikt wordt, wordt deze gedefinieerd als generieke berichtklasse in het UML model \"Bibliotheek - Berichtklassen\"  Voor retourberichten wordt ook een package aangemaakt, hierin wordt alleen de Berichtklasse root opgenomen t.b.v. koppeling van bedrijfsregels etc.",
"type":"Package"
}
]
}
,
"182913" : {
"id":182913,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"10",
"type":"Enumeratiewaarde"
}
]
}
,
"183002" : {
"id":183002,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG101",
"type":"Enumeratiewaarde"
}
]
}
,
"182970" : {
"id":182970,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183023" : {
"id":183023,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG116",
"type":"Enumeratiewaarde"
}
]
}
,
"183025" : {
"id":183025,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG110",
"type":"Enumeratiewaarde"
}
]
}
,
"183030" : {
"id":183030,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"182979" : {
"id":182979,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Huisletter",
"type":"Attribuut"
}
]
}
,
"183033" : {
"id":183033,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"183010" : {
"id":183010,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG107",
"type":"Enumeratiewaarde"
}
]
}
,
"183015" : {
"id":183015,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG108",
"type":"Enumeratiewaarde"
}
]
}
,
"182997" : {
"id":182997,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG113",
"type":"Enumeratiewaarde"
}
]
}
,
"183013" : {
"id":183013,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183008" : {
"id":183008,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG105",
"type":"Enumeratiewaarde"
}
]
}
,
"182981" : {
"id":182981,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"AanduidingWoonadres",
"type":"Attribuut"
}
]
}
,
"182988" : {
"id":182988,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"182992" : {
"id":182992,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG109",
"type":"Enumeratiewaarde"
}
]
}
,
"183006" : {
"id":183006,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG103",
"type":"Enumeratiewaarde"
}
]
}
,
"182972" : {
"id":182972,
"typeIconPath":"data/icons/ArchiMate/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"183004" : {
"id":183004,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG106",
"type":"Enumeratiewaarde"
}
]
}
,
"183019" : {
"id":183019,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG104",
"type":"Enumeratiewaarde"
}
]
}
,
"183021" : {
"id":183021,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG114",
"type":"Enumeratiewaarde"
}
]
}
,
"182977" : {
"id":182977,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"CDT_Huis",
"type":"Datatype"
}
]
}
,
"182994" : {
"id":182994,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG111",
"type":"Enumeratiewaarde"
}
]
}
,
"183027" : {
"id":183027,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG112",
"type":"Enumeratiewaarde"
}
]
}
,
"182983" : {
"id":182983,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"HuisnummerToevoeging",
"type":"Attribuut"
}
]
}
,
"182990" : {
"id":182990,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183000" : {
"id":183000,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG115",
"type":"Enumeratiewaarde"
}
]
}
,
"183017" : {
"id":183017,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"WVG102",
"type":"Enumeratiewaarde"
}
]
}
,
"182975" : {
"id":182975,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Huisnummer",
"type":"Attribuut"
}
]
}
,
"183057" : {
"id":183057,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EIS",
"type":"Enumeratiewaarde"
}
]
}
,
"183073" : {
"id":183073,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183066" : {
"id":183066,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183053" : {
"id":183053,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EVO",
"type":"Enumeratiewaarde"
}
]
}
,
"183035" : {
"id":183035,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183069" : {
"id":183069,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183079" : {
"id":183079,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"045",
"type":"Enumeratiewaarde"
}
]
}
,
"183083" : {
"id":183083,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"096",
"type":"Enumeratiewaarde"
}
]
}
,
"183087" : {
"id":183087,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"032",
"type":"Enumeratiewaarde"
}
]
}
,
"183071" : {
"id":183071,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AVP",
"type":"Enumeratiewaarde"
}
]
}
,
"183063" : {
"id":183063,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"BVB",
"type":"Enumeratiewaarde"
}
]
}
,
"183042" : {
"id":183042,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EPS",
"type":"Enumeratiewaarde"
}
]
}
,
"183093" : {
"id":183093,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"088",
"type":"Enumeratiewaarde"
}
]
}
,
"183037" : {
"id":183037,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"183055" : {
"id":183055,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EFS",
"type":"Enumeratiewaarde"
}
]
}
,
"183077" : {
"id":183077,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"023",
"type":"Enumeratiewaarde"
}
]
}
,
"183081" : {
"id":183081,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"103",
"type":"Enumeratiewaarde"
}
]
}
,
"183044" : {
"id":183044,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EMS",
"type":"Enumeratiewaarde"
}
]
}
,
"183047" : {
"id":183047,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"HGA",
"type":"Enumeratiewaarde"
}
]
}
,
"183049" : {
"id":183049,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"ELL",
"type":"Enumeratiewaarde"
}
]
}
,
"183061" : {
"id":183061,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"EVM",
"type":"Enumeratiewaarde"
}
]
}
,
"183085" : {
"id":183085,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"093",
"type":"Enumeratiewaarde"
}
]
}
,
"183059" : {
"id":183059,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"AMT",
"type":"Enumeratiewaarde"
}
]
}
,
"183091" : {
"id":183091,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"086",
"type":"Enumeratiewaarde"
}
]
}
,
"183095" : {
"id":183095,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"024",
"type":"Enumeratiewaarde"
}
]
}
,
"183039" : {
"id":183039,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183051" : {
"id":183051,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"LVG",
"type":"Enumeratiewaarde"
}
]
}
,
"183075" : {
"id":183075,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"065",
"type":"Enumeratiewaarde"
}
]
}
,
"183097" : {
"id":183097,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"084",
"type":"Enumeratiewaarde"
}
]
}
,
"183107" : {
"id":183107,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"091",
"type":"Enumeratiewaarde"
}
]
}
,
"183127" : {
"id":183127,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"097",
"type":"Enumeratiewaarde"
}
]
}
,
"183103" : {
"id":183103,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"081",
"type":"Enumeratiewaarde"
}
]
}
,
"183149" : {
"id":183149,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"110",
"type":"Enumeratiewaarde"
}
]
}
,
"183123" : {
"id":183123,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"078",
"type":"Enumeratiewaarde"
}
]
}
,
"183160" : {
"id":183160,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"009",
"type":"Enumeratiewaarde"
}
]
}
,
"183162" : {
"id":183162,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"002",
"type":"Enumeratiewaarde"
}
]
}
,
"183109" : {
"id":183109,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"083",
"type":"Enumeratiewaarde"
}
]
}
,
"183113" : {
"id":183113,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"089",
"type":"Enumeratiewaarde"
}
]
}
,
"183111" : {
"id":183111,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"087",
"type":"Enumeratiewaarde"
}
]
}
,
"183099" : {
"id":183099,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"085",
"type":"Enumeratiewaarde"
}
]
}
,
"183133" : {
"id":183133,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"100",
"type":"Enumeratiewaarde"
}
]
}
,
"183158" : {
"id":183158,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"019",
"type":"Enumeratiewaarde"
}
]
}
,
"183137" : {
"id":183137,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"104",
"type":"Enumeratiewaarde"
}
]
}
,
"183156" : {
"id":183156,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"001",
"type":"Enumeratiewaarde"
}
]
}
,
"183125" : {
"id":183125,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"095",
"type":"Enumeratiewaarde"
}
]
}
,
"183145" : {
"id":183145,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"108",
"type":"Enumeratiewaarde"
}
]
}
,
"183153" : {
"id":183153,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"051",
"type":"Enumeratiewaarde"
}
]
}
,
"183135" : {
"id":183135,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"101",
"type":"Enumeratiewaarde"
}
]
}
,
"183131" : {
"id":183131,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"099",
"type":"Enumeratiewaarde"
}
]
}
,
"183117" : {
"id":183117,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"090",
"type":"Enumeratiewaarde"
}
]
}
,
"183119" : {
"id":183119,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"092",
"type":"Enumeratiewaarde"
}
]
}
,
"183139" : {
"id":183139,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"105",
"type":"Enumeratiewaarde"
}
]
}
,
"183129" : {
"id":183129,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"098",
"type":"Enumeratiewaarde"
}
]
}
,
"183141" : {
"id":183141,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"106",
"type":"Enumeratiewaarde"
}
]
}
,
"183101" : {
"id":183101,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"080",
"type":"Enumeratiewaarde"
}
]
}
,
"183147" : {
"id":183147,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"109",
"type":"Enumeratiewaarde"
}
]
}
,
"183121" : {
"id":183121,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"094",
"type":"Enumeratiewaarde"
}
]
}
,
"183151" : {
"id":183151,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"061",
"type":"Enumeratiewaarde"
}
]
}
,
"183143" : {
"id":183143,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"107",
"type":"Enumeratiewaarde"
}
]
}
,
"183105" : {
"id":183105,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"082",
"type":"Enumeratiewaarde"
}
]
}
,
"183115" : {
"id":183115,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"075",
"type":"Enumeratiewaarde"
}
]
}
,
"183214" : {
"id":183214,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"031",
"type":"Enumeratiewaarde"
}
]
}
,
"183186" : {
"id":183186,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"015",
"type":"Enumeratiewaarde"
}
]
}
,
"183188" : {
"id":183188,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"016",
"type":"Enumeratiewaarde"
}
]
}
,
"183170" : {
"id":183170,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"006",
"type":"Enumeratiewaarde"
}
]
}
,
"183164" : {
"id":183164,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"003",
"type":"Enumeratiewaarde"
}
]
}
,
"183176" : {
"id":183176,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"010",
"type":"Enumeratiewaarde"
}
]
}
,
"183184" : {
"id":183184,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"014",
"type":"Enumeratiewaarde"
}
]
}
,
"183198" : {
"id":183198,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"021",
"type":"Enumeratiewaarde"
}
]
}
,
"183194" : {
"id":183194,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"018",
"type":"Enumeratiewaarde"
}
]
}
,
"183202" : {
"id":183202,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"025",
"type":"Enumeratiewaarde"
}
]
}
,
"183204" : {
"id":183204,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"026",
"type":"Enumeratiewaarde"
}
]
}
,
"183208" : {
"id":183208,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"029",
"type":"Enumeratiewaarde"
}
]
}
,
"183166" : {
"id":183166,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"004",
"type":"Enumeratiewaarde"
}
]
}
,
"183174" : {
"id":183174,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"008",
"type":"Enumeratiewaarde"
}
]
}
,
"183200" : {
"id":183200,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"022",
"type":"Enumeratiewaarde"
}
]
}
,
"183196" : {
"id":183196,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"020",
"type":"Enumeratiewaarde"
}
]
}
,
"183172" : {
"id":183172,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"007",
"type":"Enumeratiewaarde"
}
]
}
,
"183178" : {
"id":183178,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"011",
"type":"Enumeratiewaarde"
}
]
}
,
"183180" : {
"id":183180,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"012",
"type":"Enumeratiewaarde"
}
]
}
,
"183182" : {
"id":183182,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"013",
"type":"Enumeratiewaarde"
}
]
}
,
"183190" : {
"id":183190,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"017",
"type":"Enumeratiewaarde"
}
]
}
,
"183192" : {
"id":183192,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"183206" : {
"id":183206,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"027",
"type":"Enumeratiewaarde"
}
]
}
,
"183168" : {
"id":183168,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"005",
"type":"Enumeratiewaarde"
}
]
}
,
"183210" : {
"id":183210,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"030",
"type":"Enumeratiewaarde"
}
]
}
,
"183212" : {
"id":183212,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"054",
"type":"Enumeratiewaarde"
}
]
}
,
"103628" : {
"id":103628,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103603" : {
"id":103603,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103621" : {
"id":103621,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103630" : {
"id":103630,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Rechtbank",
"type":"Datatype"
}
]
}
,
"103633" : {
"id":103633,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103604" : {
"id":103604,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP605: De Oficier van Justitie start de voorbereiding van een zorgmachtiging ambtshalve of op basis van een ontvangen aanvraag.",
"type":"Requirement"
}
]
}
,
"103593" : {
"id":103593,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103624" : {
"id":103624,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_DocumentNaam",
"type":"Datatype"
}
]
}
,
"103611" : {
"id":103611,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103622" : {
"id":103622,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103594" : {
"id":103594,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103598" : {
"id":103598,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103676" : {
"id":103676,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DatumGebruik",
"type":"Attribuut"
}
]
}
,
"103649" : {
"id":103649,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103643" : {
"id":103643,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP090: Voor ieder ontvangen bericht wordt binnen een uur na ontvangst een retourbericht verzonden.",
"type":"Requirement"
}
]
}
,
"103646" : {
"id":103646,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_AanduidingWoonadres",
"type":"Klassendiagram"
}
]
}
,
"103634" : {
"id":103634,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP090x2: Indien voor een ontvangen bericht geen retourbericht kan worden gemaakt moet de ontvangende partij dit buiten het berichtenverkeer om melden aan de verzendende partij.",
"type":"Requirement"
}
]
}
,
"103661" : {
"id":103661,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103642" : {
"id":103642,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103658" : {
"id":103658,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103662" : {
"id":103662,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103678" : {
"id":103678,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103713" : {
"id":103713,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103688" : {
"id":103688,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103719" : {
"id":103719,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Geboortedatum",
"type":"Klassendiagram"
}
]
}
,
"103685" : {
"id":103685,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103712" : {
"id":103712,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Emailadres",
"type":"Klassendiagram"
}
]
}
,
"103704" : {
"id":103704,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103700" : {
"id":103700,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103726" : {
"id":103726,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD601: Als Bsn leeg is, dan vullen, anders leeg laten.",
"type":"Beperking"
}
]
}
,
"103735" : {
"id":103735,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103737" : {
"id":103737,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_OrganisatieSoort",
"type":"Datatype"
}
]
}
,
"103725" : {
"id":103725,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103728" : {
"id":103728,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Identificatie",
"type":"Datatype"
}
]
}
,
"103753" : {
"id":103753,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Grondslag",
"type":"Datatype"
}
]
}
,
"103739" : {
"id":103739,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103751" : {
"id":103751,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103769" : {
"id":103769,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"103774" : {
"id":103774,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103738" : {
"id":103738,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103743" : {
"id":103743,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103777" : {
"id":103777,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Commentaar",
"type":"Klassendiagram"
}
]
}
,
"103754" : {
"id":103754,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103789" : {
"id":103789,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103784" : {
"id":103784,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103818" : {
"id":103818,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_ZorgvormCategorie",
"type":"Datatype"
}
]
}
,
"103794" : {
"id":103794,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_AanleidingBevindingen",
"type":"Datatype"
}
]
}
,
"103787" : {
"id":103787,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103866" : {
"id":103866,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_LandCode",
"type":"Klassendiagram"
}
]
}
,
"103824" : {
"id":103824,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103831" : {
"id":103831,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD608: Als Land de waarde NL (Nederland) bevat, en AanduidingBijAdres bevat niet de waarde TO (tegenover) of WW (woonwagen), dan verplicht vullen, anders leeglaten.",
"type":"Beperking"
}
]
}
,
"103909" : {
"id":103909,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_UUID",
"type":"Klassendiagram"
}
]
}
,
"103917" : {
"id":103917,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BeperkingCategorie",
"type":"Klassendiagram"
}
]
}
,
"103958" : {
"id":103958,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Grondslagen",
"type":"Klassendiagram"
}
]
}
,
"103976" : {
"id":103976,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Gemeente",
"type":"Klassendiagram"
}
]
}
,
"104012" : {
"id":104012,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Plaatsnaam",
"type":"Klassendiagram"
}
]
}
,
"104009" : {
"id":104009,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Straatnaam",
"type":"Klassendiagram"
}
]
}
,
"104039" : {
"id":104039,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"Retourbericht Template",
"type":"Klassendiagram"
}
]
}
,
"104084" : {
"id":104084,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_DatumGebruik",
"type":"Klassendiagram"
}
]
}
,
"104060" : {
"id":104060,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Telefoon",
"type":"Klassendiagram"
}
]
}
,
"104072" : {
"id":104072,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Telefoonnummer",
"type":"Klassendiagram"
}
]
}
,
"104057" : {
"id":104057,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Geslacht",
"type":"Klassendiagram"
}
]
}
,
"104090" : {
"id":104090,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Grondslag",
"type":"Klassendiagram"
}
]
}
,
"104045" : {
"id":104045,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Huisletter",
"type":"Klassendiagram"
}
]
}
,
"104063" : {
"id":104063,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_ZorgkantoorCode",
"type":"Klassendiagram"
}
]
}
,
"104066" : {
"id":104066,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_SoortRelatie",
"type":"Klassendiagram"
}
]
}
,
"104075" : {
"id":104075,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_HuisnummerToevoeging",
"type":"Klassendiagram"
}
]
}
,
"104054" : {
"id":104054,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Tijd",
"type":"Klassendiagram"
}
]
}
,
"104087" : {
"id":104087,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_GeslotenPeriode",
"type":"Klassendiagram"
}
]
}
,
"104069" : {
"id":104069,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Landnummer",
"type":"Klassendiagram"
}
]
}
,
"104048" : {
"id":104048,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Referentie",
"type":"Klassendiagram"
}
]
}
,
"104078" : {
"id":104078,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Adres",
"type":"Klassendiagram"
}
]
}
,
"104051" : {
"id":104051,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_AdresSoort",
"type":"Klassendiagram"
}
]
}
,
"104081" : {
"id":104081,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Telefoonnummers",
"type":"Klassendiagram"
}
]
}
,
"104124" : {
"id":104124,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Postcode",
"type":"Klassendiagram"
}
]
}
,
"104098" : {
"id":104098,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Nummer",
"type":"Klassendiagram"
}
]
}
,
"104106" : {
"id":104106,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_VolledigeNaam",
"type":"Klassendiagram"
}
]
}
,
"104109" : {
"id":104109,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_NaamGebruik",
"type":"Klassendiagram"
}
]
}
,
"104112" : {
"id":104112,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Persoonsid",
"type":"Klassendiagram"
}
]
}
,
"104121" : {
"id":104121,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_BeperkingVraag",
"type":"Klassendiagram"
}
]
}
,
"104127" : {
"id":104127,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Huisnummer",
"type":"Klassendiagram"
}
]
}
,
"104115" : {
"id":104115,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Datum",
"type":"Klassendiagram"
}
]
}
,
"104133" : {
"id":104133,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Huis",
"type":"Klassendiagram"
}
]
}
,
"104136" : {
"id":104136,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Duur",
"type":"Klassendiagram"
}
]
}
,
"104103" : {
"id":104103,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"CDT_Communicatie",
"type":"Klassendiagram"
}
]
}
,
"104130" : {
"id":104130,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_JaNee",
"type":"Klassendiagram"
}
]
}
,
"103535" : {
"id":103535,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103558" : {
"id":103558,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103523" : {
"id":103523,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103532" : {
"id":103532,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Naam",
"type":"Klassendiagram"
}
]
}
,
"103533" : {
"id":103533,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103519" : {
"id":103519,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP614: Als een leveringsnummer in een eerder bericht gebruikt is, dan wordt er vanuit gegaan dat dit dezelfde levering betreft.",
"type":"Requirement"
}
]
}
,
"103543" : {
"id":103543,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103540" : {
"id":103540,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_Zorgvorm",
"type":"Datatype"
}
]
}
,
"103545" : {
"id":103545,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103534" : {
"id":103534,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP606: Als een bijlage wordt ontvangen met een hoger versienummer, dan vervangt deze de eerdere bijlage.",
"type":"Requirement"
}
]
}
,
"103527" : {
"id":103527,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_DocumentVersie",
"type":"Datatype"
}
]
}
,
"103529" : {
"id":103529,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103544" : {
"id":103544,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103588" : {
"id":103588,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103592" : {
"id":103592,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103581" : {
"id":103581,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103564" : {
"id":103564,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP607: Via het bericht Bevindingen Gd kunnen nieuwe documenten en nieuwe versies van bestaande documenten verstuurd worden.",
"type":"Requirement"
}
]
}
,
"103571" : {
"id":103571,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103570" : {
"id":103570,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103563" : {
"id":103563,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103582" : {
"id":103582,
"typeIconPath":"data/icons/ArchiMate/ArchiMateMM_Model.png",
"data" : [
{
"name":"Regelkoppelingen",
"type":"ArchiMate-model"
}
]
}
,
"103565" : {
"id":103565,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103585" : {
"id":103585,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"103589" : {
"id":103589,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP608: Bij een Aanvraag Zorgmachtiging bericht moet het document \"Aanvraag tot voorbereiding Zorgmachtiging\" als bijlage worden meegestuurd.",
"type":"Requirement"
}
]
}
,
"103577" : {
"id":103577,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"name":"LDT_Percentage",
"type":"Klassendiagram"
}
]
}
,
"103566" : {
"id":103566,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP602: De informatie over de bijlagen in een bericht sluit aan bij de bijgevoegde bestanden.",
"type":"Requirement"
}
]
}
,
"103583" : {
"id":103583,
"typeIconPath":"data/icons/MM_ModelPackage/AssociationDependencyRelation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"152295" : {
"id":152295,
"typeIconPath":"data/icons/ArchiMate/BusinessScheme.png",
"data" : [
{
"name":"Bedrijfslaag",
"type":"Bedrijfslaag"
}
]
}
,
"181204" : {
"id":181204,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"GGZ-instelling",
"type":"Pool"
}
]
}
,
"181205" : {
"id":181205,
"typeIconPath":"data/icons/BPMN/BPMN_Participant.png",
"data" : [
{
"name":"OM",
"type":"Pool"
}
]
}
,
"181214" : {
"id":181214,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"MV",
"type":"Message"
}
]
}
,
"181215" : {
"id":181215,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181216" : {
"id":181216,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht bevindingen GD",
"type":"Task"
}
]
}
,
"181210" : {
"id":181210,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aavraag ZM ontvangen",
"type":"Intermediate event"
}
]
}
,
"181207" : {
"id":181207,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"181208" : {
"id":181208,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanwijzing GD",
"type":"Message"
}
]
}
,
"181206" : {
"id":181206,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181211" : {
"id":181211,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Aanvraag ZM",
"type":"Message"
}
]
}
,
"181212" : {
"id":181212,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181213" : {
"id":181213,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht MV ontvangen",
"type":"Intermediate event"
}
]
}
,
"181209" : {
"id":181209,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181219" : {
"id":181219,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"181217" : {
"id":181217,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour bevindingen GD",
"type":"Message"
}
]
}
,
"181218" : {
"id":181218,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181223" : {
"id":181223,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing tav aanvraag / voorbereiding ZM",
"type":"Message"
}
]
}
,
"181224" : {
"id":181224,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181220" : {
"id":181220,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanwijzing GD",
"type":"Message"
}
]
}
,
"181230" : {
"id":181230,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181226" : {
"id":181226,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour aanvraag ZM",
"type":"Message"
}
]
}
,
"181231" : {
"id":181231,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"181232" : {
"id":181232,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing tav aanvraag / voorbereiding ZM",
"type":"Message"
}
]
}
,
"181234" : {
"id":181234,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181222" : {
"id":181222,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht beslissing tav  indienen verzoekschrift ontvangen",
"type":"Intermediate event"
}
]
}
,
"181228" : {
"id":181228,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht  MV",
"type":"Task"
}
]
}
,
"181221" : {
"id":181221,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181225" : {
"id":181225,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht aanvraag ZM",
"type":"Task"
}
]
}
,
"181227" : {
"id":181227,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181229" : {
"id":181229,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour MV",
"type":"Message"
}
]
}
,
"181251" : {
"id":181251,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181252" : {
"id":181252,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"181253" : {
"id":181253,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181254" : {
"id":181254,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"181255" : {
"id":181255,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181236" : {
"id":181236,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanwijzen GD",
"type":"Task"
}
]
}
,
"181256" : {
"id":181256,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181257" : {
"id":181257,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181258" : {
"id":181258,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD niet valide",
"type":"End event"
}
]
}
,
"181246" : {
"id":181246,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht MV  niet valide",
"type":"End event"
}
]
}
,
"181235" : {
"id":181235,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Aanvraag ZM afgewezen?",
"type":"Gateway"
}
]
}
,
"181239" : {
"id":181239,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181238" : {
"id":181238,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"181247" : {
"id":181247,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181248" : {
"id":181248,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanvraag ZM valide?",
"type":"Gateway"
}
]
}
,
"181240" : {
"id":181240,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht bevindingen GD",
"type":"Task"
}
]
}
,
"181241" : {
"id":181241,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181242" : {
"id":181242,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht  bevindingen GD",
"type":"Task"
}
]
}
,
"181243" : {
"id":181243,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht bevindingen GD valide?",
"type":"Gateway"
}
]
}
,
"181244" : {
"id":181244,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181245" : {
"id":181245,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht MV valide?",
"type":"Gateway"
}
]
}
,
"181237" : {
"id":181237,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181249" : {
"id":181249,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181250" : {
"id":181250,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanvraag ZM niet valide",
"type":"End event"
}
]
}
,
"181261" : {
"id":181261,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181269" : {
"id":181269,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181266" : {
"id":181266,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181264" : {
"id":181264,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181270" : {
"id":181270,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181271" : {
"id":181271,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181272" : {
"id":181272,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181267" : {
"id":181267,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181273" : {
"id":181273,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181259" : {
"id":181259,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181263" : {
"id":181263,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181260" : {
"id":181260,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beslissen over aanvraag en  voorbereiding ZM",
"type":"Task"
}
]
}
,
"181262" : {
"id":181262,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"181265" : {
"id":181265,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanvraag ZM in behandeling nemen",
"type":"Task"
}
]
}
,
"181268" : {
"id":181268,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"OvJ start ambsthalve voorbereiden ZM",
"type":"Start event"
}
]
}
,
"181276" : {
"id":181276,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren  bericht MV",
"type":"Task"
}
]
}
,
"181278" : {
"id":181278,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181277" : {
"id":181277,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181275" : {
"id":181275,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181274" : {
"id":181274,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht MV",
"type":"Task"
}
]
}
,
"181280" : {
"id":181280,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181282" : {
"id":181282,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"181281" : {
"id":181281,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181279" : {
"id":181279,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181186" : {
"id":181186,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanrvaag ontvangen",
"type":"Lane"
}
]
}
,
"181182" : {
"id":181182,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Voorbereiding starten",
"type":"Lane"
}
]
}
,
"181201" : {
"id":181201,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"181202" : {
"id":181202,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht bevindingen GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"181203" : {
"id":181203,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Bevindingen GD",
"type":"Message"
}
]
}
,
"181108" : {
"id":181108,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Lane"
}
]
}
,
"181095" : {
"id":181095,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Indienen",
"type":"Lane"
}
]
}
,
"181118" : {
"id":181118,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanvragen",
"type":"Choreography task"
}
]
}
,
"181119" : {
"id":181119,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Aanwijzen",
"type":"Choreography task"
}
]
}
,
"181117" : {
"id":181117,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181120" : {
"id":181120,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Melden",
"type":"Choreography task"
}
]
}
,
"181121" : {
"id":181121,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181129" : {
"id":181129,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Onderzoeken",
"type":"Choreography task"
}
]
}
,
"181131" : {
"id":181131,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"181132" : {
"id":181132,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Voorbereiding ZM gestopt",
"type":"End event"
}
]
}
,
"181133" : {
"id":181133,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181134" : {
"id":181134,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beoordelen",
"type":"Choreography task"
}
]
}
,
"181122" : {
"id":181122,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyStartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"181130" : {
"id":181130,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181135" : {
"id":181135,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181137" : {
"id":181137,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"181139" : {
"id":181139,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beslissen",
"type":"Lane"
}
]
}
,
"181124" : {
"id":181124,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyEndEvent.png",
"data" : [
{
"name":"Indienen verzoekschrift gemeld",
"type":"End event"
}
]
}
,
"181125" : {
"id":181125,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181123" : {
"id":181123,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181126" : {
"id":181126,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyTask.png",
"data" : [
{
"name":"Beslissen",
"type":"Choreography task"
}
]
}
,
"181127" : {
"id":181127,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographyGateway.png",
"data" : [
{
"name":"Beeindigen voorbereiden ZM?",
"type":"Gateway"
}
]
}
,
"181128" : {
"id":181128,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180988" : {
"id":180988,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"180969" : {
"id":180969,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180989" : {
"id":180989,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanwijzing GD valide?",
"type":"Gateway"
}
]
}
,
"180990" : {
"id":180990,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"180978" : {
"id":180978,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD opstellen",
"type":"Task"
}
]
}
,
"180981" : {
"id":180981,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180972" : {
"id":180972,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180975" : {
"id":180975,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Voorbereiding ZM  is gestart",
"type":"Start event"
}
]
}
,
"180966" : {
"id":180966,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Voorbereiding ZM ambsthalve door OvJ gestart",
"type":"Start event"
}
]
}
,
"180984" : {
"id":180984,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180987" : {
"id":180987,
"typeIconPath":"data/icons/BPMN/BPMN_MessageFlow.png",
"data" : [
{
"name":"Message flow",
"type":"Message flow"
}
]
}
,
"180992" : {
"id":180992,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Uitvoeren psychiatrisch onderzoek",
"type":"Task"
}
]
}
,
"181011" : {
"id":181011,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht beslissing tav  indienen verzoekschrift valide?",
"type":"Gateway"
}
]
}
,
"181012" : {
"id":181012,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181015" : {
"id":181015,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht aanwijzing GD",
"type":"Task"
}
]
}
,
"180996" : {
"id":180996,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen  beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"180997" : {
"id":180997,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180999" : {
"id":180999,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"180993" : {
"id":180993,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht MV",
"type":"Task"
}
]
}
,
"181002" : {
"id":181002,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181010" : {
"id":181010,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht  beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"181016" : {
"id":181016,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181017" : {
"id":181017,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht bevindingen GD",
"type":"Task"
}
]
}
,
"180995" : {
"id":180995,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht beslissing tav indienen verzoekschrift ontvangen",
"type":"Intermediate event"
}
]
}
,
"180994" : {
"id":180994,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181018" : {
"id":181018,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht bevindingen GD",
"type":"Task"
}
]
}
,
"181007" : {
"id":181007,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht MV ontvangen",
"type":"Intermediate event"
}
]
}
,
"181003" : {
"id":181003,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht aanvraag ZM ontvangen",
"type":"Intermediate event"
}
]
}
,
"181019" : {
"id":181019,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181014" : {
"id":181014,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Controleren bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"180998" : {
"id":180998,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht aanvraag ZM",
"type":"Task"
}
]
}
,
"181013" : {
"id":181013,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"180991" : {
"id":180991,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181005" : {
"id":181005,
"typeIconPath":"data/icons/BPMN/BPMN_StartEvent.png",
"data" : [
{
"name":"Aanvragen ZM gestart",
"type":"Start event"
}
]
}
,
"181000" : {
"id":181000,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181001" : {
"id":181001,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Aanvragen ZM",
"type":"Task"
}
]
}
,
"181004" : {
"id":181004,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181006" : {
"id":181006,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181008" : {
"id":181008,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden bericht MV",
"type":"Task"
}
]
}
,
"181009" : {
"id":181009,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181023" : {
"id":181023,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181025" : {
"id":181025,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Ontvangen bericht aanwijzing GD",
"type":"Task"
}
]
}
,
"181026" : {
"id":181026,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181027" : {
"id":181027,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht beslissing tav  indienen verzoekschrift niet valide",
"type":"End event"
}
]
}
,
"181028" : {
"id":181028,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"181029" : {
"id":181029,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD niet valide",
"type":"End event"
}
]
}
,
"181022" : {
"id":181022,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Retourbericht bevindingen GD  ontvangen",
"type":"Intermediate event"
}
]
}
,
"181030" : {
"id":181030,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181033" : {
"id":181033,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181034" : {
"id":181034,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181035" : {
"id":181035,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181031" : {
"id":181031,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181036" : {
"id":181036,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181024" : {
"id":181024,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD ontvangen",
"type":"Intermediate event"
}
]
}
,
"181021" : {
"id":181021,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"181032" : {
"id":181032,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Verzenden retourbericht beslissing tav indienen verzoekschrift",
"type":"Task"
}
]
}
,
"181020" : {
"id":181020,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Beoordelen Pva, zorgplan en zorgkaart",
"type":"Task"
}
]
}
,
"181042" : {
"id":181042,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Melden",
"type":"Lane"
}
]
}
,
"181046" : {
"id":181046,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"181052" : {
"id":181052,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Beslissen",
"type":"Lane"
}
]
}
,
"181058" : {
"id":181058,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"In behandeling nemen",
"type":"Lane"
}
]
}
,
"179746" : {
"id":179746,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD controleren",
"type":"Task"
}
]
}
,
"179734" : {
"id":179734,
"typeIconPath":"data/icons/BPMN/BPMN_IntermediateEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD is afgeleverd",
"type":"Intermediate event"
}
]
}
,
"179757" : {
"id":179757,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Rol",
"type":"Attribuut"
}
]
}
,
"179754" : {
"id":179754,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Werkadres",
"type":"Attribuut"
}
]
}
,
"179759" : {
"id":179759,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Organisatie",
"type":"Attribuut"
}
]
}
,
"179736" : {
"id":179736,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Bericht aanwijzing GD is niet valide",
"type":"End event"
}
]
}
,
"179738" : {
"id":179738,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Bericht aanwijzing GD ontvangen",
"type":"Task"
}
]
}
,
"179748" : {
"id":179748,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179740" : {
"id":179740,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"JA",
"type":"Sequence flow"
}
]
}
,
"179742" : {
"id":179742,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Bericht aanwijzing GD valide?",
"type":"Gateway"
}
]
}
,
"179744" : {
"id":179744,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179732" : {
"id":179732,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179750" : {
"id":179750,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Contactgegevens",
"type":"Attribuut"
}
]
}
,
"179752" : {
"id":179752,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"179761" : {
"id":179761,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000027000",
"type":"Enumeratiewaarde"
}
]
}
,
"179795" : {
"id":179795,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Opstellen bericht melding indienen verzoekschrift",
"type":"Task"
}
]
}
,
"179796" : {
"id":179796,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179797" : {
"id":179797,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Indienen verzoekschrift",
"type":"Task"
}
]
}
,
"179763" : {
"id":179763,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000142000",
"type":"Enumeratiewaarde"
}
]
}
,
"179765" : {
"id":179765,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000025000",
"type":"Enumeratiewaarde"
}
]
}
,
"179777" : {
"id":179777,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000151000",
"type":"Enumeratiewaarde"
}
]
}
,
"179767" : {
"id":179767,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"179784" : {
"id":179784,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000145000",
"type":"Enumeratiewaarde"
}
]
}
,
"179775" : {
"id":179775,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"179781" : {
"id":179781,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000143000",
"type":"Enumeratiewaarde"
}
]
}
,
"179788" : {
"id":179788,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000150000",
"type":"Enumeratiewaarde"
}
]
}
,
"179779" : {
"id":179779,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000055000",
"type":"Enumeratiewaarde"
}
]
}
,
"179786" : {
"id":179786,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000032000",
"type":"Enumeratiewaarde"
}
]
}
,
"179790" : {
"id":179790,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"179770" : {
"id":179770,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000033000",
"type":"Enumeratiewaarde"
}
]
}
,
"179772" : {
"id":179772,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"00000004000000146000",
"type":"Enumeratiewaarde"
}
]
}
,
"179791" : {
"id":179791,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Besloten tot beeindigen voorbereiden ZM?",
"type":"Gateway"
}
]
}
,
"179792" : {
"id":179792,
"typeIconPath":"data/icons/BPMN/BPMN_Gateway.png",
"data" : [
{
"name":"Gateway",
"type":"Gateway"
}
]
}
,
"179793" : {
"id":179793,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179794" : {
"id":179794,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Melden indienen verzoekschrift",
"type":"Task"
}
]
}
,
"179376" : {
"id":179376,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG103 - Aanwijzing GD",
"type":"Tekenvorm"
}
]
}
,
"179378" : {
"id":179378,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"179379" : {
"id":179379,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"179381" : {
"id":179381,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"179380" : {
"id":179380,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"179377" : {
"id":179377,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"179448" : {
"id":179448,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG105 - Medische verklaring",
"type":"Tekenvorm"
}
]
}
,
"179451" : {
"id":179451,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"179449" : {
"id":179449,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"179450" : {
"id":179450,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"179452" : {
"id":179452,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"179453" : {
"id":179453,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"179518" : {
"id":179518,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"179514" : {
"id":179514,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"179515" : {
"id":179515,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"179516" : {
"id":179516,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"179517" : {
"id":179517,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"179513" : {
"id":179513,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG107 - Bevindingen GD",
"type":"Tekenvorm"
}
]
}
,
"179579" : {
"id":179579,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG109 - Beslissing voorbereiding of indiening ZM",
"type":"Tekenvorm"
}
]
}
,
"179580" : {
"id":179580,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"179584" : {
"id":179584,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"179583" : {
"id":179583,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"179581" : {
"id":179581,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"179582" : {
"id":179582,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"179724" : {
"id":179724,
"typeIconPath":"data/icons/BPMN/BPMN_LaneSet.png",
"data" : [
{
"name":"Lane set",
"type":"Lane set"
}
]
}
,
"179726" : {
"id":179726,
"typeIconPath":"data/icons/BPMN/BPMN_EndEvent.png",
"data" : [
{
"name":"Aanwijzing GD is ontvangen",
"type":"End event"
}
]
}
,
"179720" : {
"id":179720,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"Sequence flow",
"type":"Sequence flow"
}
]
}
,
"179728" : {
"id":179728,
"typeIconPath":"data/icons/BPMN/BPMN_Lane.png",
"data" : [
{
"name":"Ontvangen",
"type":"Lane"
}
]
}
,
"179722" : {
"id":179722,
"typeIconPath":"data/icons/BPMN/BPMN_Task.png",
"data" : [
{
"name":"Retourbericht aanwijzing GD verzenden",
"type":"Task"
}
]
}
,
"179730" : {
"id":179730,
"typeIconPath":"data/icons/BPMN/BPMN_SequenceFlow.png",
"data" : [
{
"name":"NEE",
"type":"Sequence flow"
}
]
}
,
"152694" : {
"id":152694,
"typeIconPath":"data/icons/ArchiMate/RSThreatEvent.png",
"data" : [
{
"name":"Release: iWlz 2.1.1",
"type":"Bedreigingsevent"
}
]
}
,
"152693" : {
"id":152693,
"typeIconPath":"data/icons/ArchiMate/RSThreatEvent.png",
"data" : [
{
"name":"Release: iJw 2.4.1",
"type":"Bedreigingsevent"
}
]
}
,
"152692" : {
"id":152692,
"typeIconPath":"data/icons/ArchiMate/RSThreatEvent.png",
"data" : [
{
"name":"Release: iPgb 2.1.0",
"type":"Bedreigingsevent"
}
]
}
,
"152695" : {
"id":152695,
"typeIconPath":"data/icons/ArchiMate/RSThreatEvent.png",
"data" : [
{
"name":"Release: iWmo 2.4.1",
"type":"Bedreigingsevent"
}
]
}
,
"152691" : {
"id":152691,
"typeIconPath":"data/icons/ArchiMate/RSThreatEvent.png",
"data" : [
{
"name":"Release: iEb 1.0.2",
"type":"Bedreigingsevent"
}
]
}
,
"190461" : {
"id":190461,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190468" : {
"id":190468,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"190469" : {
"id":190469,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"190471" : {
"id":190471,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"190470" : {
"id":190470,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"190472" : {
"id":190472,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"190292" : {
"id":190292,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iJw 2.3",
"type":"Tekenvorm"
}
]
}
,
"190284" : {
"id":190284,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iEb 1.0",
"type":"Tekenvorm"
}
]
}
,
"190300" : {
"id":190300,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iWmo 2.4",
"type":"Tekenvorm"
}
]
}
,
"190304" : {
"id":190304,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iJw",
"type":"Tekenvorm"
}
]
}
,
"190281" : {
"id":190281,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iPgb 2.1",
"type":"Tekenvorm"
}
]
}
,
"190296" : {
"id":190296,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iPgb 2.1",
"type":"Tekenvorm"
}
]
}
,
"190314" : {
"id":190314,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iJw 2.4",
"type":"Tekenvorm"
}
]
}
,
"190297" : {
"id":190297,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190290" : {
"id":190290,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iWlz",
"type":"Tekenvorm"
}
]
}
,
"190286" : {
"id":190286,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Lopend",
"type":"Tekenvorm"
}
]
}
,
"190274" : {
"id":190274,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190302" : {
"id":190302,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190288" : {
"id":190288,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iEb",
"type":"Tekenvorm"
}
]
}
,
"190312" : {
"id":190312,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190317" : {
"id":190317,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190315" : {
"id":190315,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iPgb",
"type":"Tekenvorm"
}
]
}
,
"190278" : {
"id":190278,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190294" : {
"id":190294,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iWmo 2.3",
"type":"Tekenvorm"
}
]
}
,
"190299" : {
"id":190299,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190311" : {
"id":190311,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iEb 1.0",
"type":"Tekenvorm"
}
]
}
,
"190282" : {
"id":190282,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190275" : {
"id":190275,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iWmo",
"type":"Tekenvorm"
}
]
}
,
"190308" : {
"id":190308,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iPgb 2.0",
"type":"Tekenvorm"
}
]
}
,
"190306" : {
"id":190306,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190321" : {
"id":190321,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190332" : {
"id":190332,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"In voorbereiding",
"type":"Tekenvorm"
}
]
}
,
"190318" : {
"id":190318,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190327" : {
"id":190327,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190323" : {
"id":190323,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190338" : {
"id":190338,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190339" : {
"id":190339,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iWmo 2.1",
"type":"Tekenvorm"
}
]
}
,
"190349" : {
"id":190349,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190343" : {
"id":190343,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190344" : {
"id":190344,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190334" : {
"id":190334,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iWlz 2.0.2",
"type":"Tekenvorm"
}
]
}
,
"190336" : {
"id":190336,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190345" : {
"id":190345,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190333" : {
"id":190333,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iStandaarden is een set van informatiestandaarden die gebruikt wordt om informatie uit te wisselen over de  uitvoering van de wetten Wlz, Wmo en Jeugdwet. Deze wetten op het gebied van zorg en ondersteuning kennen  elk een eigen informatiestandaard; iWlz, iWmo en iJw. Daarnaast is iPgb ontwikkeld, hiermee kan informatie  worden uitgewisseld over clienten met een pgb binnen alle drie deze wetten. De berichtenstandaarden iWlz, iPgb,  iWmo en iJw gebruiken waar mogelijk dezelfde elementen en systematiek.  Het Informatiemodel iStandaarden brengt de complete systematiek van de iStandaarden in kaart. Per iStandaard  worden processen, regels en berichtspecificaties in onderlinge samenhang getoond. Meer informatie over de  achtergrond en het beheer van iStandaarden vindt u op www.istandaarden.nl en in het boekje \"Wat u moet weten  over iStandaarden\" (zie Tools aan de rechterzijde van deze pagina)'.",
"type":"Tekenvorm"
}
]
}
,
"190329" : {
"id":190329,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190353" : {
"id":190353,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Archief",
"type":"Tekenvorm"
}
]
}
,
"190324" : {
"id":190324,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Lopend",
"type":"Tekenvorm"
}
]
}
,
"190348" : {
"id":190348,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190320" : {
"id":190320,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190337" : {
"id":190337,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190346" : {
"id":190346,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"In voorbereiding",
"type":"Tekenvorm"
}
]
}
,
"190341" : {
"id":190341,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iWlz 2.1",
"type":"Tekenvorm"
}
]
}
,
"190347" : {
"id":190347,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190350" : {
"id":190350,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190351" : {
"id":190351,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190354" : {
"id":190354,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190360" : {
"id":190360,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190367" : {
"id":190367,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190368" : {
"id":190368,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190359" : {
"id":190359,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190370" : {
"id":190370,
"typeIconPath":"data/icons/ArchiMate/ApplicationDataObject.png",
"data" : [
{
"name":"WLZ502",
"type":"Dataobject"
}
]
}
,
"190356" : {
"id":190356,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190355" : {
"id":190355,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190371" : {
"id":190371,
"typeIconPath":"data/icons/ArchiMate/ApplicationDataObject.png",
"data" : [
{
"name":"WLZ508",
"type":"Dataobject"
}
]
}
,
"190369" : {
"id":190369,
"typeIconPath":"data/icons/ArchiMate/RSSecurityDomain.png",
"data" : [
{
"name":"Beveiligingsdomein",
"type":"Beveiligingsdomein"
}
]
}
,
"190374" : {
"id":190374,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS003: Maximale waarde 9999",
"type":"Beperking"
}
]
}
,
"190357" : {
"id":190357,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190361" : {
"id":190361,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iJw 2.4",
"type":"Tekenvorm"
}
]
}
,
"190358" : {
"id":190358,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190366" : {
"id":190366,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190372" : {
"id":190372,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS040: Maximale waarde 999999999999 (12*9)",
"type":"Beperking"
}
]
}
,
"190364" : {
"id":190364,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatiemodel iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"190373" : {
"id":190373,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS039: Maximale lengte 14 posities",
"type":"Beperking"
}
]
}
,
"190378" : {
"id":190378,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS041: Vullen met hoofdletters of cijfers",
"type":"Beperking"
}
]
}
,
"190375" : {
"id":190375,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS025: Maximale lengte 64 posities",
"type":"Beperking"
}
]
}
,
"190379" : {
"id":190379,
"typeIconPath":"data/icons/ArchiMate/MotivationUseCase.png",
"data" : [
{
"name":"IV068: Hoe moeten percentages gevuld worden?",
"type":"Usecase"
}
]
}
,
"190377" : {
"id":190377,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS038: Vullen met UUID versie 4",
"type":"Beperking"
}
]
}
,
"190376" : {
"id":190376,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"RS042: Minimale waarde 1",
"type":"Beperking"
}
]
}
,
"190401" : {
"id":190401,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Berichtelement_1 : Datatype_LDT_of_CDT",
"type":"Attribuut"
}
]
}
,
"190388" : {
"id":190388,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Berichtklasse_1",
"type":"Klasse"
}
]
}
,
"190397" : {
"id":190397,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Berichtklasse_2",
"type":"Klasse"
}
]
}
,
"190398" : {
"id":190398,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"190402" : {
"id":190402,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Berichtelement_3 : Datatype_LDT_of_CDT",
"type":"Attribuut"
}
]
}
,
"190394" : {
"id":190394,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Berichtelement",
"type":"Attribuut"
}
]
}
,
"190391" : {
"id":190391,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Berichtelement_2 : Datatype_LDT_of_CDT",
"type":"Attribuut"
}
]
}
,
"190408" : {
"id":190408,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"190415" : {
"id":190415,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header Zorgkantoor - CAK",
"type":"Package"
}
]
}
,
"190421" : {
"id":190421,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header Zorgaanbieder - Zorgkantoor",
"type":"Package"
}
]
}
,
"190425" : {
"id":190425,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header Gemeente - Aanbieder",
"type":"Package"
}
]
}
,
"190428" : {
"id":190428,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header retour declaratie/factuur",
"type":"Package"
}
]
}
,
"190429" : {
"id":190429,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"190430" : {
"id":190430,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header Declaratie/factuur",
"type":"Package"
}
]
}
,
"190434" : {
"id":190434,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"190432" : {
"id":190432,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header Gemeente - CAK",
"type":"Package"
}
]
}
,
"190435" : {
"id":190435,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"StoornisScore generiek",
"type":"Package"
}
]
}
,
"190442" : {
"id":190442,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header Aanbieder - Gemeente",
"type":"Package"
}
]
}
,
"190444" : {
"id":190444,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"190438" : {
"id":190438,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Stoornis generiek",
"type":"Package"
}
]
}
,
"190439" : {
"id":190439,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Client Declaratie/factuur",
"type":"Package"
}
]
}
,
"190448" : {
"id":190448,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"190446" : {
"id":190446,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Client 305/307",
"type":"Package"
}
]
}
,
"190452" : {
"id":190452,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Dit template bepaalt de logica waarmee automatisch een retourbericht xsd wordt gegenereerd wanneer een xsd van het heenbericht wordt aangemaakt.  Om de retourcodes voor een berichtenstandaard mee te nemen in het basisschema: kies hieronder bij RetourCode het LDT_RetourCode van de betreffende berichtstandaard. Iedere berichtstandaard kent zijn eigen retourcodelijst, die gekoppeld is aan een eigen LDT_RetourCode.",
"type":"Tekenvorm"
}
]
}
,
"190451" : {
"id":190451,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Retourbericht iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"190454" : {
"id":190454,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190458" : {
"id":190458,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190456" : {
"id":190456,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190045" : {
"id":190045,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Maatregel",
"type":"Attribuut"
}
]
}
,
"190046" : {
"id":190046,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Omschrijving",
"type":"Attribuut"
}
]
}
,
"189949" : {
"id":189949,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189955" : {
"id":189955,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189948" : {
"id":189948,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189968" : {
"id":189968,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Invulinstructies Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189956" : {
"id":189956,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189953" : {
"id":189953,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatiemodel iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"189959" : {
"id":189959,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189952" : {
"id":189952,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"De processen in het Informatiemodel zijn afgeleid uit de waardeketen voor zorg en ondersteuning, zoals die  hieronder is weergegeven.  De onderste balk van de waardeketen geeft het primaire proces weer dat de client doorloopt. Het clientproces  start bij het moment dat hij vaststelt dat hij mogelijk behoefte heeft aan zorg of ondersteuning (bewustwording)  en loopt tot en met de levering van zorg of ondersteuning en de evaluatie daarvan.   Het bovenste deel van de waardeketen toont de ondersteunende processen die uitvoering van het primaire proces  mogelijk maken.",
"type":"Tekenvorm"
}
]
}
,
"189957" : {
"id":189957,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189960" : {
"id":189960,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189964" : {
"id":189964,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189962" : {
"id":189962,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Over iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"189967" : {
"id":189967,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189945" : {
"id":189945,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189969" : {
"id":189969,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Constraints Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189971" : {
"id":189971,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Uitgangspunten Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189970" : {
"id":189970,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Technische regels Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189972" : {
"id":189972,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Condities Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189973" : {
"id":189973,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Bedrijfsregels Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189975" : {
"id":189975,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189979" : {
"id":189979,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Datatypen Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189983" : {
"id":189983,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189986" : {
"id":189986,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"De casuistiek ter ondersteuning van iWvggz 1.0 is nog niet uitgewerkt.",
"type":"Tekenvorm"
}
]
}
,
"189987" : {
"id":189987,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189988" : {
"id":189988,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Over iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"189990" : {
"id":189990,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189991" : {
"id":189991,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189976" : {
"id":189976,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Codelijsten Wvggz",
"type":"Tekenvorm"
}
]
}
,
"189977" : {
"id":189977,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189980" : {
"id":189980,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189999" : {
"id":189999,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"190000" : {
"id":190000,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"189994" : {
"id":189994,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189998" : {
"id":189998,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatiemodel iWvggz",
"type":"Tekenvorm"
}
]
}
,
"189995" : {
"id":189995,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Casussen iWvggz",
"type":"Tekenvorm"
}
]
}
,
"190003" : {
"id":190003,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"DocumentInformatie",
"type":"Package"
}
]
}
,
"190014" : {
"id":190014,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Header iWvggz",
"type":"Package"
}
]
}
,
"189771" : {
"id":189771,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing tav voorbereiden VCM",
"type":"Message"
}
]
}
,
"189772" : {
"id":189772,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"189773" : {
"id":189773,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Meldiing indienen verzoekschrift",
"type":"Message"
}
]
}
,
"189774" : {
"id":189774,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing tav voorbereiden VCM",
"type":"Message"
}
]
}
,
"189770" : {
"id":189770,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Procesmodel voorbereiding ZM nav voorstel berichten GGZ - OM (KBG iWvggz d.d. 17 maart 2020)",
"type":"Tekenvorm"
}
]
}
,
"189769" : {
"id":189769,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Hoofdprocesflow met activiteiten waar berichten ontstaan en worden verwerkt  (i) Informatieproducten die geen onderdeel uitmaken van de huidige berichtscope zijn hier niet in meegenomen (bijv. schorsen / hervatten voorbereiding ZM) (ii) Bedoeld als beschrijvend model om de volgorde / flow van de berichten af te kunnen leiden (niet als voorschrijvend model voor de interne bedrijfsvoering)",
"type":"Tekenvorm"
}
]
}
,
"189777" : {
"id":189777,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Choreografiemodel ZM voorbereiden (iWvggz v1.0 - Concept 14-7-'20)",
"type":"Tekenvorm"
}
]
}
,
"189776" : {
"id":189776,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"189775" : {
"id":189775,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour melding indienen verzoekschrift",
"type":"Message"
}
]
}
,
"189828" : {
"id":189828,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Procesmodel ZM voorbereiden (iWvggz v1.0 - Concept 14-7-'20)",
"type":"Tekenvorm"
}
]
}
,
"189838" : {
"id":189838,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Hoofdprocesflow met activiteiten waar berichten ontstaan en worden verwerkt  (i) Informatieproducten die geen onderdeel uitmaken van de huidige berichtscope zijn hier niet in meegenomen (bijv. schorsen / hervatten voorbereiding ZM) (ii) Bedoeld als beschrijvend model om de volgorde / flow van de berichten af te kunnen leiden (niet als voorschrijvend model voor de interne bedrijfsvoering)",
"type":"Tekenvorm"
}
]
}
,
"189843" : {
"id":189843,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Bericht VCM ()",
"type":"Message"
}
]
}
,
"189846" : {
"id":189846,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour persoonsgegevens betrokkene ()",
"type":"Message"
}
]
}
,
"189844" : {
"id":189844,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour Bericht VCM ()",
"type":"Message"
}
]
}
,
"189845" : {
"id":189845,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene ()",
"type":"Message"
}
]
}
,
"189636" : {
"id":189636,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing tav voorbereiden VCM",
"type":"Message"
}
]
}
,
"189637" : {
"id":189637,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing tav voorbereiden VCM",
"type":"Message"
}
]
}
,
"189634" : {
"id":189634,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Choreografiemodel voorbereiding ZM nav voorstel berichten GGZ - OM (KBG iWvggz d.d. 3 maart 2020)",
"type":"Tekenvorm"
}
]
}
,
"189635" : {
"id":189635,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"189638" : {
"id":189638,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"189702" : {
"id":189702,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Hoofdprocesflow met activiteiten waar berichten ontstaan en worden verwerkt  (i) Informatieproducten die geen onderdeel uitmaken van de huidige berichtscope zijn hier niet in meegenomen (bijv. schorsen / hervatten voorbereiding ZM) (ii) Bedoeld als beschrijvend model om de volgorde / flow van de berichten af te kunnen leiden (niet als voorschrijvend model voor de interne bedrijfsvoering)",
"type":"Tekenvorm"
}
]
}
,
"189703" : {
"id":189703,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Procesmodel voorbereiding ZM nav voorstel berichten GGZ - OM (iWvggz v0.1)",
"type":"Tekenvorm"
}
]
}
,
"189705" : {
"id":189705,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour contactgegevens betrokkene",
"type":"Message"
}
]
}
,
"189706" : {
"id":189706,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Contactgegevens betrokkene",
"type":"Message"
}
]
}
,
"189707" : {
"id":189707,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour informatie ZM aansluitend op VCM",
"type":"Message"
}
]
}
,
"189704" : {
"id":189704,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Choreografiemodel voorbereiding ZM nav voorstel berichten GGZ - OM (iWvggz v0.1)",
"type":"Tekenvorm"
}
]
}
,
"189708" : {
"id":189708,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Informatie ZM aansluitend op VCM",
"type":"Message"
}
]
}
,
"189709" : {
"id":189709,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Choreografiemodel voorbereiding ZM nav voorstel berichten GGZ - OM (KBG iWvggz d.d. 17 maart)",
"type":"Tekenvorm"
}
]
}
,
"189633" : {
"id":189633,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Happy flow met activiteiten waar berichten ontstaan en worden verwerkt  (i) Informatieproducten die geen onderdeel uitmaken van de huidige berichtscope zijn hier niet in meegenomen (bijv. schorsen / hervatten voorbereiding ZM) (ii) Bedoeld als beschrijvend model om de volgorde / flow van de berichten af te kunnen leiden (niet als voorschrijvend model voor de interne bedrijfsvoering)",
"type":"Tekenvorm"
}
]
}
,
"189632" : {
"id":189632,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Procesmodel voorbereiding ZM nav voorstel berichten GGZ - OM (KBG iWvggz d.d. 3 maart 2020)",
"type":"Tekenvorm"
}
]
}
,
"189557" : {
"id":189557,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Beslissing tav voorbereiden VCM",
"type":"Message"
}
]
}
,
"189559" : {
"id":189559,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"189554" : {
"id":189554,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour melding indienen verzoekschrift",
"type":"Message"
}
]
}
,
"189555" : {
"id":189555,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour persoonsgegevens betrokkene",
"type":"Message"
}
]
}
,
"189556" : {
"id":189556,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Meldiing indienen verzoekschrift",
"type":"Message"
}
]
}
,
"189558" : {
"id":189558,
"typeIconPath":"data/icons/BPMN/BPMN_Message.png",
"data" : [
{
"name":"Retour beslissing tav voorbereiden VCM",
"type":"Message"
}
]
}
,
"189535" : {
"id":189535,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Happy flow met activiteiten waar berichten ontstaan en worden verwerkt  (i) Informatieproducten die geen onderdeel uitmaken van de huidige berichtscope zijn hier niet in meegenomen (bijv. schorsen / hervatten voorbereiding ZM) (ii) Bedoeld als beschrijvend model om de volgorde / flow van de berichten af te kunnen leiden (niet als voorschrijvend model voor de interne bedrijfsvoering)",
"type":"Tekenvorm"
}
]
}
,
"189536" : {
"id":189536,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Procesmodel voorbereiding ZM nav voorstel berichten GGZ - OM (KBG iWvggz d.d. 3 maart 2020) - gewijzigd nav sessie",
"type":"Tekenvorm"
}
]
}
,
"187050" : {
"id":187050,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"187044" : {
"id":187044,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"187046" : {
"id":187046,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"187039" : {
"id":187039,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG115 - Bericht VCM",
"type":"Tekenvorm"
}
]
}
,
"187042" : {
"id":187042,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"187048" : {
"id":187048,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"187216" : {
"id":187216,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187217" : {
"id":187217,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG103 berichtklassen",
"type":"Package"
}
]
}
,
"187214" : {
"id":187214,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG111 berichtklassen",
"type":"Package"
}
]
}
,
"187219" : {
"id":187219,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187208" : {
"id":187208,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG101 berichtklassen",
"type":"Package"
}
]
}
,
"187220" : {
"id":187220,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG109 berichtklassen",
"type":"Package"
}
]
}
,
"187221" : {
"id":187221,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187223" : {
"id":187223,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187210" : {
"id":187210,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"CrisismaatregelDatum",
"type":"Klasse"
}
]
}
,
"187222" : {
"id":187222,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG Retour",
"type":"Package"
}
]
}
,
"187207" : {
"id":187207,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187224" : {
"id":187224,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG105 berichtklassen",
"type":"Package"
}
]
}
,
"187218" : {
"id":187218,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187225" : {
"id":187225,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187203" : {
"id":187203,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afgiftedatum",
"type":"Attribuut"
}
]
}
,
"187204" : {
"id":187204,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"AfgiftePlaats",
"type":"Attribuut"
}
]
}
,
"187206" : {
"id":187206,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG113 berichtklassen",
"type":"Package"
}
]
}
,
"187209" : {
"id":187209,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"187211" : {
"id":187211,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187212" : {
"id":187212,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG107 berichtklassen",
"type":"Package"
}
]
}
,
"187213" : {
"id":187213,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187215" : {
"id":187215,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187205" : {
"id":187205,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187248" : {
"id":187248,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187245" : {
"id":187245,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187226" : {
"id":187226,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187231" : {
"id":187231,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187246" : {
"id":187246,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187255" : {
"id":187255,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187238" : {
"id":187238,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187253" : {
"id":187253,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187227" : {
"id":187227,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187235" : {
"id":187235,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"WVG115 berichtklassen",
"type":"Package"
}
]
}
,
"187242" : {
"id":187242,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187229" : {
"id":187229,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187250" : {
"id":187250,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187241" : {
"id":187241,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187251" : {
"id":187251,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187233" : {
"id":187233,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187240" : {
"id":187240,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187234" : {
"id":187234,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187230" : {
"id":187230,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187232" : {
"id":187232,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187239" : {
"id":187239,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187243" : {
"id":187243,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187254" : {
"id":187254,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187228" : {
"id":187228,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187236" : {
"id":187236,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187237" : {
"id":187237,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187249" : {
"id":187249,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187258" : {
"id":187258,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187247" : {
"id":187247,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187244" : {
"id":187244,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187252" : {
"id":187252,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187290" : {
"id":187290,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187337" : {
"id":187337,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187322" : {
"id":187322,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187342" : {
"id":187342,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187324" : {
"id":187324,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187352" : {
"id":187352,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187328" : {
"id":187328,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187317" : {
"id":187317,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationRequirementSpecialization.png",
"data" : [
{
"name":"Specialisatierelatie",
"type":"Specialisatierelatie"
}
]
}
,
"187315" : {
"id":187315,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187297" : {
"id":187297,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187307" : {
"id":187307,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187310" : {
"id":187310,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187292" : {
"id":187292,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187299" : {
"id":187299,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187303" : {
"id":187303,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationRequirementSpecialization.png",
"data" : [
{
"name":"Specialisatierelatie",
"type":"Specialisatierelatie"
}
]
}
,
"187333" : {
"id":187333,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187330" : {
"id":187330,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187339" : {
"id":187339,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187380" : {
"id":187380,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187371" : {
"id":187371,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187383" : {
"id":187383,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187398" : {
"id":187398,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187391" : {
"id":187391,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationRequirementSpecialization.png",
"data" : [
{
"name":"Specialisatierelatie",
"type":"Specialisatierelatie"
}
]
}
,
"187373" : {
"id":187373,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"187393" : {
"id":187393,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirementMotivationPrincipleRealisation.png",
"data" : [
{
"name":"Realisatierelatie",
"type":"Realisatierelatie"
}
]
}
,
"186237" : {
"id":186237,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186242" : {
"id":186242,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"186260" : {
"id":186260,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"[0..1]",
"type":"Tekenvorm"
}
]
}
,
"186256" : {
"id":186256,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Legenda",
"type":"Tekenvorm"
}
]
}
,
"186258" : {
"id":186258,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"{id}",
"type":"Tekenvorm"
}
]
}
,
"186248" : {
"id":186248,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"186243" : {
"id":186243,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186249" : {
"id":186249,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"186232" : {
"id":186232,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"GrondslagSoort",
"type":"Attribuut"
}
]
}
,
"186235" : {
"id":186235,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Organisatie",
"type":"Attribuut"
}
]
}
,
"186231" : {
"id":186231,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Datum",
"type":"Attribuut"
}
]
}
,
"186241" : {
"id":186241,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Contactgegevens",
"type":"Attribuut"
}
]
}
,
"186245" : {
"id":186245,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"186250" : {
"id":186250,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186247" : {
"id":186247,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"186240" : {
"id":186240,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geboortedatum",
"type":"Attribuut"
}
]
}
,
"186239" : {
"id":186239,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Geslacht",
"type":"Attribuut"
}
]
}
,
"186246" : {
"id":186246,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"186253" : {
"id":186253,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Bericht WVG113 - Aanlevering verplichte zorg",
"type":"Tekenvorm"
}
]
}
,
"186264" : {
"id":186264,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"element mag 0 of 1 keer voorkomen",
"type":"Tekenvorm"
}
]
}
,
"186236" : {
"id":186236,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186262" : {
"id":186262,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"sleutelgegeven",
"type":"Tekenvorm"
}
]
}
,
"186234" : {
"id":186234,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"186238" : {
"id":186238,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186244" : {
"id":186244,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"186233" : {
"id":186233,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"GeneesheerDirecteur",
"type":"Klasse"
}
]
}
,
"186342" : {
"id":186342,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186300" : {
"id":186300,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186348" : {
"id":186348,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186304" : {
"id":186304,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186328" : {
"id":186328,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186352" : {
"id":186352,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186354" : {
"id":186354,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186346" : {
"id":186346,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186314" : {
"id":186314,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186356" : {
"id":186356,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186332" : {
"id":186332,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186340" : {
"id":186340,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186324" : {
"id":186324,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186330" : {
"id":186330,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186344" : {
"id":186344,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186308" : {
"id":186308,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186316" : {
"id":186316,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186322" : {
"id":186322,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186306" : {
"id":186306,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186326" : {
"id":186326,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186302" : {
"id":186302,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186320" : {
"id":186320,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186338" : {
"id":186338,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186350" : {
"id":186350,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186318" : {
"id":186318,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186310" : {
"id":186310,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186336" : {
"id":186336,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186312" : {
"id":186312,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186334" : {
"id":186334,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186403" : {
"id":186403,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BegindatumTijd",
"type":"Attribuut"
}
]
}
,
"186358" : {
"id":186358,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186392" : {
"id":186392,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"186393" : {
"id":186393,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186362" : {
"id":186362,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186388" : {
"id":186388,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"186391" : {
"id":186391,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"186405" : {
"id":186405,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186396" : {
"id":186396,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"RapportagePeriode",
"type":"Attribuut"
}
]
}
,
"186390" : {
"id":186390,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"186399" : {
"id":186399,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Zelfbindingsverklaring",
"type":"Attribuut"
}
]
}
,
"186395" : {
"id":186395,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"VestigingsNummer",
"type":"Attribuut"
}
]
}
,
"186401" : {
"id":186401,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"LeveringsNummer",
"type":"Attribuut"
}
]
}
,
"186364" : {
"id":186364,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186360" : {
"id":186360,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186368" : {
"id":186368,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186366" : {
"id":186366,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186387" : {
"id":186387,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"186394" : {
"id":186394,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186398" : {
"id":186398,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Bsn",
"type":"Attribuut"
}
]
}
,
"186400" : {
"id":186400,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Zorgvorm",
"type":"Attribuut"
}
]
}
,
"186397" : {
"id":186397,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186389" : {
"id":186389,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"186402" : {
"id":186402,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"JuridischeTitel",
"type":"Attribuut"
}
]
}
,
"186404" : {
"id":186404,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"MomentDuurIndicatie",
"type":"Attribuut"
}
]
}
,
"186483" : {
"id":186483,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121621000146106",
"type":"Enumeratiewaarde"
}
]
}
,
"186485" : {
"id":186485,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"124041000146108",
"type":"Enumeratiewaarde"
}
]
}
,
"186481" : {
"id":186481,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121471000146108",
"type":"Enumeratiewaarde"
}
]
}
,
"186455" : {
"id":186455,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"123881000146109",
"type":"Enumeratiewaarde"
}
]
}
,
"186436" : {
"id":186436,
"typeIconPath":"data/icons/UML/UML_DataType.png",
"data" : [
{
"name":"LDT_BinaireInhoud",
"type":"Datatype"
}
]
}
,
"186475" : {
"id":186475,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"124061000146109",
"type":"Enumeratiewaarde"
}
]
}
,
"186487" : {
"id":186487,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"124071000146103",
"type":"Enumeratiewaarde"
}
]
}
,
"186438" : {
"id":186438,
"typeIconPath":"data/icons/UML/UML_PrimitiveType.png",
"data" : [
{
"name":"base64Binary",
"type":"Primitief type"
}
]
}
,
"186440" : {
"id":186440,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186449" : {
"id":186449,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121511000146100",
"type":"Enumeratiewaarde"
}
]
}
,
"186467" : {
"id":186467,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"225212001",
"type":"Enumeratiewaarde"
}
]
}
,
"186461" : {
"id":186461,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"68894007",
"type":"Enumeratiewaarde"
}
]
}
,
"186477" : {
"id":186477,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121641000146100",
"type":"Enumeratiewaarde"
}
]
}
,
"186457" : {
"id":186457,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"23835007",
"type":"Enumeratiewaarde"
}
]
}
,
"186444" : {
"id":186444,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186471" : {
"id":186471,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121601000146103",
"type":"Enumeratiewaarde"
}
]
}
,
"186453" : {
"id":186453,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121521000146105",
"type":"Enumeratiewaarde"
}
]
}
,
"186459" : {
"id":186459,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"130201000146105",
"type":"Enumeratiewaarde"
}
]
}
,
"186465" : {
"id":186465,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"225210009",
"type":"Enumeratiewaarde"
}
]
}
,
"186447" : {
"id":186447,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"29211000146105",
"type":"Enumeratiewaarde"
}
]
}
,
"186451" : {
"id":186451,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121531000146107",
"type":"Enumeratiewaarde"
}
]
}
,
"186473" : {
"id":186473,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"225309002",
"type":"Enumeratiewaarde"
}
]
}
,
"186463" : {
"id":186463,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"37041007",
"type":"Enumeratiewaarde"
}
]
}
,
"186479" : {
"id":186479,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"62407006",
"type":"Enumeratiewaarde"
}
]
}
,
"186469" : {
"id":186469,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121461000146102",
"type":"Enumeratiewaarde"
}
]
}
,
"186493" : {
"id":186493,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121411000146104",
"type":"Enumeratiewaarde"
}
]
}
,
"186539" : {
"id":186539,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"186489" : {
"id":186489,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"124051000146106",
"type":"Enumeratiewaarde"
}
]
}
,
"186491" : {
"id":186491,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121541000146104",
"type":"Enumeratiewaarde"
}
]
}
,
"186499" : {
"id":186499,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186505" : {
"id":186505,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"186495" : {
"id":186495,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"121631000146108",
"type":"Enumeratiewaarde"
}
]
}
,
"186497" : {
"id":186497,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"90278001",
"type":"Enumeratiewaarde"
}
]
}
,
"186591" : {
"id":186591,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"186606" : {
"id":186606,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186608" : {
"id":186608,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"AangewezenGeneesheerDirecteur",
"type":"Attribuut"
}
]
}
,
"186609" : {
"id":186609,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"AmbsthalveAangewezenIndicatie",
"type":"Attribuut"
}
]
}
,
"186611" : {
"id":186611,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"186610" : {
"id":186610,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186572" : {
"id":186572,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"186612" : {
"id":186612,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"186593" : {
"id":186593,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"186559" : {
"id":186559,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186562" : {
"id":186562,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0200",
"type":"Enumeratiewaarde"
}
]
}
,
"186590" : {
"id":186590,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186574" : {
"id":186574,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186605" : {
"id":186605,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"186587" : {
"id":186587,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Professional",
"type":"Attribuut"
}
]
}
,
"186603" : {
"id":186603,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Bestand",
"type":"Attribuut"
}
]
}
,
"186598" : {
"id":186598,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"DatumLaatsteWijziging",
"type":"Attribuut"
}
]
}
,
"186561" : {
"id":186561,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186567" : {
"id":186567,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Ontvanger",
"type":"Attribuut"
}
]
}
,
"186594" : {
"id":186594,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"186607" : {
"id":186607,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"186614" : {
"id":186614,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"186585" : {
"id":186585,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186568" : {
"id":186568,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Vertegenwoordiger",
"type":"Klasse"
}
]
}
,
"186595" : {
"id":186595,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"186579" : {
"id":186579,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Advocaat",
"type":"Klasse"
}
]
}
,
"186566" : {
"id":186566,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9612",
"type":"Enumeratiewaarde"
}
]
}
,
"186581" : {
"id":186581,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Naam",
"type":"Attribuut"
}
]
}
,
"186578" : {
"id":186578,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"WVGRelatie",
"type":"Attribuut"
}
]
}
,
"186580" : {
"id":186580,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Professional",
"type":"Attribuut"
}
]
}
,
"186575" : {
"id":186575,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"186588" : {
"id":186588,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186604" : {
"id":186604,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"186560" : {
"id":186560,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186563" : {
"id":186563,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0233",
"type":"Enumeratiewaarde"
}
]
}
,
"186573" : {
"id":186573,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"186583" : {
"id":186583,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Adres",
"type":"Attribuut"
}
]
}
,
"186584" : {
"id":186584,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186592" : {
"id":186592,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"186570" : {
"id":186570,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Aanvrager",
"type":"Klasse"
}
]
}
,
"186577" : {
"id":186577,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186569" : {
"id":186569,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Afzender",
"type":"Attribuut"
}
]
}
,
"186571" : {
"id":186571,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"186582" : {
"id":186582,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Contactgegevens",
"type":"Attribuut"
}
]
}
,
"186576" : {
"id":186576,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186628" : {
"id":186628,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186634" : {
"id":186634,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186652" : {
"id":186652,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186638" : {
"id":186638,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"186655" : {
"id":186655,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"186658" : {
"id":186658,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186657" : {
"id":186657,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186660" : {
"id":186660,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"186631" : {
"id":186631,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"186662" : {
"id":186662,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"186665" : {
"id":186665,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186629" : {
"id":186629,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Diagnose",
"type":"Attribuut"
}
]
}
,
"186635" : {
"id":186635,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186666" : {
"id":186666,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186636" : {
"id":186636,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186650" : {
"id":186650,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"186625" : {
"id":186625,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Soort",
"type":"Attribuut"
}
]
}
,
"186671" : {
"id":186671,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186672" : {
"id":186672,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186675" : {
"id":186675,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186633" : {
"id":186633,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186623" : {
"id":186623,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186648" : {
"id":186648,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"NoodzaakVerplichteZorg",
"type":"Attribuut"
}
]
}
,
"186632" : {
"id":186632,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186640" : {
"id":186640,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186668" : {
"id":186668,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186670" : {
"id":186670,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186674" : {
"id":186674,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186677" : {
"id":186677,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186678" : {
"id":186678,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186667" : {
"id":186667,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186676" : {
"id":186676,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186673" : {
"id":186673,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186644" : {
"id":186644,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186642" : {
"id":186642,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Professional",
"type":"Attribuut"
}
]
}
,
"186627" : {
"id":186627,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Onderzoek",
"type":"Klasse"
}
]
}
,
"186615" : {
"id":186615,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186698" : {
"id":186698,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186709" : {
"id":186709,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186723" : {
"id":186723,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Eenheid",
"type":"Attribuut"
}
]
}
,
"186684" : {
"id":186684,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186691" : {
"id":186691,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186694" : {
"id":186694,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186718" : {
"id":186718,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186681" : {
"id":186681,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"OnafhankelijkPsychiater",
"type":"Klasse"
}
]
}
,
"186697" : {
"id":186697,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186727" : {
"id":186727,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"ZorgvormCategorie",
"type":"Attribuut"
}
]
}
,
"186707" : {
"id":186707,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtVersie",
"type":"Attribuut"
}
]
}
,
"186729" : {
"id":186729,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtIdentificatie",
"type":"Attribuut"
}
]
}
,
"186696" : {
"id":186696,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186733" : {
"id":186733,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186734" : {
"id":186734,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186708" : {
"id":186708,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186683" : {
"id":186683,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186710" : {
"id":186710,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186693" : {
"id":186693,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186716" : {
"id":186716,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186730" : {
"id":186730,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186731" : {
"id":186731,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186732" : {
"id":186732,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186717" : {
"id":186717,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186685" : {
"id":186685,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186688" : {
"id":186688,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186689" : {
"id":186689,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186690" : {
"id":186690,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186679" : {
"id":186679,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186687" : {
"id":186687,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186682" : {
"id":186682,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186695" : {
"id":186695,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186692" : {
"id":186692,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186714" : {
"id":186714,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Aantal",
"type":"Attribuut"
}
]
}
,
"186715" : {
"id":186715,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186686" : {
"id":186686,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186712" : {
"id":186712,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"XsdVersie",
"type":"Attribuut"
}
]
}
,
"186719" : {
"id":186719,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186743" : {
"id":186743,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"OrganisatieNaam",
"type":"Attribuut"
}
]
}
,
"186768" : {
"id":186768,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186775" : {
"id":186775,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186771" : {
"id":186771,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186787" : {
"id":186787,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186795" : {
"id":186795,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186796" : {
"id":186796,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186797" : {
"id":186797,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186798" : {
"id":186798,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186753" : {
"id":186753,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186777" : {
"id":186777,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186735" : {
"id":186735,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186776" : {
"id":186776,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186779" : {
"id":186779,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186736" : {
"id":186736,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186767" : {
"id":186767,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186774" : {
"id":186774,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186781" : {
"id":186781,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186765" : {
"id":186765,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186751" : {
"id":186751,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186780" : {
"id":186780,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186755" : {
"id":186755,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtSubversie",
"type":"Attribuut"
}
]
}
,
"186772" : {
"id":186772,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186778" : {
"id":186778,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186758" : {
"id":186758,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"VerklarendGeneesheerDirecteur",
"type":"Klasse"
}
]
}
,
"186745" : {
"id":186745,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"OrganisatieContactgegevens",
"type":"Attribuut"
}
]
}
,
"186748" : {
"id":186748,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"OrganisatieAdres",
"type":"Attribuut"
}
]
}
,
"186762" : {
"id":186762,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186760" : {
"id":186760,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Professional",
"type":"Attribuut"
}
]
}
,
"186770" : {
"id":186770,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186782" : {
"id":186782,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186738" : {
"id":186738,
"typeIconPath":"data/icons/UML/UML_Association.png",
"data" : [
{
"name":"Associatie",
"type":"Associatie"
}
]
}
,
"186750" : {
"id":186750,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"BerichtType",
"type":"Attribuut"
}
]
}
,
"186784" : {
"id":186784,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186769" : {
"id":186769,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186786" : {
"id":186786,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186741" : {
"id":186741,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Header",
"type":"Klasse"
}
]
}
,
"186788" : {
"id":186788,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186766" : {
"id":186766,
"typeIconPath":"data/icons/UML/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"186773" : {
"id":186773,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186783" : {
"id":186783,
"typeIconPath":"data/icons/UML/ViewEdge.png",
"data" : [
{
"name":"Verbinding",
"type":"Verbinding"
}
]
}
,
"186739" : {
"id":186739,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"BelasteZorgaanbieder",
"type":"Klasse"
}
]
}
,
"186823" : {
"id":186823,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186813" : {
"id":186813,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186820" : {
"id":186820,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186819" : {
"id":186819,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186801" : {
"id":186801,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186799" : {
"id":186799,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186815" : {
"id":186815,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186803" : {
"id":186803,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186825" : {
"id":186825,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Huisletter",
"type":"Attribuut"
}
]
}
,
"186804" : {
"id":186804,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186821" : {
"id":186821,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186845" : {
"id":186845,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186806" : {
"id":186806,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186810" : {
"id":186810,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186809" : {
"id":186809,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186817" : {
"id":186817,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186808" : {
"id":186808,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186814" : {
"id":186814,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186802" : {
"id":186802,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186818" : {
"id":186818,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186836" : {
"id":186836,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"HuisnummerToevoeging",
"type":"Attribuut"
}
]
}
,
"186812" : {
"id":186812,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186811" : {
"id":186811,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186800" : {
"id":186800,
"typeIconPath":"data/icons/ArchiMate/ElementRelationAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186807" : {
"id":186807,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186839" : {
"id":186839,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186805" : {
"id":186805,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186816" : {
"id":186816,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186822" : {
"id":186822,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"186830" : {
"id":186830,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Adressoort",
"type":"Attribuut"
}
]
}
,
"186827" : {
"id":186827,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"AanduidingBijAdres",
"type":"Attribuut"
}
]
}
,
"186869" : {
"id":186869,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Professional",
"type":"Package"
}
]
}
,
"186866" : {
"id":186866,
"typeIconPath":"data/icons/UML/UML_Package.png",
"data" : [
{
"name":"Betrokkene",
"type":"Package"
}
]
}
,
"186865" : {
"id":186865,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"186870" : {
"id":186870,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"186868" : {
"id":186868,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Professional",
"type":"Klasse"
}
]
}
,
"186867" : {
"id":186867,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"189368" : {
"id":189368,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces medisch onderzoeken",
"type":"Tekenvorm"
}
]
}
,
"189385" : {
"id":189385,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces ZM aanvragen",
"type":"Tekenvorm"
}
]
}
,
"189407" : {
"id":189407,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces GD aanwijzen",
"type":"Tekenvorm"
}
]
}
,
"189429" : {
"id":189429,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces indiening VCM mededelen",
"type":"Tekenvorm"
}
]
}
,
"189435" : {
"id":189435,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - ZM(zorgmachtiging) voorbereiden",
"type":"Tekenvorm"
}
]
}
,
"189455" : {
"id":189455,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces gegevens geleverde verplichte zorg aanleveren",
"type":"Tekenvorm"
}
]
}
,
"189467" : {
"id":189467,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - Toezicht houden",
"type":"Tekenvorm"
}
]
}
,
"189470" : {
"id":189470,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Ondersteunende processen",
"type":"Tekenvorm"
}
]
}
,
"189471" : {
"id":189471,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Zelfbindingsverklaring opstellen",
"type":"Tekenvorm"
}
]
}
,
"189474" : {
"id":189474,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189490" : {
"id":189490,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Zorg verlenen",
"type":"Tekenvorm"
}
]
}
,
"189491" : {
"id":189491,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"CM voorbereiden",
"type":"Tekenvorm"
}
]
}
,
"189480" : {
"id":189480,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189486" : {
"id":189486,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"De processen in het informatiemodel zijn afgeleid uit de deelprocessen in het hoofdprocesmodel Wvggz en de nadere afbakening van de release thema's. Onderstaande plaat geeft de processen weer die momenteel in de roadmap t/m release 3.0 zijn opgenomen.  De huidige iWvggz 1.0 release ondersteund (deels) de gegevensuitwisseling tussen Zorgaanbieders, OM en stichting PVP voor: - Primaire processen: ZM voorbereiden (aanvragen en indienen)  en Toezicht houden (gegevens aanleveren) - Ondersteunende processen: Persoonsgegevens betrokkene verstrekken (aan stichting PVP)  Klik op de processen in de plaat voor details over de gegevensuitwisseling.",
"type":"Tekenvorm"
}
]
}
,
"189485" : {
"id":189485,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Primaire processen",
"type":"Tekenvorm"
}
]
}
,
"189483" : {
"id":189483,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - Processen",
"type":"Tekenvorm"
}
]
}
,
"189476" : {
"id":189476,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189481" : {
"id":189481,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189492" : {
"id":189492,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"Choreografiemodel voorbereiding ZM nav voorstel berichten GGZ - OM (KBG iWvggz d.d. 3 maart 2020) - gewijzigd nav sessie",
"type":"Tekenvorm"
}
]
}
,
"189319" : {
"id":189319,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces bevindingen beoordelen",
"type":"Tekenvorm"
}
]
}
,
"189340" : {
"id":189340,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces over voorbereiding ZM beslissen",
"type":"Tekenvorm"
}
]
}
,
"189296" : {
"id":189296,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - Persoonsgegevens betrokkene verstrekken",
"type":"Tekenvorm"
}
]
}
,
"188604" : {
"id":188604,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188632" : {
"id":188632,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188612" : {
"id":188612,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188685" : {
"id":188685,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188688" : {
"id":188688,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188753" : {
"id":188753,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188841" : {
"id":188841,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188838" : {
"id":188838,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188822" : {
"id":188822,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188825" : {
"id":188825,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188832" : {
"id":188832,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188818" : {
"id":188818,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188835" : {
"id":188835,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188814" : {
"id":188814,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188805" : {
"id":188805,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188817" : {
"id":188817,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188829" : {
"id":188829,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188871" : {
"id":188871,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188864" : {
"id":188864,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188878" : {
"id":188878,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188879" : {
"id":188879,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188857" : {
"id":188857,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188870" : {
"id":188870,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188852" : {
"id":188852,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188849" : {
"id":188849,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188860" : {
"id":188860,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188863" : {
"id":188863,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188850" : {
"id":188850,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188893" : {
"id":188893,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188883" : {
"id":188883,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188892" : {
"id":188892,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188894" : {
"id":188894,
"typeIconPath":"data/icons/ArchiMate/BusinessScheme.png",
"data" : [
{
"name":"Bronnen en registers",
"type":"Bedrijfslaag"
}
]
}
,
"188929" : {
"id":188929,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Model",
"type":"Model"
}
]
}
,
"188952" : {
"id":188952,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Voorbeeldregels",
"type":"Motivatie-elementen"
}
]
}
,
"188956" : {
"id":188956,
"typeIconPath":"data/icons/ArchiMate/BusinessScheme.png",
"data" : [
{
"name":"Voorbeeldproces",
"type":"Bedrijfslaag"
}
]
}
,
"188943" : {
"id":188943,
"typeIconPath":"data/icons/ArchiMate/ApplicationScheme.png",
"data" : [
{
"name":"Applicatielaag",
"type":"Applicatielaag"
}
]
}
,
"188994" : {
"id":188994,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189011" : {
"id":189011,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189012" : {
"id":189012,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189013" : {
"id":189013,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188986" : {
"id":188986,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Condities",
"type":"Motivatie-elementen"
}
]
}
,
"189005" : {
"id":189005,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Constraints - CS Gedeeld Wmo-Jw-Eb",
"type":"Motivatie-elementen"
}
]
}
,
"189029" : {
"id":189029,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"189048" : {
"id":189048,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Invulinstructies - IV Generiek",
"type":"Motivatie-elementen"
}
]
}
,
"189014" : {
"id":189014,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189038" : {
"id":189038,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Pattern restricties",
"type":"Motivatie-elementen"
}
]
}
,
"189041" : {
"id":189041,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"CD generiek",
"type":"Motivatie-elementen"
}
]
}
,
"189035" : {
"id":189035,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Constraints - CS Gedeeld Wlz-Wmo-Jw-Eb",
"type":"Motivatie-elementen"
}
]
}
,
"189053" : {
"id":189053,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"189018" : {
"id":189018,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"189024" : {
"id":189024,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Technische regels - TR domeinoverstijgend",
"type":"Motivatie-elementen"
}
]
}
,
"189028" : {
"id":189028,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"189046" : {
"id":189046,
"typeIconPath":"data/icons/ArchiMate/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"189080" : {
"id":189080,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189076" : {
"id":189076,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189075" : {
"id":189075,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189089" : {
"id":189089,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189061" : {
"id":189061,
"typeIconPath":"data/icons/ArchiMate/MotivationScheme.png",
"data" : [
{
"name":"Bedrijfsregels - OP Generiek",
"type":"Motivatie-elementen"
}
]
}
,
"189077" : {
"id":189077,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189090" : {
"id":189090,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189056" : {
"id":189056,
"typeIconPath":"data/icons/ArchiMate/CompositeScheme.png",
"data" : [
{
"name":"Samengestelde elementen",
"type":"Samengestelde elementen"
}
]
}
,
"189074" : {
"id":189074,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189122" : {
"id":189122,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189134" : {
"id":189134,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189135" : {
"id":189135,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Codelijsten",
"type":"Model"
}
]
}
,
"189125" : {
"id":189125,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189116" : {
"id":189116,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189177" : {
"id":189177,
"typeIconPath":"data/icons/UML/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"189145" : {
"id":189145,
"typeIconPath":"data/icons/UML/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"189141" : {
"id":189141,
"typeIconPath":"data/icons/UML/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"189198" : {
"id":189198,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Vervallen codes en codelijsten",
"type":"Model"
}
]
}
,
"189262" : {
"id":189262,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Datatypen generiek nav iWvggz",
"type":"Model"
}
]
}
,
"189268" : {
"id":189268,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Datatypen",
"type":"Model"
}
]
}
,
"189266" : {
"id":189266,
"typeIconPath":"data/icons/UML/UML_ElementsScheme.png",
"data" : [
{
"name":"Codelijsten",
"type":"Model"
}
]
}
,
"189290" : {
"id":189290,
"typeIconPath":"data/icons/BPMN/ViewGraphic.png",
"data" : [
{
"name":"iWvggz 1.0 - proces persoonsgegevens betrokkene verstrekken",
"type":"Tekenvorm"
}
]
}
,
"190159" : {
"id":190159,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP130: Van de relatie moet altijd een naam worden vastgelegd, aangevuld met een volledig adres en/of een telefoonnummer.",
"type":"Requirement"
}
]
}
,
"190158" : {
"id":190158,
"typeIconPath":"data/icons/ArchiMate/MotivationRequirement.png",
"data" : [
{
"name":"OP091: Van een client mogen aanvullende contactgegevens vastgelegd worden; er moet dan wel vastgelegd worden wat voor soort adres het betreft.",
"type":"Requirement"
}
]
}
,
"190169" : {
"id":190169,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Vul scripts voor automatisch invullen van custom eigenschappen",
"type":"Tekenvorm"
}
]
}
,
"190174" : {
"id":190174,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Genereer regeloverzicht voor model:",
"type":"Tekenvorm"
}
]
}
,
"190160" : {
"id":190160,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Bericht details view: Gecombineerd viewpoint dat onderstaande labels toont bij de datatypen: * Regelcode van gekoppelde regels op berichtelementen (modeloverstijgende associaties van een attribuut van een datatype naar beperking) * Op de Root klasse de volgende eigenschappen (van profiel Berichtklasse root):   * Titel   * Berichtcode   * Titel retourbericht   * Code retourbericht * Regelcode van gekoppelde technische regels die op de berichtklassen (is dit zinvol??)",
"type":"Tekenvorm"
}
]
}
,
"190182" : {
"id":190182,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Gebruik het viewpoint \"Vul 'Waar gebruikt voor rapportage\" voordat een model geexporteerd wordt voor rapportage.  Voor dit viewpoint is een eigenschap \"waar gebruikt\" toegevoegd aan verschillende onderdelen van het model. Opgehaald worden alle geassocieerde attributen of klassen, gevuld wordt op welke views deze voorkomen. Dit wordt ook meegenomen naar de inSight rapportage zodat daar ook te zien is in welke berichten datatypen en regels gebruikt worden.  De functie van dit script is om in de insite publicatie ook het nuttige deel van “waar gebruikt” functionaliteit te reproduceren. Daarvoor is bij een aantal concepten de eigenschap Wordt gebruikt in toegevoegd.   Die concepten zijn: • Alle regeltypes in ArchiMate • UML klassen • UML attributen • UML datatypes  Alle objecten in het modelpackage die deze eigenschap hebben worden ververst bij het uitvoeren van het script.  • Bij regels worden alle views (= berichten) opgenomen waarop een klasse of attribuut staat die verbonden is aan de regel, of waarvan het datatype verbonden is aan de regel • Bij alle uml objecten worden alle views (= berichten) opgenomen waarop een attribuut staat waarin het object wordt gebruikt. Voor een datatype betekent dit de views waarop attributen staan waarin dit datatype wordt gebruikt. • Klassen en attributen worden over het algemeen niet op andere plekken gebruikt, maar als het toch voorkomt wordt het met dit script inzichtelijk gemaakt voor de lezer.  Dit script moet voor elke publicatie uitgevoerd worden om de inhoud van de eigenschap bij te werken.  In v3 van het script is een wijziging doorgevoerd zodat het veld \"'waar gebruikt\" leeg gemaakt wordt wanneer er geen koppelingen meer zijn.",
"type":"Tekenvorm"
}
]
}
,
"190171" : {
"id":190171,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Gebruik het viewpoint \"Vul 'Waar gebruikt voor rapportage\" voordat een model geexporteerd wordt voor rapportage.  Voor dit viewpoint is een eigenschap \"waar gebruikt\" toegevoegd aan verschillende onderdelen van het model. Opgehaald worden alle geassocieerde attributen of klassen, gevuld wordt op welke views deze voorkomen. Dit wordt ook meegenomen naar de inSight rapportage zodat daar ook te zien is in welke berichten datatypen en regels gebruikt worden.  De functie van dit script is om in de insite publicatie ook het nuttige deel van “waar gebruikt” functionaliteit te reproduceren. Daarvoor is bij een aantal concepten de eigenschap Wordt gebruikt in toegevoegd.   Die concepten zijn: • Alle regeltypes in ArchiMate • UML klassen • UML attributen • UML datatypes  Alle objecten in het modelpackage die deze eigenschap hebben worden ververst bij het uitvoeren van het script.  • Bij regels worden alle views (= berichten) opgenomen waarop een klasse of attribuut staat die verbonden is aan de regel, of waarvan het datatype verbonden is aan de regel • Bij alle uml objecten worden alle views (= berichten) opgenomen waarop een attribuut staat waarin het object wordt gebruikt. Voor een datatype betekent dit de views waarop attributen staan waarin dit datatype wordt gebruikt. • Klassen en attributen worden over het algemeen niet op andere plekken gebruikt, maar als het toch voorkomt wordt het met dit script inzichtelijk gemaakt voor de lezer.  Dit script moet voor elke publicatie uitgevoerd worden om de inhoud van de eigenschap bij te werken.  In v3 van het script is een wijziging doorgevoerd zodat het veld \"'waar gebruikt\" leeg gemaakt wordt wanneer er geen koppelingen meer zijn.",
"type":"Tekenvorm"
}
]
}
,
"190189" : {
"id":190189,
"typeIconPath":"data/icons/UML/UML_Class.png",
"data" : [
{
"name":"Class",
"type":"Klasse"
}
]
}
,
"190167" : {
"id":190167,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Berichten generiek: Attributen op UML klasse sorteren Alle UML attributen in het model hebben een nummer dat de volgorde bepaalt waarin de attributen in het XSD worden opgenomen. De attributen worden echter niet automatisch op die volgorde getoond in UML klasse diagrammen. Het script zorgt ervoor dat de volgorde klopt met de volgorde in het xsd. Er is een script dat de volgorde alleen op de huidige view aanpast en een script dat de volgorde op álle views in het package aanpast. Hierbij worden views die 'read only' zijn gemaakt (wanneer binnen een project wordt gewerkt) niet aangepast.   Het script dat álle views aanpast, sorteert bovendien de Enumeration literals op alfabet.",
"type":"Tekenvorm"
}
]
}
,
"190161" : {
"id":190161,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"De eigenschappen die speciaal voor ZIN zijn toegevoegd aan het metamodel hebben een eigen naam in de configuratie. De configuratie van een model kan worden uitgebreid met extra eigenschappen m.b.v. de 'metamodeller'.",
"type":"Tekenvorm"
}
]
}
,
"190162" : {
"id":190162,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Vul regelcode: Onder Controle scripts staat ook het script Vul regelcode. Dit vult automatisch de eigenschap Code voor iedere regel in het model met het gedeelte van de titel vóór de dubbele punt.",
"type":"Tekenvorm"
}
]
}
,
"190175" : {
"id":190175,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Gebruik het viewpoint \"Genereer regeloverzicht voor model\" om voor één model te rapporteren welke regels waar van toepassing zijn.  Het viewpoint genereerd een Excel bestand met twee tabbladen: 1: Regels per bericht(element): voor ieder bericht in het model (o.b.v. de views) wordt weergegeven welke regels gekoppeld zijn op bericht, op berichtklasse of op berichtelement. De titel en de code van de regel wordt opgenomen in de output. 2: Regels: hierin staan uniek genoemd alle regels die van toepassing zijn op één model. Regeltype, -code, titel, documentatie en de evt. XSD restrictie regel worden opgenomen in de output.  Dit script genereert een regeltabel per element en eigenschappentabel voor alle gebruikte regels in een geselecteerd model.  Voor alle objecten in het geselecteerde model worden de gekoppelde regels opgehaald, en worden de aan gebruikte datatypes gekoppelde regels opgehaald. Het resultaat zijn twee worksheets in een excel venster, dat opgeslagen kan worden als een document. • De sheet Regels per bericht(element) bevat voor ieder object zijn gekoppelde regels, voor attributen wordt gespecificeerd voor welk van de gebruikte datatypes de regel is gekoppeld • De sheet Regels bevat alle regels die zijn gekoppeld, gesorteerd op type regel.  Dit script moet voor elke publicatie van het regelrapport uitgevoerd worden en het resultaat gepubliceerd. Ook kan het resultaat gebruikt worden voor inhoudelijke controle van de regels in het model.",
"type":"Tekenvorm"
}
]
}
,
"190177" : {
"id":190177,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Gebruik het viewpoint \"Genereer bericht xsd v#.#\" voor het genereren van de XML schema definitie voor een bericht én het bijbehorende retourbericht.  De xsd's worden gegenereerd op basis van de geselecteerde view. Voor de betreffende view worden alle berichtklassen afgelopen volgens de getekende relaties.  Als de juiste gegevens en modelvoorwaarden zijn ingevuld, wordt een retourbericht altijd samen met het heenbericht gegenereerd. Deze voorwaarden zijn: • Er moet één UML-klasseview genaamd \"Retourbericht Template\" in het modelpackage aanwezig zijn. • Op de Retourbericht Template view moeten klassen met de naam RootClass en MessageClass voorkomen. • Op de Rootklasse van het héénbericht moeten de eigenschappen Naam Retourbericht en Code Retourbericht ingevuld zijn. Deze waarden worden gebruikt in plaats van de waarden voor naam en berichtcode van het heenbericht.  RootClass en MessageClass representeren de generieke klassen die in een bericht worden gebruikt.; RootClass komt 1 keer voor in elk bericht.  MessageClass staat voor alle klassen in het bericht die niet de root klasse zijn.  De klassen Retourcode en Header komen overeen met klassen die in een bericht worden gebruikt met die naam.  Wanneer een klasse met dezelfde naam voorkomt op het retourtemplate, dan worden de attributen en relaties met cardinaliteit toegevoegd aan die specifieke klasse. Wanneer een klassenaam niet voorkomt op het retourtemplate, dan worden de relaties met cardinaliteit en attributen van MessageClass toegevoegd aan de berichtklasse. De rootklasse krijgt altijd de relaties en attributen van de klasse RootClass in het template.  De Client klasse krijgt een andere cardinaliteit mee, dit is \"hardcoded\" opgenomen in het script. Voor Client wordt de cardinaliteit in het retourbericht gesteld op 0..* voor Wlz en op 0..1 voor overige modellen.   Wanneer een basisschema wordt gegenereerd en er is een retourtemplate aanwezig in het modelpackage, dan worden altijd alle gebruikte datatypes in het retourtemplate in het basisschema gezet. Zo kan er altijd over de juiste types beschikt worden.",
"type":"Tekenvorm"
}
]
}
,
"190179" : {
"id":190179,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Genereer berichtschema zonder basisschema:",
"type":"Tekenvorm"
}
]
}
,
"190163" : {
"id":190163,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Controle scripts: 1: Controleer of alle Enum literals getoond worden Wanneer een Enumeration uitgebreid wordt met één of meer nieuwe literals, worden deze literals niet automatisch ook op de views (UML klasse diagram) waarop de Enumeration staat toegevoegd. Om ze wel op deze views te tonen, moet de hele enumeration opnieuw op de view gezet worden. Dit gaat regelmatig mis; het script controleert of alle enumeration literals van een enumeration die in het model op een view getoond ook daadwerkelijk voorkomen op de view.  2: Controleer koppeling van de regels Regels kennen onderlinge samenhang d.m.v. relaties en zijn gerelateerd aan de gegevenslaag d.m.v. modeloverstijgende relaties. Wanneer relaties niet goed zijn gelegd, worden niet de juiste koppelingen getoond in het informatiemodel. Het script controleert de volgende relaties en geeft per relatie een overzicht van de regels waar die niet goed zijn: 1. Een ArchiMate principe (uitgangspunt) wordt gerealiseerd door minimaal één ArchiMate Requirement (bedrijfsregel). 2. Een ArchiMate Requirement (bedrijfsregel) realiseert minimaal één ArchiMate principe (uitgangspunt).  3. Een ArchiMate Requirement (bedrijfsregel) is met een modeloverstijgende associatierelatie gekoppeld aan minimaal één UML-klasse met profiel “Berichtklasse Root”.  4. Een ArchiMate Beperking; profiel Technische regel is met een (niet modeloverstijgende!) associatierelatie gekoppeld aan een ArchiMate Requirement (bedrijfsregel). 5. Een ArchiMate Beperking met profiel Technische regel is niet met een modeloverstijgende associatierelatie gekoppeld aan een ArchiMate Requirement (bedrijfsregel).   3: Controleer of regeltype goed is ingesteld Alle regels worden gedefinieerd binnen de ArchiMate Motivation extension; ArchiMate principes worden automatisch gelabeld als Uitgangspunt, ArchiMate Requirements worden automatisch gelabeld als Bedrijfsregel en ArchiMate Usecases worden automatisch gelabeld als Invulinstructie. De ArchiMate Beperking wordt voor meerdere regeltypen gebruikt; hier moet handmatig een keuze gemaakt worden voor een profiel. Het script controleert of er een keuze is gemaakt: ArchiMate Beperking heeft ZIN profiel Constraint, Conditie of Technische regel. Regels waarvoor dit ontbreekt worden in een workset getoond.",
"type":"Tekenvorm"
}
]
}
,
"190172" : {
"id":190172,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Met dit script wordt een XSD van een héén- en retourbericht gegenereerd, waarbij alle gebruikte datatype-definities als onderdeel van het bericht XSD worden opgenomen. Er is dan dus geen verwijzing naar een basisschema.  NB: dit script neemt in het retourbericht niet de datatypen mee die alléén in het retourbericht gebruikt worden. Omdat we vooralsnog besloten hebben wel te blijven werken met een basisschema per domein, wordt dit nu niet gebruikt voor externe publicaties en wordt dit script vooralsnog niet aangepast om dit te corrigeren.",
"type":"Tekenvorm"
}
]
}
,
"190181" : {
"id":190181,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Genereer bericht xsd:",
"type":"Tekenvorm"
}
]
}
,
"190164" : {
"id":190164,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Datatype details view: Gecombineerd viewpoint dat onderstaande labels toont bij de datatypen: * Gekoppelde regels op het datatype (modeloverstijgende associaties van datatype naar beperking) * Op welke views het datatype gebruikt wordt (Basisprofiel \"Wordt gebruikt in\"; dit attribuut wordt gevuld met het script '\"Vul Waar gebruikt voor rapportage\". * De omschrijving bij de enumeraties (documentatie van Enumeration literals) * Gekoppelde regels op data elementen van een CDT (modeloverstijgende associaties van een attribuut van een datatype naar beperking)",
"type":"Tekenvorm"
}
]
}
,
"190166" : {
"id":190166,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Controle scripts",
"type":"Tekenvorm"
}
]
}
,
"190165" : {
"id":190165,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Attributen op views sorteren:",
"type":"Tekenvorm"
}
]
}
,
"190168" : {
"id":190168,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Toevoeging eigenschappen in metamodel:",
"type":"Tekenvorm"
}
]
}
,
"190170" : {
"id":190170,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Label views:",
"type":"Tekenvorm"
}
]
}
,
"190180" : {
"id":190180,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Genereer basisschema:",
"type":"Tekenvorm"
}
]
}
,
"190200" : {
"id":190200,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"* Primitive datatypen worden in het xsd basisschema opgenomen als de \"'restriction base\" van een LDT.  * Wanneer nieuwe primitives gewenst zijn, kunnen deze worden aangemaakt zolang de naam overeenkomt met de XML/XSD specificaties. * Let wel op dat de gekoppelde restricties toegestaan moeten zijn bij het gekozen primitive datatypen om een valide basisschema te kunnen genereren. Bijv. een integer kan een maxInclusive restrictie krijgen, maar geen maxLength.",
"type":"Tekenvorm"
}
]
}
,
"190203" : {
"id":190203,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Codelijst vullen vanuit Excel: * Klik in modelbrowser met rechtermuisknop op de enumeration; * Kies \"New multiple..\" enumeration literals; * Kies de eigenschappen die je wil vullen vanuit Excel (zoals Naam en documentatie); * kopieer de gegevens uit Excel en plak in Bizzdesign.",
"type":"Tekenvorm"
}
]
}
,
"190205" : {
"id":190205,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"* Een composite datatype heeft prefix \"CDT_\" * Een CDT is een datatype dat een aantal attributen bevat; elk attribuut wordt gekoppeld aan een ander CDT of aan een LDT. * Gelijk aan de werkwijze van een berichtklasse kan per attribuut worden aangegeven of het element optioneel of verplicht is (multiplicity 1 of 0..1) * Op een attribuut kan ook een conditie gekoppeld worden, indien het CDT altijd volgens dezelfde condities wordt opgebouwd. * Binnen het xsd basisschema wordt een CDT standaard omgezet in een complexType * Standaard wordt dit complexType opgebouwd als xs:sequence. * Een CDT kan ook in het xsd opgenomen worden als xs:choice (waarbij 1 van de attributen van het CDT verplicht gevuld moet worden). Dit kan worden aangegeven door het profiel \"choice\" te kiezen.",
"type":"Tekenvorm"
}
]
}
,
"190206" : {
"id":190206,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Stappenplan nieuw datatype aanmaken: 1. Maak binnen het juiste package een nieuw datatype aan. 2. Geef naam:  * afhankelijk van type: LDT_ of CDT_  * UpperCamelCase, kijk goed naar evt. aandere datatypen met vergelijkbare namen voor consistentie. Indien in normale taal 1 woord, dan in principe alleen begin met hoofdletter  * Bij samengestelde namen: onderwerp, dan eigenschap (bijv. AppelKleur) 3. Maak een view van het datatype en sleep het nieuw aangemaakte datatype daarop. 4. Voor een CDT:   * voeg de attributen toe  * geeft de attributen de juiste naam  * koppel de attributen aan de juiste datatypen  * vul de multiplicity in: 0..1 indien niet verplicht  * kies profiel \"choice\" indien het een choice datatype betreft 5. Koppel een LDT met een dependency relatie aan het primitive type. Datatypen die gevuld worden met nummers die geen numerieke betekenis hebben (codes) zijn altijd string! 6. Koppel indien van toepassing het LDT met dependency relatie aan een Enumeration. 7. Koppel het LDT met berichtoverstijgende associatie relatie aan geldende xsd restricties (altijd >=1 min/max restrictie en evt. ook een pattern restrictie. 8. Viewpoint \"Datatype detailview\" wordt gebruikt om te tonen:  * welke restricties gekoppeld zijn;  * de omschrijving van de literals van een enumeratie;  * op welke views het datatype gebruikt wordt. Als alle labels geselecteerd zijn (rechter muis: soortgelijke selecteren) kunnen met \"label aanhaken\" de labels allemaal rechts aangehaakt worden voor een duidelijkere weergave.",
"type":"Tekenvorm"
}
]
}
,
"190208" : {
"id":190208,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Ter referentie: naamgeving conventies Vektis: Elementnamen zijn zelfverklarend met de volgende uitgangspunten en gedefinieerd met behulp van een naam conventie: 1. semantisch: geordende opeenvolgingen van informatie 2. intuitief te begrijpen 3. betekenisvol en beschrijvend 4. niet omschrijvend, geen business rules en waardebereik in een elementdefinitie 5. herbruikbaar, een element staat op zich kan verschillend toegepast worden 6. een of meer woorden aan elkaar zonder spatie 7. elk woord begint met een hoofdletter en wordt gevolgd door kleine letters 8. weinig tot geen afkortingen 9. eenvoudige constructie: prefix onderwerp, suffix datatype, i.e DeclaratieBedrag 10. complexe constructie: volgorde is wie-onderwerp-status-bewerking-datatype, i.e ZorgaanbiederOntvangenTotaalbedrag",
"type":"Tekenvorm"
}
]
}
,
"190191" : {
"id":190191,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Stappenplan nieuw bericht aanmaken:  1. Maak in het juiste model een package aan met naam \"Berichtcode berichtklassen\"  2. Maak in hetzelfde model een klassenview aan met naam \"Berichtcode View\"  3. Maak de root aan:   3a. Maak in in het package met de berichtklassen een UML klasse aan met naam \"Berichtcode\".   3b. Kies voor deze klasse profiel Berichtklasse root (onder Eigenschappen)   3c. Geef in Eigenschappen de titel en de berichtcode op (die gevuld moet worden in BerichtCode)   3d. Geef in de Documentatie de omschrijving van het bericht op.  4. Hergebruik bestaande inhoudelijke berichtklassen:   4a. Wanneer precies dezelfde berichtklasse in meerdere berichten wordt gebruikt, kan deze in de Bibliotheek - Berichtklassen worden opgenomen. Voorwaarde is dat de klassen echt identiek zijn, inclusief alle gekoppelde regels. Deze klassen kunnen vanuit de bibliotheek op de View gesleept worden.   4b. Klassen die op elkaar lijken kunnen gekopieerd worden vanuit een ander package. Daarna op de view slepen en aanpassen naar gebruik binnen het betreffende bericht. Let op: bij kopieren worden niet de modeloverstijgende relaties naar de regels mee gekopieerd.   4c. Elementen die verwijderd worden uit gekopieerde berichtklassen: kies verwijderen uit model.   5. Maak nieuwe inhoudelijke berichtklassen aan:   5a. Maak een nieuwe UML klasse aan en geef de naam van de berichtklasse op (UpperCamelCase, let op consistentie met bestaande berichtklassen).   5b. Kies profiel Berichtklasse inhoud en geef het nummer op (volgordelijkheid binnen xsd) en de naam van de plural.   6. Maak nieuwe berichtelementen aan als attributen binnen de klasse:   6a. Geef de naam van het berichtelement op (UpperCamelCase, let op constistentie)   6b. Geef in documentatie de omschrijving op  7. Sleep de nieuw aangemaakte berichtklassen op de view   7a. Kies het datatype door te klikken op het blauwe attribuut icoontje (LDT of CDT)   7b. Indien het element optioneel is: multiplicity is 0..1   7c. Indien het een sleutelelement is: vink in Eigenschappen \"is ID\" aan   7d. Geef met het nummer in de profielinformatie (Eigenschappen) de volgordelijkheid van de elementen aan.  8. Zet alle berichtklassen netjes op de view   8a. Verbind de berichtklassen met elkaar met associatierelaties   8b. klik op het uiteinde van de relatielijn om aan te geven dat het een aggregatie betreft (het wiebertje aan de kant van de bovenliggende klasse)   8c. Geef de cardinaliteit op aan de kant van de onderliggende klasse indien deze anders is dan 0..1.   8d. Sorteer de elementen op volgorde van de aangegeven nummers met Viewpoint \"Attributen op UML klasse sorteren\"",
"type":"Tekenvorm"
}
]
}
,
"190199" : {
"id":190199,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Berichtelementen: * koppelen type = datatype LDT_ of CDT_ * multiplicity: default 1 (verplicht); indien berichtelement niet verplicht dan multiplicity op 0..1 zetten. * sleutelelement: vinkje \"Is ID\" aanzetten * attribuut \"nummer\" moet gevuld worden: dit bepaalt de volgorde van de elementen in het xsd. * om de volgorde van de elementen op de view te tonen: gebruik viewpoint \"Attributen op UML klasse sorteren in huidige view\"",
"type":"Tekenvorm"
}
]
}
,
"190198" : {
"id":190198,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Berichtklasse inhoud bevat extra profiel informatie: * nummer: bepaalt de volgorde van de berichtklassen in het xsd; * plural: bepaalt de naam van de collecties in het xsd voor berichtklassen die vaker dan 1x kunnen voorkomen.  De cardinaliteit op de relatie tussen berichtklassen bepaalt of de klasse verplicht/niet verplicht is en hoe vaak deze mag voorkomen. Default is 0..1, waar het anders is moet dit worden aangegeven.",
"type":"Tekenvorm"
}
]
}
,
"190204" : {
"id":190204,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"* Een logisch datatype heeft prefix \"LDT_\" * Een LDT is altijd afhankelijk van een primitive datatype * Een LDT wordt met modeloverstijgende associaties gekoppeld aan constraints: - lengte restrictie en evt. pattern - CS constraints indien deze altijd geldig is op alle toepassingen van het LDT over alle domeinen * Een LDT kan afhankelijk zijn van een Codelijst (Enumeration) * Een LDT wordt in het xsd basisschema opgenomen als simpleType met de gekoppelde restricties en evt. Enumeratie.",
"type":"Tekenvorm"
}
]
}
,
"190207" : {
"id":190207,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"* Enumerations krijgen de naam \"Code: naam\"  (bijv COD001: Codelijst) * Literals krijgen de naam van de code, de omschrijving wordt in de documentatie opgenomen (bijv. naam \"01\" documentatie \"Eerste code\") * In het xsd basisschema worden alle litterals van de enumeratie als zodanig opgenomen bij het datatype, de documentatie wordt hierbij ook getoond. De naam van de codelijst komt niet terug in het xsd.",
"type":"Tekenvorm"
}
]
}
,
"190197" : {
"id":190197,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Berichtklasse root bevat informatie over het bericht: * titel * berichtcode De berichtcode wordt gebruikt om in het xsd het element BerichtCode te voorzien van een pattern value restrictie.  Daarnaast ook: Naam retourbericht en Code retourbericht: Als deze gevuld zijn, wordt bij genereren xsd automatisch een retourbericht xsd gegenereerd.   Domeinoverstijgende koppelingen op het bericht worden gekoppeld aan Berichtklasse root: * Bestanden (Dataobjecten) uit de processen * Bedrijfsregels (Requirements)",
"type":"Tekenvorm"
}
]
}
,
"190210" : {
"id":190210,
"typeIconPath":"data/icons/ArchiMate/BusinessProcess.png",
"data" : [
{
"name":"Bedrijfsproces",
"type":"Bedrijfsproces"
}
]
}
,
"190212" : {
"id":190212,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Opmaak proces platen: Om de processen 'verkleind' weer te geven, met een link naar de details: kies na rechter muisklik \"inklappen\". Daarna kan het formaat worden aangepast tot de gewenste grootte.  Binnen de detailplaten zijn de relaties met de processtappen/triggers buiten het ingeklapte stuk niet meer zichtbaar. Om inzichtelijk te maken dat de lijn \"van buiten\" komt, kan op de rand van de detailplaat een Verbinding worden geplaatst. Vanuit deze verbinding kan de triggeringsrelatie getrokken worden. Een Verbinding wordt standaard getoond als een bolletje. Om hiervan een driehoek te maken: kies \"Grafische vorm wijzigen\" na rechtermuisklik en kies voor de Triangle-right-icon (of -up- etc. afhankelijk van de locatie.",
"type":"Tekenvorm"
}
]
}
,
"190213" : {
"id":190213,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Processen worden gemodelleerd binnen de ArchiMate bedrijfslaag. We gebruiken hierin processen, processtappen, events (triggers) en bedrijfsrollen. De bedrijfsrol geeft aan wie de uitvoerder van een proces of processtap is. De rol wordt met een toekenningsrelatie gekoppeld aan het betreffende procesonderdeel.  De bedrijfsrollen worden beheerd in Processen generiek. Iedere bedrijfsrol heeft zijn eigen kleur. Deze wordt toegekend binnen de view \"Kleurenview rollen\" in Processen generiek. Bij het uitvoeren van het viewpoint \"Rollen bij processen en casuistiek\" wordt de kleur overgenomen vanuit de \"Kleurenview rollen\" view.  Viewpoints voor de kleurenview en labelview bij de processen en casussen moeten in ieder model (Processen Wlz etc) apart worden opgenomen om in de InSight rapportage de view te kunnen gebruiken.   Binnen de processen worden de berichten uitgewisseld. Een bericht (bestand) is gemodelleerd als een dataobject uit de applicatielaag. Het bestand is met een toegangsrelatie gekoppeld aan de processtap. De richting van de pijl geeft aan of het bestand gecreeerd wordt (type = schrijf) of wordt ingelezen (type = lees). Type schrijf/lees kan gekozen worden in de eigenschappen (properties) van de toegangsrelatie.  De link naar de UML-view van het bericht wordt gelegd door ieder bestand met een modeloverstijgende associatie te koppelen aan de betreffende bericht klassenview.  De link naar de bedrijfsregels wordt gelegd door de relevante bedrijfsregels met een associatierelatie te koppelen aan processen. Om het geheel leesbaar te houden worden bedrijfsregels niet gekoppeld aan een processtap (activiteit) of trigger (event).",
"type":"Tekenvorm"
}
]
}
,
"190222" : {
"id":190222,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Uitgangspunten, bedrijfsregels en technische regels komen in principe voort uit het proces, dat kan het clientproces of het berichtproces zijn.  Uitgangspunten worden gedefinieerd als ArchiMate principes en worden per standaard apart gedefinieerd. Een uitgangspunt wordt gerealiseerd door een of meer bedrijfsregels. Koppeling wordt gelegd door een realisatierelatie.  Bedrijfsregels worden gedefinieerd als ArchiMate requirements. Ze horen bij een proces (via associatierelatie) en/of bij één of meer berichten, via een modeloverstijgende associatie relatie met de berichtklasse root. Op een bedrijfsregel kunnen één of meer uitzonderingen gedefinieerd worden. Dit is een specialisatie van een bedrijfsregel. De uitzondering krijgt dezelfde regelcode als de regel waarop de uitzondering betrekking heeft met toevoeging van \"x\" en een volgnummer (zoals OP033x1). Bedrijfsregels worden indien mogelijk uitgewerkt in technische regels. Bedrijfsregels die niet zijn uitgewerkt in een technische regel kunnen als zodanig gemarkeerd worden in de profielinformatie (hier doen we op dit moment niks mee).  Technische regels worden gedefinieerd als ArchiMate beperkingen, met als profiel \"Technische regel\". Ze vormen de technische controleerbare vertaling van een bedrijfsregel. Iedere technische regel is dus ook gekoppeld aan (minstens) een bedrijfsregeleen associatie relatie. Let op: dit is een 'normale' associatierelatie, géén modeloverstijgende. Technische regels zijn van toepassing op een berichtklasse of een berichtelement via een modeloverstijgende associatierelatie. Bij een techische regels moet in de profielinformatie (\"niveau\") worden aangegeven of deze berichtoverstijgend is of niet (standaard).",
"type":"Tekenvorm"
}
]
}
,
"190215" : {
"id":190215,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"UML objecten",
"type":"Tekenvorm"
}
]
}
,
"190220" : {
"id":190220,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Alle regels worden gedefinieerd binnen de ArchiMate laag \"Motivatie\". Regels worden met modeloverstijgende associatierelaties gekoppeld aan het 'gegevensstuk' (in UML). Dit gebeurt op een zo laag mogelijk niveau: indien overal dezelfde beperking geldt aan het datatype, anders aan berichtelement of -klasse.  In het model wordt voor iedere standaard een AchiMate model gemaakt met daarin per regelsoort een 'motivatielaag' met de regels. Daarnaast is er een model 'Generieke regels' met regels die in iedere standaard terugkomen. Bij een generieke regel is evt. mogelijk om per standaard een specialisatie te maken, bijv. wanneer een andere retourcode van toepassing is. In de publicatielaag (inSite) worden tabellen gemaakt per standaard; deze tabellen worden gevuld op basis van de regels die binnen één of meer 'motivatielagen' zijn opgenomen. Welke lagen getoond moeten worden is per tabel in te stellen.  Regels krijgen als titel: \"Code: Beknopte omschrijving.\" Uitgebreidere omschrijving en verdere uitleg kan in de documentatie worden opgenomen. In de profielinformatie moet (handmatig!) de code van de regel ingevuld worden.",
"type":"Tekenvorm"
}
]
}
,
"190223" : {
"id":190223,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Condities, constraints en invulinstructies zijn beperkingen of aanwijzingen op de gegevens die gevuld moeten of mogen worden.  Condities worden gedefinieerd als ArchiMate beperkingen, met als profiel \"Conditie\". Condities worden gekoppeld aan een berichtelement of aan een attribuut binnen een composite datatype. Op dit moment worden condities alleen gekoppeld aan het element dat daadwerkelijk beperkt wordt, niet aan het element op basis waarvan de beperking geldig is.  Constraints worden gedefinieerd als ArchiMate beperkingen, met als profiel \"Constraint\". Constraints worden gekoppeld aan een berichtelement of aan een attribuut binnen een composite datatype. Een constraint kan ook gekoppeld worden aan een datatype, hoewel dan een xsd restrictie meer voor de hand ligt.  Een xsd restrictie is een specialisatie van een constraint en daarmee ook een Archimate beperking met profiel \"constraint\". Xsd restricties worden altijd vertaald als een restrictie op een datatype in het xsd. Deze worden altijd gekoppeld aan een logisch datatype.  Invulinstructies worden gekoppeld aan een berichtelement of aan berichtklasse root (alleen voor Retourbericht invulinstructie)",
"type":"Tekenvorm"
}
]
}
,
"190227" : {
"id":190227,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD065: Als type verwijzer is gelijk aan 02,03,04 of 05 en NaamVerwijzer is leeg, dan verplicht vullen, anders leeg laten.",
"type":"Beperking"
}
]
}
,
"190218" : {
"id":190218,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"\"proces\" regels",
"type":"Tekenvorm"
}
]
}
,
"190224" : {
"id":190224,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"\"data\" regels",
"type":"Tekenvorm"
}
]
}
,
"190226" : {
"id":190226,
"typeIconPath":"data/icons/ArchiMate/MotivationConstraint.png",
"data" : [
{
"name":"CD064: Als type verwijzer is gelijk aan 02,03,04 of 05 en ZorgverlenerCode is leeg, dan verplicht vullen, anders leeg laten.",
"type":"Beperking"
}
]
}
,
"190115" : {
"id":190115,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Binnen iStandaarden wordt ieder verzonden heenbericht beantwoord met een retourbericht. De specificaties van de retourberichten zijn gelijk aan de specificaties van de bijbehorende heenberichten. Daarop worden de volgende wijzigingen en aanvullingen doorgevoerd:  1. Header:   - In de header wordt de BerichtCode gevuld met de berichtcode van het betreffende retourbericht.   - De elementen Afzender en Ontvanger worden ongewijzigd overgenomen van de header van het heenbestand.   - De header wordt aangevuld met identificerende gegevens van het retourbestand (IdentificatieRetour en DagtekeningRetour).  2. Berichtklassen:   - De berichtklassen zijn optioneel binnen het retourbericht; een retourbericht kan ook alleen een header bevatten.   - Alle berichtklassen, inclusief de header, worden uitgebreid met een berichtklasse RetourCodes.    - Berichtklasse RetourCodes is optioneel voor de header, voor alle overige berichtklassen moet RetourCodes verplicht worden opgenomen.",
"type":"Tekenvorm"
}
]
}
,
"190117" : {
"id":190117,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Retourbericht iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"189901" : {
"id":189901,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189911" : {
"id":189911,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189906" : {
"id":189906,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189914" : {
"id":189914,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189919" : {
"id":189919,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189916" : {
"id":189916,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189920" : {
"id":189920,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189928" : {
"id":189928,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189925" : {
"id":189925,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189923" : {
"id":189923,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189940" : {
"id":189940,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189933" : {
"id":189933,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189936" : {
"id":189936,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189937" : {
"id":189937,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"189879" : {
"id":189879,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"188134" : {
"id":188134,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188138" : {
"id":188138,
"typeIconPath":"data/icons/ArchiMate/CommandFolder.png",
"data" : [
{
"name":"Viewpoints",
"type":"Viewpoints"
}
]
}
,
"188118" : {
"id":188118,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188137" : {
"id":188137,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188119" : {
"id":188119,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188128" : {
"id":188128,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188160" : {
"id":188160,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188148" : {
"id":188148,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188165" : {
"id":188165,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188166" : {
"id":188166,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188140" : {
"id":188140,
"typeIconPath":"data/icons/ArchiMate/CommandFolder.png",
"data" : [
{
"name":"Viewpoints",
"type":"Viewpoints"
}
]
}
,
"188157" : {
"id":188157,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188154" : {
"id":188154,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188181" : {
"id":188181,
"typeIconPath":"data/icons/ArchiMate/CommandFolder.png",
"data" : [
{
"name":"Viewpoints",
"type":"Viewpoints"
}
]
}
,
"188188" : {
"id":188188,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188170" : {
"id":188170,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188177" : {
"id":188177,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188169" : {
"id":188169,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188178" : {
"id":188178,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188174" : {
"id":188174,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188173" : {
"id":188173,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188183" : {
"id":188183,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188186" : {
"id":188186,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188234" : {
"id":188234,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188205" : {
"id":188205,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188208" : {
"id":188208,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188221" : {
"id":188221,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188214" : {
"id":188214,
"typeIconPath":"data/icons/ArchiMate/CommandFolder.png",
"data" : [
{
"name":"Viewpoints",
"type":"Viewpoints"
}
]
}
,
"188215" : {
"id":188215,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188223" : {
"id":188223,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188227" : {
"id":188227,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188218" : {
"id":188218,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188230" : {
"id":188230,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188224" : {
"id":188224,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188211" : {
"id":188211,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188232" : {
"id":188232,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188268" : {
"id":188268,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188271" : {
"id":188271,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188240" : {
"id":188240,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188247" : {
"id":188247,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188274" : {
"id":188274,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188235" : {
"id":188235,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188244" : {
"id":188244,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188248" : {
"id":188248,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188275" : {
"id":188275,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188276" : {
"id":188276,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"188316" : {
"id":188316,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188303" : {
"id":188303,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188312" : {
"id":188312,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188279" : {
"id":188279,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188290" : {
"id":188290,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188278" : {
"id":188278,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188364" : {
"id":188364,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188359" : {
"id":188359,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188325" : {
"id":188325,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188329" : {
"id":188329,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188351" : {
"id":188351,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188333" : {
"id":188333,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188353" : {
"id":188353,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188320" : {
"id":188320,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188379" : {
"id":188379,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188370" : {
"id":188370,
"typeIconPath":"data/icons/BPMN/BPMN_ItemScheme.png",
"data" : [
{
"name":"iWvGGZ-berichten",
"type":"Items"
}
]
}
,
"188382" : {
"id":188382,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188402" : {
"id":188402,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188381" : {
"id":188381,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188391" : {
"id":188391,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188393" : {
"id":188393,
"typeIconPath":"data/icons/BPMN/BPMN_ItemScheme.png",
"data" : [
{
"name":"iWvGGZ-berichten",
"type":"Items"
}
]
}
,
"188426" : {
"id":188426,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188449" : {
"id":188449,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188437" : {
"id":188437,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188429" : {
"id":188429,
"typeIconPath":"data/icons/BPMN/BPMN_ItemScheme.png",
"data" : [
{
"name":"iWvGGZ-berichten",
"type":"Items"
}
]
}
,
"188445" : {
"id":188445,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188487" : {
"id":188487,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188474" : {
"id":188474,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188473" : {
"id":188473,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188464" : {
"id":188464,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188484" : {
"id":188484,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188480" : {
"id":188480,
"typeIconPath":"data/icons/BPMN/BPMN_ItemScheme.png",
"data" : [
{
"name":"iWvGGZ-berichten",
"type":"Items"
}
]
}
,
"188514" : {
"id":188514,
"typeIconPath":"data/icons/BPMN/BPMN_ItemScheme.png",
"data" : [
{
"name":"iWvGGZ-berichten",
"type":"Items"
}
]
}
,
"188536" : {
"id":188536,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188545" : {
"id":188545,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188524" : {
"id":188524,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188509" : {
"id":188509,
"typeIconPath":"data/icons/BPMN/BPMN_ItemScheme.png",
"data" : [
{
"name":"iWvGGZ-berichten",
"type":"Items"
}
]
}
,
"188517" : {
"id":188517,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188531" : {
"id":188531,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"188518" : {
"id":188518,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"187927" : {
"id":187927,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187936" : {
"id":187936,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatie over zorg en ondersteuning wordt uitgewisseld in de vorm van gestandaardiseerde berichten. De berichtspecificaties zijn per iStandaard beschreven.  Onderstaande tabel toont een overzicht van de berichten die vallen onder de iStandaarden.",
"type":"Tekenvorm"
}
]
}
,
"187951" : {
"id":187951,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187952" : {
"id":187952,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187926" : {
"id":187926,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187950" : {
"id":187950,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187953" : {
"id":187953,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187924" : {
"id":187924,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187923" : {
"id":187923,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187937" : {
"id":187937,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187933" : {
"id":187933,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatiemodel iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"187928" : {
"id":187928,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187942" : {
"id":187942,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187944" : {
"id":187944,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187947" : {
"id":187947,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187925" : {
"id":187925,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187932" : {
"id":187932,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Versie informatiemodel:  0.1  Publicatiedatum: 01-09-2020",
"type":"Tekenvorm"
}
]
}
,
"187935" : {
"id":187935,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Over iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"187941" : {
"id":187941,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Overzicht Berichten iWvggz",
"type":"Tekenvorm"
}
]
}
,
"187921" : {
"id":187921,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Over iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"187946" : {
"id":187946,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"188580" : {
"id":188580,
"typeIconPath":"data/icons/BPMN/AbstractFolder.png",
"data" : [
{
"name":"Map",
"type":"Map"
}
]
}
,
"187957" : {
"id":187957,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187956" : {
"id":187956,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187954" : {
"id":187954,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190673" : {
"id":190673,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8028",
"type":"Enumeratiewaarde"
}
]
}
,
"190659" : {
"id":190659,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190662" : {
"id":190662,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190672" : {
"id":190672,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8269",
"type":"Enumeratiewaarde"
}
]
}
,
"190677" : {
"id":190677,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9092",
"type":"Enumeratiewaarde"
}
]
}
,
"190657" : {
"id":190657,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190681" : {
"id":190681,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8178",
"type":"Enumeratiewaarde"
}
]
}
,
"190675" : {
"id":190675,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0451",
"type":"Enumeratiewaarde"
}
]
}
,
"190670" : {
"id":190670,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"16",
"type":"Enumeratiewaarde"
}
]
}
,
"190668" : {
"id":190668,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D016",
"type":"Enumeratiewaarde"
}
]
}
,
"190667" : {
"id":190667,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190678" : {
"id":190678,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8185",
"type":"Enumeratiewaarde"
}
]
}
,
"190679" : {
"id":190679,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0760",
"type":"Enumeratiewaarde"
}
]
}
,
"190665" : {
"id":190665,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190674" : {
"id":190674,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"14",
"type":"Enumeratiewaarde"
}
]
}
,
"190682" : {
"id":190682,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"397",
"type":"Enumeratiewaarde"
}
]
}
,
"190690" : {
"id":190690,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0100",
"type":"Enumeratiewaarde"
}
]
}
,
"190692" : {
"id":190692,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"04",
"type":"Enumeratiewaarde"
}
]
}
,
"190684" : {
"id":190684,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D043",
"type":"Enumeratiewaarde"
}
]
}
,
"190695" : {
"id":190695,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"82",
"type":"Enumeratiewaarde"
}
]
}
,
"190694" : {
"id":190694,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"81",
"type":"Enumeratiewaarde"
}
]
}
,
"190696" : {
"id":190696,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"08",
"type":"Enumeratiewaarde"
}
]
}
,
"190699" : {
"id":190699,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD165: Soort toewijzing - Vervallen codes",
"type":"Enumeratie"
}
]
}
,
"190701" : {
"id":190701,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S065",
"type":"Enumeratiewaarde"
}
]
}
,
"190685" : {
"id":190685,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD218: Tijdseenheid Zorgperiode - Vervallen",
"type":"Enumeratie"
}
]
}
,
"190702" : {
"id":190702,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8188",
"type":"Enumeratiewaarde"
}
]
}
,
"190688" : {
"id":190688,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"355",
"type":"Enumeratiewaarde"
}
]
}
,
"190686" : {
"id":190686,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1113",
"type":"Enumeratiewaarde"
}
]
}
,
"190689" : {
"id":190689,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9085",
"type":"Enumeratiewaarde"
}
]
}
,
"190703" : {
"id":190703,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"190687" : {
"id":190687,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8839",
"type":"Enumeratiewaarde"
}
]
}
,
"190693" : {
"id":190693,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"21",
"type":"Enumeratiewaarde"
}
]
}
,
"190704" : {
"id":190704,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4",
"type":"Enumeratiewaarde"
}
]
}
,
"190698" : {
"id":190698,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S057",
"type":"Enumeratiewaarde"
}
]
}
,
"190705" : {
"id":190705,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8850",
"type":"Enumeratiewaarde"
}
]
}
,
"190691" : {
"id":190691,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"190711" : {
"id":190711,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WMO588: Reden beeindiging - Vervallen codes",
"type":"Enumeratie"
}
]
}
,
"190714" : {
"id":190714,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"33",
"type":"Enumeratiewaarde"
}
]
}
,
"190719" : {
"id":190719,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0018",
"type":"Enumeratiewaarde"
}
]
}
,
"190722" : {
"id":190722,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9061",
"type":"Enumeratiewaarde"
}
]
}
,
"190706" : {
"id":190706,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1110",
"type":"Enumeratiewaarde"
}
]
}
,
"190707" : {
"id":190707,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1230",
"type":"Enumeratiewaarde"
}
]
}
,
"190715" : {
"id":190715,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"34",
"type":"Enumeratiewaarde"
}
]
}
,
"190720" : {
"id":190720,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2910",
"type":"Enumeratiewaarde"
}
]
}
,
"190724" : {
"id":190724,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD999: Voorkeur client - Vervallen codes",
"type":"Enumeratie"
}
]
}
,
"190716" : {
"id":190716,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8193",
"type":"Enumeratiewaarde"
}
]
}
,
"190726" : {
"id":190726,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9016",
"type":"Enumeratiewaarde"
}
]
}
,
"190723" : {
"id":190723,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8222",
"type":"Enumeratiewaarde"
}
]
}
,
"190718" : {
"id":190718,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"450",
"type":"Enumeratiewaarde"
}
]
}
,
"190709" : {
"id":190709,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"32",
"type":"Enumeratiewaarde"
}
]
}
,
"190721" : {
"id":190721,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S002",
"type":"Enumeratiewaarde"
}
]
}
,
"190713" : {
"id":190713,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8183",
"type":"Enumeratiewaarde"
}
]
}
,
"190708" : {
"id":190708,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S118",
"type":"Enumeratiewaarde"
}
]
}
,
"190712" : {
"id":190712,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0960",
"type":"Enumeratiewaarde"
}
]
}
,
"190717" : {
"id":190717,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1079",
"type":"Enumeratiewaarde"
}
]
}
,
"190727" : {
"id":190727,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1000",
"type":"Enumeratiewaarde"
}
]
}
,
"190744" : {
"id":190744,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8064",
"type":"Enumeratiewaarde"
}
]
}
,
"190730" : {
"id":190730,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0659",
"type":"Enumeratiewaarde"
}
]
}
,
"190749" : {
"id":190749,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8184",
"type":"Enumeratiewaarde"
}
]
}
,
"190736" : {
"id":190736,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WJ001: Retourcode - Vervallen codes",
"type":"Enumeratie"
}
]
}
,
"190751" : {
"id":190751,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8194",
"type":"Enumeratiewaarde"
}
]
}
,
"190753" : {
"id":190753,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8215",
"type":"Enumeratiewaarde"
}
]
}
,
"190752" : {
"id":190752,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8207",
"type":"Enumeratiewaarde"
}
]
}
,
"190755" : {
"id":190755,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8376",
"type":"Enumeratiewaarde"
}
]
}
,
"190746" : {
"id":190746,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8171",
"type":"Enumeratiewaarde"
}
]
}
,
"190757" : {
"id":190757,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8455",
"type":"Enumeratiewaarde"
}
]
}
,
"190759" : {
"id":190759,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8835",
"type":"Enumeratiewaarde"
}
]
}
,
"190761" : {
"id":190761,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8851",
"type":"Enumeratiewaarde"
}
]
}
,
"190765" : {
"id":190765,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9014",
"type":"Enumeratiewaarde"
}
]
}
,
"190737" : {
"id":190737,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0150",
"type":"Enumeratiewaarde"
}
]
}
,
"190750" : {
"id":190750,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8186",
"type":"Enumeratiewaarde"
}
]
}
,
"190762" : {
"id":190762,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9001",
"type":"Enumeratiewaarde"
}
]
}
,
"190766" : {
"id":190766,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9015",
"type":"Enumeratiewaarde"
}
]
}
,
"190728" : {
"id":190728,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8198",
"type":"Enumeratiewaarde"
}
]
}
,
"190748" : {
"id":190748,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8182",
"type":"Enumeratiewaarde"
}
]
}
,
"190763" : {
"id":190763,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9002",
"type":"Enumeratiewaarde"
}
]
}
,
"190767" : {
"id":190767,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9017",
"type":"Enumeratiewaarde"
}
]
}
,
"190768" : {
"id":190768,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9018",
"type":"Enumeratiewaarde"
}
]
}
,
"190769" : {
"id":190769,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9020",
"type":"Enumeratiewaarde"
}
]
}
,
"190770" : {
"id":190770,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9021",
"type":"Enumeratiewaarde"
}
]
}
,
"190771" : {
"id":190771,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9037",
"type":"Enumeratiewaarde"
}
]
}
,
"190772" : {
"id":190772,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9039",
"type":"Enumeratiewaarde"
}
]
}
,
"190764" : {
"id":190764,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9006",
"type":"Enumeratiewaarde"
}
]
}
,
"190742" : {
"id":190742,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8061",
"type":"Enumeratiewaarde"
}
]
}
,
"190740" : {
"id":190740,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0582",
"type":"Enumeratiewaarde"
}
]
}
,
"190733" : {
"id":190733,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8177",
"type":"Enumeratiewaarde"
}
]
}
,
"190731" : {
"id":190731,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D018",
"type":"Enumeratiewaarde"
}
]
}
,
"190735" : {
"id":190735,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"432",
"type":"Enumeratiewaarde"
}
]
}
,
"190738" : {
"id":190738,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0383",
"type":"Enumeratiewaarde"
}
]
}
,
"190734" : {
"id":190734,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8175",
"type":"Enumeratiewaarde"
}
]
}
,
"190745" : {
"id":190745,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8166",
"type":"Enumeratiewaarde"
}
]
}
,
"190747" : {
"id":190747,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8181",
"type":"Enumeratiewaarde"
}
]
}
,
"190754" : {
"id":190754,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8223",
"type":"Enumeratiewaarde"
}
]
}
,
"190743" : {
"id":190743,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8062",
"type":"Enumeratiewaarde"
}
]
}
,
"190741" : {
"id":190741,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8002",
"type":"Enumeratiewaarde"
}
]
}
,
"190739" : {
"id":190739,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0435",
"type":"Enumeratiewaarde"
}
]
}
,
"190729" : {
"id":190729,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"190756" : {
"id":190756,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8454",
"type":"Enumeratiewaarde"
}
]
}
,
"190758" : {
"id":190758,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8456",
"type":"Enumeratiewaarde"
}
]
}
,
"190732" : {
"id":190732,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"392",
"type":"Enumeratiewaarde"
}
]
}
,
"190760" : {
"id":190760,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8837",
"type":"Enumeratiewaarde"
}
]
}
,
"190777" : {
"id":190777,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9052",
"type":"Enumeratiewaarde"
}
]
}
,
"190796" : {
"id":190796,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D022",
"type":"Enumeratiewaarde"
}
]
}
,
"190804" : {
"id":190804,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D040",
"type":"Enumeratiewaarde"
}
]
}
,
"190774" : {
"id":190774,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9041",
"type":"Enumeratiewaarde"
}
]
}
,
"190808" : {
"id":190808,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D044",
"type":"Enumeratiewaarde"
}
]
}
,
"190812" : {
"id":190812,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D048",
"type":"Enumeratiewaarde"
}
]
}
,
"190811" : {
"id":190811,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D047",
"type":"Enumeratiewaarde"
}
]
}
,
"190791" : {
"id":190791,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D005",
"type":"Enumeratiewaarde"
}
]
}
,
"190785" : {
"id":190785,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9086",
"type":"Enumeratiewaarde"
}
]
}
,
"190783" : {
"id":190783,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9078",
"type":"Enumeratiewaarde"
}
]
}
,
"190795" : {
"id":190795,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D020",
"type":"Enumeratiewaarde"
}
]
}
,
"190786" : {
"id":190786,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9091",
"type":"Enumeratiewaarde"
}
]
}
,
"190789" : {
"id":190789,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9301",
"type":"Enumeratiewaarde"
}
]
}
,
"190793" : {
"id":190793,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D009",
"type":"Enumeratiewaarde"
}
]
}
,
"190803" : {
"id":190803,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D039",
"type":"Enumeratiewaarde"
}
]
}
,
"190815" : {
"id":190815,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S014",
"type":"Enumeratiewaarde"
}
]
}
,
"190778" : {
"id":190778,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9064",
"type":"Enumeratiewaarde"
}
]
}
,
"190792" : {
"id":190792,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D007",
"type":"Enumeratiewaarde"
}
]
}
,
"190810" : {
"id":190810,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D046",
"type":"Enumeratiewaarde"
}
]
}
,
"190817" : {
"id":190817,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S035",
"type":"Enumeratiewaarde"
}
]
}
,
"190799" : {
"id":190799,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D029",
"type":"Enumeratiewaarde"
}
]
}
,
"190784" : {
"id":190784,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9085",
"type":"Enumeratiewaarde"
}
]
}
,
"190790" : {
"id":190790,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D004",
"type":"Enumeratiewaarde"
}
]
}
,
"190780" : {
"id":190780,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9066",
"type":"Enumeratiewaarde"
}
]
}
,
"190782" : {
"id":190782,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9073",
"type":"Enumeratiewaarde"
}
]
}
,
"190819" : {
"id":190819,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S050",
"type":"Enumeratiewaarde"
}
]
}
,
"190820" : {
"id":190820,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S057",
"type":"Enumeratiewaarde"
}
]
}
,
"190821" : {
"id":190821,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S058",
"type":"Enumeratiewaarde"
}
]
}
,
"190775" : {
"id":190775,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9042",
"type":"Enumeratiewaarde"
}
]
}
,
"190822" : {
"id":190822,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S062",
"type":"Enumeratiewaarde"
}
]
}
,
"190800" : {
"id":190800,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D034",
"type":"Enumeratiewaarde"
}
]
}
,
"190781" : {
"id":190781,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9070",
"type":"Enumeratiewaarde"
}
]
}
,
"190806" : {
"id":190806,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D042",
"type":"Enumeratiewaarde"
}
]
}
,
"190818" : {
"id":190818,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S049",
"type":"Enumeratiewaarde"
}
]
}
,
"190823" : {
"id":190823,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S064",
"type":"Enumeratiewaarde"
}
]
}
,
"190824" : {
"id":190824,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S065",
"type":"Enumeratiewaarde"
}
]
}
,
"190826" : {
"id":190826,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S069",
"type":"Enumeratiewaarde"
}
]
}
,
"190828" : {
"id":190828,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S072",
"type":"Enumeratiewaarde"
}
]
}
,
"190831" : {
"id":190831,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S086",
"type":"Enumeratiewaarde"
}
]
}
,
"190832" : {
"id":190832,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S088",
"type":"Enumeratiewaarde"
}
]
}
,
"190834" : {
"id":190834,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S092",
"type":"Enumeratiewaarde"
}
]
}
,
"190835" : {
"id":190835,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S093",
"type":"Enumeratiewaarde"
}
]
}
,
"190802" : {
"id":190802,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D038",
"type":"Enumeratiewaarde"
}
]
}
,
"190814" : {
"id":190814,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S012",
"type":"Enumeratiewaarde"
}
]
}
,
"190816" : {
"id":190816,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S023",
"type":"Enumeratiewaarde"
}
]
}
,
"190836" : {
"id":190836,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S107",
"type":"Enumeratiewaarde"
}
]
}
,
"190776" : {
"id":190776,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9046",
"type":"Enumeratiewaarde"
}
]
}
,
"190825" : {
"id":190825,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S067",
"type":"Enumeratiewaarde"
}
]
}
,
"190809" : {
"id":190809,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D045",
"type":"Enumeratiewaarde"
}
]
}
,
"190773" : {
"id":190773,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9040",
"type":"Enumeratiewaarde"
}
]
}
,
"190813" : {
"id":190813,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S003",
"type":"Enumeratiewaarde"
}
]
}
,
"190830" : {
"id":190830,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S074",
"type":"Enumeratiewaarde"
}
]
}
,
"190829" : {
"id":190829,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S073",
"type":"Enumeratiewaarde"
}
]
}
,
"190787" : {
"id":190787,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9097",
"type":"Enumeratiewaarde"
}
]
}
,
"190788" : {
"id":190788,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9101",
"type":"Enumeratiewaarde"
}
]
}
,
"190807" : {
"id":190807,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D043",
"type":"Enumeratiewaarde"
}
]
}
,
"190801" : {
"id":190801,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D036",
"type":"Enumeratiewaarde"
}
]
}
,
"190827" : {
"id":190827,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S071",
"type":"Enumeratiewaarde"
}
]
}
,
"190805" : {
"id":190805,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D041",
"type":"Enumeratiewaarde"
}
]
}
,
"190833" : {
"id":190833,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S089",
"type":"Enumeratiewaarde"
}
]
}
,
"190794" : {
"id":190794,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D017",
"type":"Enumeratiewaarde"
}
]
}
,
"190798" : {
"id":190798,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D025",
"type":"Enumeratiewaarde"
}
]
}
,
"190779" : {
"id":190779,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9065",
"type":"Enumeratiewaarde"
}
]
}
,
"190797" : {
"id":190797,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D023",
"type":"Enumeratiewaarde"
}
]
}
,
"190852" : {
"id":190852,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"446",
"type":"Enumeratiewaarde"
}
]
}
,
"190853" : {
"id":190853,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0300",
"type":"Enumeratiewaarde"
}
]
}
,
"190851" : {
"id":190851,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1300",
"type":"Enumeratiewaarde"
}
]
}
,
"190844" : {
"id":190844,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S121",
"type":"Enumeratiewaarde"
}
]
}
,
"190849" : {
"id":190849,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"8817",
"type":"Enumeratiewaarde"
}
]
}
,
"190841" : {
"id":190841,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S115",
"type":"Enumeratiewaarde"
}
]
}
,
"190847" : {
"id":190847,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S317",
"type":"Enumeratiewaarde"
}
]
}
,
"190838" : {
"id":190838,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S112",
"type":"Enumeratiewaarde"
}
]
}
,
"190843" : {
"id":190843,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S120",
"type":"Enumeratiewaarde"
}
]
}
,
"190854" : {
"id":190854,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"D053",
"type":"Enumeratiewaarde"
}
]
}
,
"190842" : {
"id":190842,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S119",
"type":"Enumeratiewaarde"
}
]
}
,
"190855" : {
"id":190855,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"190845" : {
"id":190845,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S122",
"type":"Enumeratiewaarde"
}
]
}
,
"190846" : {
"id":190846,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S123",
"type":"Enumeratiewaarde"
}
]
}
,
"190837" : {
"id":190837,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S108",
"type":"Enumeratiewaarde"
}
]
}
,
"190848" : {
"id":190848,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S318",
"type":"Enumeratiewaarde"
}
]
}
,
"190840" : {
"id":190840,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S114",
"type":"Enumeratiewaarde"
}
]
}
,
"190850" : {
"id":190850,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0940",
"type":"Enumeratiewaarde"
}
]
}
,
"190839" : {
"id":190839,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S113",
"type":"Enumeratiewaarde"
}
]
}
,
"190863" : {
"id":190863,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0309",
"type":"Enumeratiewaarde"
}
]
}
,
"190861" : {
"id":190861,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1060",
"type":"Enumeratiewaarde"
}
]
}
,
"190865" : {
"id":190865,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1800",
"type":"Enumeratiewaarde"
}
]
}
,
"190857" : {
"id":190857,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0410",
"type":"Enumeratiewaarde"
}
]
}
,
"190864" : {
"id":190864,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2610",
"type":"Enumeratiewaarde"
}
]
}
,
"190860" : {
"id":190860,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"388",
"type":"Enumeratiewaarde"
}
]
}
,
"190862" : {
"id":190862,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"358",
"type":"Enumeratiewaarde"
}
]
}
,
"190858" : {
"id":190858,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"4761",
"type":"Enumeratiewaarde"
}
]
}
,
"190859" : {
"id":190859,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"3",
"type":"Enumeratiewaarde"
}
]
}
,
"190874" : {
"id":190874,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1061",
"type":"Enumeratiewaarde"
}
]
}
,
"190875" : {
"id":190875,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1207",
"type":"Enumeratiewaarde"
}
]
}
,
"190869" : {
"id":190869,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"S049",
"type":"Enumeratiewaarde"
}
]
}
,
"190868" : {
"id":190868,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0802",
"type":"Enumeratiewaarde"
}
]
}
,
"190867" : {
"id":190867,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1076",
"type":"Enumeratiewaarde"
}
]
}
,
"190871" : {
"id":190871,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1192",
"type":"Enumeratiewaarde"
}
]
}
,
"190866" : {
"id":190866,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0130",
"type":"Enumeratiewaarde"
}
]
}
,
"190870" : {
"id":190870,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"9102",
"type":"Enumeratiewaarde"
}
]
}
,
"190872" : {
"id":190872,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"190887" : {
"id":190887,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"433",
"type":"Enumeratiewaarde"
}
]
}
,
"190889" : {
"id":190889,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"435",
"type":"Enumeratiewaarde"
}
]
}
,
"190892" : {
"id":190892,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"438",
"type":"Enumeratiewaarde"
}
]
}
,
"190876" : {
"id":190876,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"389",
"type":"Enumeratiewaarde"
}
]
}
,
"190880" : {
"id":190880,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"1",
"type":"Enumeratiewaarde"
}
]
}
,
"190884" : {
"id":190884,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"395",
"type":"Enumeratiewaarde"
}
]
}
,
"190897" : {
"id":190897,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"451",
"type":"Enumeratiewaarde"
}
]
}
,
"190898" : {
"id":190898,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"414",
"type":"Enumeratiewaarde"
}
]
}
,
"190899" : {
"id":190899,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"415",
"type":"Enumeratiewaarde"
}
]
}
,
"190901" : {
"id":190901,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"417",
"type":"Enumeratiewaarde"
}
]
}
,
"190902" : {
"id":190902,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"418",
"type":"Enumeratiewaarde"
}
]
}
,
"190904" : {
"id":190904,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"420",
"type":"Enumeratiewaarde"
}
]
}
,
"190905" : {
"id":190905,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"421",
"type":"Enumeratiewaarde"
}
]
}
,
"190883" : {
"id":190883,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2300",
"type":"Enumeratiewaarde"
}
]
}
,
"190885" : {
"id":190885,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"0110",
"type":"Enumeratiewaarde"
}
]
}
,
"190882" : {
"id":190882,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD910: Retourcode - Vervallen codes",
"type":"Enumeratie"
}
]
}
,
"190890" : {
"id":190890,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"436",
"type":"Enumeratiewaarde"
}
]
}
,
"190895" : {
"id":190895,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"441",
"type":"Enumeratiewaarde"
}
]
}
,
"190900" : {
"id":190900,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"416",
"type":"Enumeratiewaarde"
}
]
}
,
"190877" : {
"id":190877,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"449",
"type":"Enumeratiewaarde"
}
]
}
,
"190903" : {
"id":190903,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"419",
"type":"Enumeratiewaarde"
}
]
}
,
"190888" : {
"id":190888,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"434",
"type":"Enumeratiewaarde"
}
]
}
,
"190894" : {
"id":190894,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"440",
"type":"Enumeratiewaarde"
}
]
}
,
"190881" : {
"id":190881,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"2",
"type":"Enumeratiewaarde"
}
]
}
,
"190891" : {
"id":190891,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"437",
"type":"Enumeratiewaarde"
}
]
}
,
"190896" : {
"id":190896,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"447",
"type":"Enumeratiewaarde"
}
]
}
,
"190893" : {
"id":190893,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"439",
"type":"Enumeratiewaarde"
}
]
}
,
"190879" : {
"id":190879,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD841: Indicatie client overleden - Vervallen",
"type":"Enumeratie"
}
]
}
,
"190886" : {
"id":190886,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"COD002: Bericht - Vervallen",
"type":"Enumeratie"
}
]
}
,
"190646" : {
"id":190646,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190655" : {
"id":190655,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190645" : {
"id":190645,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190649" : {
"id":190649,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"190652" : {
"id":190652,
"typeIconPath":"data/icons/UML/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187874" : {
"id":187874,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Totaaloverzicht Gegevens",
"type":"Tekenvorm"
}
]
}
,
"187881" : {
"id":187881,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Gegevensmodel iWvggz",
"type":"Tekenvorm"
}
]
}
,
"187883" : {
"id":187883,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187870" : {
"id":187870,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187878" : {
"id":187878,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187876" : {
"id":187876,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187862" : {
"id":187862,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187871" : {
"id":187871,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Over iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"187879" : {
"id":187879,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187884" : {
"id":187884,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187875" : {
"id":187875,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187902" : {
"id":187902,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187889" : {
"id":187889,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"De gegevens vormen de basis van de informatieuitwisseling. Hoe de gegevens die worden uitgewisseld precies moeten worden opgenomen in de berichten is gedefinieerd in de datatypen. Dit kunnen samengestelde, ofwel  composite datatypen zijn of enkelvoudige, ofwel logische datatypen. Bij een datatype wordt ook vastgelegd of, en  zo ja, welke codelijst gebruikt wordt.   Op een datatype kunnen ook beperkingen van toepassing zijn. Naast de constraints zijn dit ook restricties zoals bijvoorbeeld de maximale lengte van een datatype.  Waar mogelijk worden binnen de verschillende wettelijke domeinen gelijke datatypen gebruikt. Waar nodig worden  domeinspecifieke datatypen gedefinieerd.",
"type":"Tekenvorm"
}
]
}
,
"187891" : {
"id":187891,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187893" : {
"id":187893,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Versie informatiemodel:  0.1  Publicatiedatum: 01-09-2020",
"type":"Tekenvorm"
}
]
}
,
"187894" : {
"id":187894,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187888" : {
"id":187888,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187895" : {
"id":187895,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Wat bedoelen we met gegevens?",
"type":"Tekenvorm"
}
]
}
,
"187887" : {
"id":187887,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187905" : {
"id":187905,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187906" : {
"id":187906,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"De processen in het informatiemodel zijn afgeleid uit de deelprocessen in het hoofdprocesmodel iWvggz en de nadere afbakening van de release-thema's. Onderstaande plaat geeft de processen weer die momenteel in de roadmap tot en  met release 3.0 zijn opgenomen.  De huidige iWvggz 1.0 release ondersteunt de gegevensuitwisseling tussen Zorgaanbieders, Openbaar Ministerie, IGJ  en stichting PVP voor: - Primaire processen: ZM voorbereiden (aanvragen en indienen)  en Toezicht houden (gegevens aanleveren) - Ondersteunende processen: Persoonsgegevens betrokkene verstrekken (aan stichting PVP)  Klik op de processen in de plaat voor details over de gegevensuitwisseling.",
"type":"Tekenvorm"
}
]
}
,
"187919" : {
"id":187919,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatiemodel iWvggz",
"type":"Tekenvorm"
}
]
}
,
"187920" : {
"id":187920,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187907" : {
"id":187907,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187911" : {
"id":187911,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187913" : {
"id":187913,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187916" : {
"id":187916,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"192199" : {
"id":192199,
"typeIconPath":"data/icons/ArchiMate/RSThreatEvent.png",
"data" : [
{
"name":"Release: iWmo 3.0.2",
"type":"Bedreigingsevent"
}
]
}
,
"192198" : {
"id":192198,
"typeIconPath":"data/icons/ArchiMate/BusinessScheme.png",
"data" : [
{
"name":"Bedrijfslaag",
"type":"Bedrijfslaag"
}
]
}
,
"187718" : {
"id":187718,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"187721" : {
"id":187721,
"typeIconPath":"data/icons/ArchiMate/QueryScript.png",
"data" : [
{
"name":"Queryscript",
"type":"Queryscript"
}
]
}
,
"187616" : {
"id":187616,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187617" : {
"id":187617,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187560" : {
"id":187560,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187556" : {
"id":187556,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Overzicht Regels iWvggz",
"type":"Tekenvorm"
}
]
}
,
"187574" : {
"id":187574,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Versie informatiemodel:  0.1  Publicatiedatum: 01-09-2020",
"type":"Tekenvorm"
}
]
}
,
"187570" : {
"id":187570,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187603" : {
"id":187603,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"05",
"type":"Enumeratiewaarde"
}
]
}
,
"187590" : {
"id":187590,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"187584" : {
"id":187584,
"typeIconPath":"data/icons/ArchiMate/ViewChart.png",
"data" : [
{
"name":"Grafiek",
"type":"Grafiek"
}
]
}
,
"187592" : {
"id":187592,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"187594" : {
"id":187594,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"01",
"type":"Enumeratiewaarde"
}
]
}
,
"187558" : {
"id":187558,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187578" : {
"id":187578,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187605" : {
"id":187605,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187618" : {
"id":187618,
"typeIconPath":"data/icons/UML/UML_Attribute.png",
"data" : [
{
"name":"Begindatum",
"type":"Attribuut"
}
]
}
,
"187619" : {
"id":187619,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187591" : {
"id":187591,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"187564" : {
"id":187564,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187566" : {
"id":187566,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187589" : {
"id":187589,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"187607" : {
"id":187607,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187610" : {
"id":187610,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187580" : {
"id":187580,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187582" : {
"id":187582,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187568" : {
"id":187568,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187588" : {
"id":187588,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"187597" : {
"id":187597,
"typeIconPath":"data/icons/UML/UML_Enumeration.png",
"data" : [
{
"name":"WVG757: Soort adres",
"type":"Enumeratie"
}
]
}
,
"187599" : {
"id":187599,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"02",
"type":"Enumeratiewaarde"
}
]
}
,
"187611" : {
"id":187611,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187609" : {
"id":187609,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187613" : {
"id":187613,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187562" : {
"id":187562,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187586" : {
"id":187586,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Overzicht regels",
"type":"Tekenvorm"
}
]
}
,
"187601" : {
"id":187601,
"typeIconPath":"data/icons/UML/UML_EnumerationLiteral.png",
"data" : [
{
"name":"03",
"type":"Enumeratiewaarde"
}
]
}
,
"187612" : {
"id":187612,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187587" : {
"id":187587,
"typeIconPath":"data/icons/ArchiMate/ElementElementAssociation.png",
"data" : [
{
"name":"Associatierelatie",
"type":"Associatierelatie"
}
]
}
,
"187614" : {
"id":187614,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187615" : {
"id":187615,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187595" : {
"id":187595,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187576" : {
"id":187576,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187635" : {
"id":187635,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187657" : {
"id":187657,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187665" : {
"id":187665,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187639" : {
"id":187639,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187645" : {
"id":187645,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187634" : {
"id":187634,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187656" : {
"id":187656,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187632" : {
"id":187632,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187633" : {
"id":187633,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187654" : {
"id":187654,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187622" : {
"id":187622,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187641" : {
"id":187641,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187625" : {
"id":187625,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187638" : {
"id":187638,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187626" : {
"id":187626,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187636" : {
"id":187636,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187646" : {
"id":187646,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187628" : {
"id":187628,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187649" : {
"id":187649,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187651" : {
"id":187651,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187643" : {
"id":187643,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187623" : {
"id":187623,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187629" : {
"id":187629,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187630" : {
"id":187630,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187659" : {
"id":187659,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187647" : {
"id":187647,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187640" : {
"id":187640,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187627" : {
"id":187627,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187637" : {
"id":187637,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187644" : {
"id":187644,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187624" : {
"id":187624,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187631" : {
"id":187631,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187648" : {
"id":187648,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187658" : {
"id":187658,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187652" : {
"id":187652,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187621" : {
"id":187621,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187642" : {
"id":187642,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187661" : {
"id":187661,
"typeIconPath":"data/icons/UML/UML_Dependency.png",
"data" : [
{
"name":"Afhankelijkheid",
"type":"Afhankelijkheid"
}
]
}
,
"187650" : {
"id":187650,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187660" : {
"id":187660,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187653" : {
"id":187653,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187655" : {
"id":187655,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187664" : {
"id":187664,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187620" : {
"id":187620,
"typeIconPath":"data/icons/UML/UML_ElementImport.png",
"data" : [
{
"name":"Element import",
"type":"Element import"
}
]
}
,
"187674" : {
"id":187674,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"iStandaarden is een set van informatiestandaarden die gebruikt wordt om informatie uit te wisselen over de  uitvoering van de wetten Wlz, Wvggz, Wmo en Jeugdwet. Deze wetten op het gebied van zorg en ondersteuning kennen  elk een eigen informatiestandaard; iWlz, iWvggz, iWmo en iJw. Daarnaast is iPgb ontwikkeld, hiermee kan informatie  worden uitgewisseld over clienten met een pgb binnen alle drie deze wetten. De berichtenstandaarden iWlz, iPgb,  iWvggz, iWmo en iJw gebruiken waar mogelijk dezelfde elementen en systematiek.  Het Informatiemodel iWvggz definieert de standaard voro de Wvggz in kaart. Hier worden processen, regels en berichtspecificaties in onderlinge samenhang getoond. Meer informatie over de achtergrond en het beheer van  iStandaarden in het algemeen vindt u op www.istandaarden.nl en in het boekje \"Wat u moet weten  over iStandaarden\" (zie Tools aan de rechterzijde van deze pagina).",
"type":"Tekenvorm"
}
]
}
,
"187668" : {
"id":187668,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187672" : {
"id":187672,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Over iStandaarden",
"type":"Tekenvorm"
}
]
}
,
"187677" : {
"id":187677,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187682" : {
"id":187682,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187685" : {
"id":187685,
"typeIconPath":"data/icons/ArchiMate/ViewHyperlink.png",
"data" : [
{
"name":"Hyperlink",
"type":"Hyperlink"
}
]
}
,
"187679" : {
"id":187679,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Informatiemodel iWvggz",
"type":"Tekenvorm"
}
]
}
,
"187678" : {
"id":187678,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
,
"187683" : {
"id":187683,
"typeIconPath":"data/icons/ArchiMate/ViewGraphic.png",
"data" : [
{
"name":"Tekenvorm",
"type":"Tekenvorm"
}
]
}
};
