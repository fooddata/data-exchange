var viewData = {"id":178292,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178292" : {
"id":178292,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces over voorbereiding ZM beslissen",
"type":"Collaboration",
"categories":[{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"Artikel 5:3 Wet verplichte geestelijke gezondheidszorg","location":"https://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=5&paragraaf=1&artikel=5:3&z=2020-01-01&g=2020-01-01"}},{"type":"link","value":{"title":"artikel 5:16, eerste lid, van de Wet verplichte geestelijke gezondheidszorg","location":"http://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=5&paragraaf=5&artikel=5:16&lid=1"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185089" : 182079
,
"185115" : 185116
,
"185118" : 185119
,
"185061" : 185062
,
"185054" : 185055
,
"185083" : 185084
,
"185057" : 185058
,
"185073" : 185074
,
"185064" : 185065
,
"185070" : 185071
,
"185047" : 185048
,
"185076" : 185077
,
"185090" : 185091
,
"185050" : 185051
,
"185067" : 185068
,
"185096" : 185097
,
"185121" : 185122
,
"185130" : 185131
,
"185111" : 185112
,
"185124" : 185125
,
"185101" : 185102
,
"185127" : 185128
,
"185086" : 182081
,
"185088" : 182080
,
"185082" : 181500
,
"185095" : 181502
,
"185093" : 181528
,
"185060" : 181522
,
"185081" : 181510
,
"185053" : 181506
,
"185079" : 181520
,
"185080" : 181535
,
"185087" : 181508
,
"185107" : 181504
,
"185100" : 181498
,
"185105" : 181516
,
"185099" : 181524
,
"185094" : 181530
,
"185114" : 181532
,
"185109" : 181526
,
"185104" : 181514
,
"185108" : 181512
,
"185106" : 181518
,
"185046" : 182082
,
"189340" : 189340
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
