var viewData = {"id":27860,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27860" : {
"id":27860,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_RolProfessional",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182762" : 107739
,
"182748" : 182749
,
"182750" : 182751
,
"182752" : 182753
,
"182754" : 182755
,
"182746" : 182747
,
"182756" : 182757
,
"182763" : 182764
,
"182765" : 182766
,
"182769" : 182770
,
"182771" : 182772
,
"182773" : 182774
,
"182775" : 182776
,
"182781" : 182782
,
"182777" : 182778
,
"182785" : 182786
,
"182783" : 182784
,
"182779" : 182780
,
"182758" : 182759
,
"182761" : 103321
,
"182760" : 178595
,
"182767" : 182768
,
"189916" : 189916
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
