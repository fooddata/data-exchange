var viewData = {"id":142468,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"142468" : {
"id":142468,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Processen - oud",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"184333":142312,"179216":142626,"184334":142083,"184335":142629,"184336":142312,"184337":142468};
var objectReferences = {
"184333" : 142312
,
"179216" : 142626
,
"189949" : 189949
,
"189948" : 189948
,
"189953" : 189953
,
"189952" : 189952
,
"189960" : 189960
,
"184334" : 142083
,
"184335" : 142629
,
"189962" : 189962
,
"184336" : 142312
,
"184337" : 142468
,
"189964" : 189964
,
"189945" : 189945
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
