var viewData = {"id":103280,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"103280" : {
"id":103280,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_RelatieVolgorde",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"179967" : 179968
,
"179969" : 179970
,
"179971" : 103080
,
"190515" : 190515
};
var viewpointsData = 
[
{"id":"viewpoint189139","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
,{"id":"viewpoint189133","name":"Datatype details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint189139": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint189133": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint189139.labels[0] = "Labelview";
vp_legends.viewpoint189139.content[0] = new Array();
vp_legends.viewpoint189139.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
vp_legends.viewpoint189133.labels[0] = "Labelview";
vp_legends.viewpoint189133.content[0] = new Array();
vp_legends.viewpoint189133.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
