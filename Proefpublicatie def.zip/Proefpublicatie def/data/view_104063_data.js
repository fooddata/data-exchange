var viewData = {"id":104063,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"104063" : {
"id":104063,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_ZorgkantoorCode",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182835" : 182836
,
"182811" : 182812
,
"182819" : 182820
,
"182821" : 182822
,
"182837" : 182838
,
"182839" : 182840
,
"182823" : 182824
,
"182815" : 182816
,
"182817" : 182818
,
"182825" : 182826
,
"182827" : 182828
,
"182829" : 182830
,
"182831" : 182832
,
"182833" : 182834
,
"182809" : 182810
,
"182871" : 182872
,
"182878" : 182879
,
"182865" : 182866
,
"182841" : 182842
,
"182851" : 182852
,
"182876" : 182877
,
"182873" : 182874
,
"182867" : 182868
,
"182863" : 182864
,
"182847" : 182848
,
"182869" : 182870
,
"182845" : 182846
,
"182859" : 182860
,
"182853" : 182854
,
"182843" : 182844
,
"182849" : 182850
,
"182861" : 182862
,
"182855" : 182856
,
"182857" : 182858
,
"182813" : 182814
,
"182875" : 178595
,
"182880" : 103368
};
var viewpointsData = 
[
{"id":"viewpoint189139","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
,{"id":"viewpoint189133","name":"Datatype details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint189139": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint189133": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint189139.labels[0] = "Labelview";
vp_legends.viewpoint189139.content[0] = new Array();
vp_legends.viewpoint189139.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
vp_legends.viewpoint189133.labels[0] = "Labelview";
vp_legends.viewpoint189133.content[0] = new Array();
vp_legends.viewpoint189133.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
