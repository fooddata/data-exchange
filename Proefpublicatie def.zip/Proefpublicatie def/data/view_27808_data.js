var viewData = {"id":27808,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27808" : {
"id":27808,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_Eenheid",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184917" : 107944
,
"184915" : 184916
,
"184921" : 184922
,
"184928" : 184929
,
"184918" : 184919
,
"184926" : 184927
,
"184920" : 178595
,
"184923" : 103188
,
"184924" : 184925
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
