var viewData = {"id":104039,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"104039" : {
"id":104039,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"Retourbericht Template",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184717" : 183392
,
"184718" : 183332
,
"184719" : 183322
,
"184715" : 183347
,
"184721" : 178613
,
"184720" : 183490
,
"184716" : 183483
,
"184724" : 183487
,
"184722" : 183489
,
"184723" : 183488
,
"184725" : 183492
,
"190452" : 190452
,
"190451" : 190451
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
