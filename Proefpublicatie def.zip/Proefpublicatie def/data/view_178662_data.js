var viewData = {"id":178662,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178662" : {
"id":178662,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"iWvGGZ-rollen",
"type":"Resources",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"180876" : 180877
,
"180880" : 180881
,
"180878" : 180879
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
