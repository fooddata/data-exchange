var viewData = {"id":178386,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178386" : {
"id":178386,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces gegevens geleverde verplichte zorg aanleveren",
"type":"Collaboration",
"categories":[{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"iWvggz juli 2020 - Notitie gegevensverstrekking artikel 8.24","location":"https://istandaarden.nl/ibieb/iwvggz-juli-2020-notitie-gegevensverstrekking-artikel-824"}},{"type":"link","value":{"title":"NGGZ - Informatieboekje - Registratie van vormen van toegepaste verplichte zorg","location":"https://www.denederlandseggz-wvggz.nl/app/download/7051894418/Informatieboekje.pdf?t=1599042338"}},{"type":"link","value":{"title":"Regeling verplichte geestelijke gezondheidszorg","location":"https://wetten.overheid.nl/jci1.3:c:BWBR0042740&z=2020-01-01&g=2020-01-01"}},{"type":"link","value":{"title":"Artikel 8:24 Wet verplichte geestelijke gezondheidszorg","location":"https://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=8&paragraaf=6&artikel=8:24&z=2020-01-01&g=2020-01-01"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185506" : 185488
,
"185496" : 185490
,
"185492" : 185487
,
"185497" : 184707
,
"185495" : 184705
,
"185504" : 179860
,
"185499" : 179865
,
"185500" : 179861
,
"185493" : 179862
,
"185502" : 179863
,
"185503" : 179859
,
"185501" : 179864
,
"185507" : 185486
,
"185508" : 185457
,
"185498" : 185459
,
"185514" : 185481
,
"185510" : 185469
,
"185513" : 185465
,
"185516" : 185455
,
"185518" : 185467
,
"185517" : 185471
,
"185511" : 185473
,
"185494" : 185475
,
"185505" : 185477
,
"185515" : 185463
,
"185512" : 185483
,
"185519" : 185479
,
"185509" : 185461
,
"189455" : 189455
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
