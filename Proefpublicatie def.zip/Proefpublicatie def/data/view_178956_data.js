var viewData = {"id":178956,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178956" : {
"id":178956,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"OM",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183760" : 183759
,
"183763" : 183762
,
"183718" : 182796
,
"183781" : 182797
,
"183777" : 182791
,
"183765" : 182793
,
"183773" : 182800
,
"183771" : 180598
,
"183775" : 182795
,
"183728" : 182799
,
"183767" : 180591
,
"183757" : 182792
,
"183779" : 182801
,
"183783" : 182798
,
"183769" : 182794
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
