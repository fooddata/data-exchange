var viewData = {"id":178916,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178916" : {
"id":178916,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces indiening VCM mededelen",
"type":"Collaboration",
"categories":[{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"artikel 7:7, eerste lid, van de Wet verplichte geestelijke gezondheidszorg","location":"http://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=7&paragraaf=5&artikel=7:7&lid=1"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185143" : 182071
,
"185144" : 185145
,
"185140" : 185141
,
"185148" : 185149
,
"185133" : 185134
,
"185151" : 185152
,
"185137" : 185138
,
"185154" : 185155
,
"185157" : 185158
,
"185160" : 185161
,
"185163" : 185164
,
"185170" : 185171
,
"185166" : 185167
,
"185173" : 185174
,
"185179" : 185180
,
"185176" : 185177
,
"185194" : 182073
,
"185187" : 182072
,
"185188" : 184060
,
"185189" : 184062
,
"185147" : 184078
,
"185136" : 184066
,
"185190" : 184080
,
"185169" : 184064
,
"185193" : 184074
,
"185191" : 184070
,
"185182" : 184068
,
"185186" : 184072
,
"185192" : 184076
,
"185185" : 182074
,
"189429" : 189429
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
