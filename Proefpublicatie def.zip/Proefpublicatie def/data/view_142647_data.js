var viewData = {"id":142647,"isExpandedObject":false};
var objectRelations = {
"142647" : [{"via": "geassocieerd met","to": ["142312"]}]
};
var objectData = {
"142647" : {
"id":142647,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Casuistiek",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142312" : {
"id":142312,
"typeIconPath":"data/icons/ArchiMate/AllExtendedView.png",
"data" : [
{
"lang":"nl",
"name":"iWvggz",
"type":"Totaalview uitgebreid",
"categories":[]
}
]
}
};
var viewReferences = {"182680":142626,"182679":142312,"182681":142629,"182683":142083,"182682":142647,"182685":141950,"182684":142312};
var objectReferences = {
"182680" : 142626
,
"182679" : 142312
,
"189983" : 189983
,
"189986" : 189986
,
"189990" : 189990
,
"189980" : 189980
,
"182681" : 142629
,
"182683" : 142083
,
"182682" : 142647
,
"182685" : 141950
,
"189988" : 189988
,
"182684" : 142312
,
"189994" : 189994
,
"189998" : 189998
,
"189995" : 189995
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
