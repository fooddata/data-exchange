var viewData = {"id":26889,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"26889" : {
"id":26889,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_Identificatie",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185232" : 185233
,
"185231" : 103728
,
"185230" : 178595
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
