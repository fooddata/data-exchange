var viewData = {"id":178970,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178970" : {
"id":178970,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"181886" : 181303
,
"181867" : 181295
,
"181884" : 181285
,
"181891" : 181300
,
"181873" : 181290
,
"181881" : 181296
,
"181872" : 181282
,
"181876" : 181294
,
"181883" : 181293
,
"181871" : 181297
,
"181877" : 181281
,
"181875" : 181286
,
"181890" : 181302
,
"181869" : 181299
,
"181878" : 181289
,
"181885" : 181304
,
"181887" : 181288
,
"181888" : 181291
,
"181889" : 181298
,
"181874" : 181301
,
"181880" : 181287
,
"181879" : 181305
,
"181868" : 181284
,
"181882" : 181292
,
"181870" : 181283
,
"189492" : 189492
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
