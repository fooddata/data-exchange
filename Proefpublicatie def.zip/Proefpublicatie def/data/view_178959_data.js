var viewData = {"id":178959,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178959" : {
"id":178959,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Zorgaanbieder",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"181314" : 181315
,
"181318" : 181319
,
"181324" : 181325
,
"181326" : 181327
,
"181320" : 181321
,
"181310" : 181311
,
"181306" : 181307
,
"181312" : 181313
,
"181316" : 181317
,
"181308" : 181309
,
"181322" : 181323
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
