var viewData = {"id":27706,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27706" : {
"id":27706,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_RelatieOmgeving",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182883" : 107861
,
"182884" : 182885
,
"182891" : 182892
,
"182897" : 182898
,
"182901" : 182902
,
"182903" : 182904
,
"182893" : 182894
,
"182887" : 182888
,
"182899" : 182900
,
"182895" : 182896
,
"182905" : 182906
,
"182908" : 182909
,
"182910" : 182911
,
"182912" : 182913
,
"182881" : 182882
,
"182886" : 103499
,
"182889" : 182890
,
"182907" : 178595
,
"189914" : 189914
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
