var viewData = {"id":66118,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"66118" : {
"id":66118,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG111",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"186102" : 178354
,
"186104" : 186242
,
"186108" : 186240
,
"186106" : 186239
,
"186110" : 186241
,
"186112" : 186236
,
"186114" : 186229
,
"186120" : 186232
,
"186118" : 186230
,
"186116" : 186231
,
"186124" : 186233
,
"186126" : 186234
,
"186128" : 186235
,
"186122" : 186238
,
"186130" : 186237
,
"186212" : 186244
,
"186214" : 178677
,
"186226" : 186246
,
"186218" : 186247
,
"186224" : 186249
,
"186216" : 178463
,
"186220" : 186245
,
"186222" : 186248
,
"186210" : 186243
,
"186228" : 186250
,
"186202" : 178553
,
"186204" : 185764
,
"186206" : 185762
,
"186208" : 185766
,
"179626" : 178295
,
"186091" : 186091
,
"186093" : 186093
,
"186095" : 186095
,
"186097" : 186097
,
"186099" : 186099
,
"186089" : 186089
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
