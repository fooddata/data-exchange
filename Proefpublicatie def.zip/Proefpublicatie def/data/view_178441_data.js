var viewData = {"id":178441,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178441" : {
"id":178441,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Zorgaanbieder",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182656" : 182657
,
"182654" : 182655
,
"182658" : 182659
,
"182668" : 182669
,
"182662" : 182663
,
"182664" : 182665
,
"182666" : 182667
,
"182670" : 182671
,
"182660" : 182661
,
"182650" : 182651
,
"182652" : 182653
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
