var viewData = {"id":178930,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178930" : {
"id":178930,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces persoonsgegevens betrokkene verstrekken",
"type":"Collaboration",
"categories":[{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"artikel 5:4, tweede lid, van de Wet verplichte geestelijke gezondheidszorg","location":"http://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=5&paragraaf=2&artikel=5:4&lid=2"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184365" : 184366
,
"184369" : 184370
,
"184381" : 184382
,
"184340" : 184341
,
"184343" : 184344
,
"184372" : 184373
,
"184390" : 184391
,
"184387" : 184388
,
"184393" : 184394
,
"184396" : 184397
,
"184399" : 184400
,
"184378" : 184379
,
"184357" : 184358
,
"184375" : 184376
,
"184384" : 184385
,
"184353" : 184354
,
"184347" : 184348
,
"184346" : 181315
,
"184339" : 181319
,
"184338" : 181317
,
"184351" : 181309
,
"184361" : 181307
,
"184360" : 181325
,
"184352" : 181313
,
"184350" : 181323
,
"184356" : 181321
,
"184362" : 181327
,
"184349" : 181311
,
"184367" : 184368
,
"184363" : 184364
,
"189290" : 189290
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
