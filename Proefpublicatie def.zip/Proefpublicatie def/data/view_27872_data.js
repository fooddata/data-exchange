var viewData = {"id":27872,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27872" : {
"id":27872,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_NadeelSoort",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183067" : 178595
,
"183068" : 183069
,
"183065" : 183066
,
"183064" : 103144
,
"183045" : 107949
,
"183070" : 183071
,
"183058" : 183059
,
"183056" : 183057
,
"183062" : 183063
,
"183060" : 183061
,
"183043" : 183044
,
"183041" : 183042
,
"183054" : 183055
,
"183046" : 183047
,
"183050" : 183051
,
"183052" : 183053
,
"183048" : 183049
,
"186539" : 186539
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
