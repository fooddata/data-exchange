var viewData = {"id":178992,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178992" : {
"id":178992,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Waardeketen iWvggz",
"type":"Choreography",
"categories":[]
}
]
}
};
var viewReferences = {"185521":178927,"185522":178906,"185520":178454};
var objectReferences = {
"189470" : 189470
,
"185521" : 178927
,
"189481" : 189481
,
"189471" : 189471
,
"189486" : 189486
,
"189485" : 189485
,
"185522" : 178906
,
"189480" : 189480
,
"189490" : 189490
,
"189476" : 189476
,
"185520" : 178454
,
"189474" : 189474
,
"189491" : 189491
,
"189483" : 189483
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
