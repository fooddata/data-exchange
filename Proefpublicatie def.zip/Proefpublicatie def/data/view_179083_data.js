var viewData = {"id":179083,"isExpandedObject":false};
var objectRelations = {
"179083" : [{"via": "geassocieerd met","to": ["142626"]}]
};
var objectData = {
"179083" : {
"id":179083,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Bedrijfsregels",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142626" : {
"id":142626,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Regels",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"183679":142626,"183699":142468,"183697":142629,"183691":142083,"183696":142312};
var objectReferences = {
"183679" : 142626
,
"183699" : 142468
,
"183697" : 142629
,
"183691" : 142083
,
"183696" : 142312
,
"189973" : 189973
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
