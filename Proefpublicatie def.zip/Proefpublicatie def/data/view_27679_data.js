var viewData = {"id":27679,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27679" : {
"id":27679,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG113",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"28567" : 178468
,
"186288" : 186397
,
"186290" : 178405
,
"186292" : 186395
,
"186294" : 186396
,
"186274" : 178272
,
"186276" : 186400
,
"186282" : 186403
,
"186286" : 186402
,
"186284" : 178603
,
"186278" : 186404
,
"186280" : 186401
,
"186266" : 178560
,
"186272" : 186399
,
"186268" : 186398
,
"186270" : 178361
,
"186296" : 186394
,
"186298" : 186393
,
"186370" : 186387
,
"186374" : 178262
,
"186384" : 186392
,
"186380" : 186389
,
"186376" : 186390
,
"186382" : 186391
,
"186372" : 178630
,
"186378" : 186388
,
"186386" : 186405
,
"186256" : 186256
,
"186258" : 186258
,
"186260" : 186260
,
"186262" : 186262
,
"186264" : 186264
,
"186253" : 186253
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
