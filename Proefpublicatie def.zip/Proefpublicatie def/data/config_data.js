var availableLanguages = 
[
{"id":"nl","isDefault":true}
];
