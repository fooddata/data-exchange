var viewData = {"id":178981,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178981" : {
"id":178981,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"IGJ",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185456" : 185457
,
"185458" : 185459
,
"185454" : 185455
,
"185470" : 185471
,
"185472" : 185473
,
"185474" : 185475
,
"185476" : 185477
,
"185462" : 185463
,
"185460" : 185461
,
"185466" : 185467
,
"185464" : 185465
,
"185468" : 185469
,
"185478" : 185479
,
"185482" : 185483
,
"185480" : 185481
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
