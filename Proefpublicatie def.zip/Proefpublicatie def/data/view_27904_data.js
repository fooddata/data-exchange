var viewData = {"id":27904,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27904" : {
"id":27904,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"CDT_AdresWvggz",
"type":"Klassendiagram",
"categories":[{"type":"documentation","title":"documentatie","content":{"type":"rtf","value":"<span style=\" font-size: 10pt;\">Adresgegevens van een &nbsp;persoon of organisatie(locatie)&nbsp;<p style=\"margin-top: 3pt;\"></span>"}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"186828" : 112491
,
"186833" : 178415
,
"186837" : 178383
,
"186829" : 186830
,
"186831" : 178357
,
"186824" : 186825
,
"186832" : 178574
,
"186835" : 186836
,
"186826" : 186827
,
"186834" : 178298
,
"189936" : 189936
,
"189937" : 189937
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
