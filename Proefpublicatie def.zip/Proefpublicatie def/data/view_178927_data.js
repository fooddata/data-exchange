var viewData = {"id":178927,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178927" : {
"id":178927,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Persoonsgegevens betrokkene  verstrekken",
"type":"Choreography",
"categories":[{"type":"documentation","title":"documentatie","content":{"type":"rtf","value":""}},{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"179876" : 179877
,
"179870" : 179871
,
"179878" : 179879
,
"179872" : 179873
,
"179874" : 179875
,
"189296" : 189296
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
