var viewData = {"id":27916,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27916" : {
"id":27916,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG105",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"179475" : 178334
,
"186624" : 186625
,
"179469" : 178314
,
"179470" : 178505
,
"186646" : 178450
,
"186647" : 186648
,
"179472" : 186627
,
"179473" : 186629
,
"179476" : 186628
,
"179468" : 178307
,
"179477" : 186633
,
"179488" : 186632
,
"179489" : 178458
,
"28294" : 178582
,
"179496" : 185752
,
"179490" : 185750
,
"179492" : 185749
,
"179491" : 178514
,
"179495" : 185751
,
"186643" : 185754
,
"179497" : 186644
,
"186639" : 186640
,
"186663" : 178553
,
"186645" : 185764
,
"186664" : 185766
,
"186653" : 185762
,
"186654" : 186655
,
"112177" : 178769
,
"186637" : 186638
,
"186661" : 186662
,
"186649" : 186650
,
"186659" : 186660
,
"186656" : 178684
,
"186630" : 186631
,
"186651" : 186652
,
"186669" : 186670
,
"186626" : 185768
,
"186680" : 186681
,
"186641" : 186642
,
"186699" : 178320
,
"186705" : 186603
,
"186703" : 178744
,
"186702" : 178259
,
"186701" : 178589
,
"186700" : 186598
,
"186704" : 178749
,
"179448" : 179448
,
"179449" : 179449
,
"179450" : 179450
,
"179451" : 179451
,
"179452" : 179452
,
"179453" : 179453
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
