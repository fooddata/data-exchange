var viewData = {"id":26973,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"26973" : {
"id":26973,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG103",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185730" : 185768
,
"185732" : 186604
,
"185744" : 186611
,
"185746" : 186614
,
"185740" : 186607
,
"185738" : 186612
,
"185734" : 178267
,
"185736" : 178718
,
"185742" : 186605
,
"185722" : 178553
,
"185726" : 185762
,
"185724" : 185764
,
"185728" : 185766
,
"185748" : 186615
,
"179409" : 186606
,
"179406" : 178548
,
"185627" : 186609
,
"28209" : 178429
,
"179408" : 178697
,
"179407" : 186608
,
"179416" : 178458
,
"185639" : 185754
,
"179417" : 185750
,
"179418" : 178514
,
"179420" : 178582
,
"179419" : 185749
,
"179423" : 185751
,
"179424" : 185752
,
"179404" : 178253
,
"179410" : 186579
,
"179411" : 186580
,
"179425" : 186577
,
"179426" : 186610
,
"186622" : 186623
,
"186616" : 178320
,
"186613" : 178589
,
"186619" : 178744
,
"186620" : 178749
,
"186617" : 186598
,
"186618" : 178259
,
"186621" : 186603
,
"179376" : 179376
,
"179377" : 179377
,
"179378" : 179378
,
"179379" : 179379
,
"179380" : 179380
,
"179381" : 179381
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
