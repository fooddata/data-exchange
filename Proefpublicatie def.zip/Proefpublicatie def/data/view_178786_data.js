var viewData = {"id":178786,"isExpandedObject":false};
var objectRelations = {
"178786" : [{"via": "geassocieerd met","to": ["142626"]}]
};
var objectData = {
"178786" : {
"id":178786,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Technische regels",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142626" : {
"id":142626,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Regels",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"182695":142312,"182696":142629,"182698":142468,"182700":142626,"182691":142083};
var objectReferences = {
"182695" : 142312
,
"182696" : 142629
,
"182698" : 142468
,
"182700" : 142626
,
"182691" : 142083
,
"189970" : 189970
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
