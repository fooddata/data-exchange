var viewData = {"id":178861,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178861" : {
"id":178861,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"iWvGGZ-rollen",
"type":"Resources",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"180890" : 180891
,
"180888" : 180889
,
"180886" : 180887
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
