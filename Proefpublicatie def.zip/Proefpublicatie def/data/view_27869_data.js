var viewData = {"id":27869,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27869" : {
"id":27869,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG Retour",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185417" : 178498
,
"185437" : 185438
,
"185403" : 185404
,
"185440" : 185441
,
"185420" : 185421
,
"185418" : 185419
,
"28568" : 185439
,
"185435" : 185436
,
"185433" : 185434
,
"185396" : 185397
,
"185442" : 185443
,
"185444" : 185445
,
"185446" : 185447
,
"185448" : 185449
,
"190115" : 190115
,
"190117" : 190117
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
