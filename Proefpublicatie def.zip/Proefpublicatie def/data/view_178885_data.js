var viewData = {"id":178885,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178885" : {
"id":178885,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"OM",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184059" : 184060
,
"184061" : 184062
,
"184067" : 184068
,
"184063" : 184064
,
"184069" : 184070
,
"184077" : 184078
,
"184065" : 184066
,
"184071" : 184072
,
"184073" : 184074
,
"184079" : 184080
,
"184075" : 184076
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
