var viewData = {"id":179010,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179010" : {
"id":179010,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"OM",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185026" : 185025
,
"185029" : 185028
,
"184983" : 183534
,
"185020" : 183535
,
"184988" : 183533
,
"185004" : 183532
,
"184976" : 183527
,
"185014" : 183528
,
"185045" : 183529
,
"185033" : 183526
,
"185035" : 183536
,
"185041" : 183525
,
"185031" : 183530
,
"185037" : 183531
,
"185043" : 183537
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
