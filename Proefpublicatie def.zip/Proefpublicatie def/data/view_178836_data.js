var viewData = {"id":178836,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178836" : {
"id":178836,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"iWvGGZ-rollen",
"type":"Resources",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185226" : 185227
,
"185228" : 185229
,
"185224" : 185225
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
