var viewData = {"id":178921,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178921" : {
"id":178921,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"OM",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"180955" : 180954
,
"180931" : 180930
,
"180928" : 180927
,
"180958" : 180957
,
"180961" : 180960
,
"180964" : 180963
,
"180970" : 180969
,
"180973" : 180972
,
"180976" : 180975
,
"180979" : 180978
,
"180967" : 180966
,
"180982" : 180981
,
"180985" : 180984
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
