var viewData = {"id":66939,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"66939" : {
"id":66939,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG109",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185760" : 178553
,
"185765" : 185766
,
"185761" : 185762
,
"185763" : 185764
,
"185767" : 185768
,
"185769" : 185770
,
"185771" : 185772
,
"185774" : 178747
,
"185775" : 185776
,
"185781" : 185782
,
"185773" : 178761
,
"185783" : 185784
,
"185777" : 185778
,
"185779" : 185780
,
"179624" : 185758
,
"179615" : 178458
,
"185753" : 185754
,
"179617" : 178514
,
"179619" : 178582
,
"179618" : 185749
,
"179622" : 185751
,
"179623" : 185752
,
"179616" : 185750
,
"179609" : 185755
,
"179610" : 178516
,
"179613" : 178532
,
"179614" : 185756
,
"179611" : 185757
,
"179612" : 178490
,
"179607" : 178301
,
"179625" : 185759
,
"179579" : 179579
,
"179580" : 179580
,
"179583" : 179583
,
"179584" : 179584
,
"179581" : 179581
,
"179582" : 179582
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
