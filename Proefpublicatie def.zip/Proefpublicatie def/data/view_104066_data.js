var viewData = {"id":104066,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"104066" : {
"id":104066,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_SoortRelatie",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184000" : 184001
,
"184032" : 184033
,
"184034" : 184035
,
"184036" : 184037
,
"184004" : 184005
,
"184038" : 184039
,
"183996" : 183997
,
"183994" : 183995
,
"184030" : 184031
,
"183998" : 183999
,
"184040" : 184041
,
"184024" : 184025
,
"184002" : 184003
,
"184012" : 184013
,
"184008" : 184009
,
"184022" : 184023
,
"184006" : 184007
,
"184010" : 184011
,
"184028" : 184029
,
"184014" : 184015
,
"184016" : 184017
,
"184018" : 184019
,
"184026" : 184027
,
"184044" : 184045
,
"183993" : 103454
,
"184020" : 184021
,
"184046" : 178595
,
"184042" : 184043
,
"190597" : 190597
};
var viewpointsData = 
[
{"id":"viewpoint189139","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
,{"id":"viewpoint189133","name":"Datatype details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint189139": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint189133": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint189139.labels[0] = "Labelview";
vp_legends.viewpoint189139.content[0] = new Array();
vp_legends.viewpoint189139.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
vp_legends.viewpoint189133.labels[0] = "Labelview";
vp_legends.viewpoint189133.content[0] = new Array();
vp_legends.viewpoint189133.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
