var viewData = {"id":27901,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27901" : {
"id":27901,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_Beslissing",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183028" : 107941
,
"183029" : 183030
,
"183032" : 183033
,
"183036" : 183037
,
"183031" : 178595
,
"183034" : 183035
,
"183038" : 183039
,
"183040" : 103488
,
"189925" : 189925
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
