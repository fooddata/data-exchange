var viewData = {"id":178640,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178640" : {
"id":178640,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Zorgaanbieder",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184706" : 184707
,
"184704" : 184705
,
"184713" : 179863
,
"184708" : 179861
,
"184709" : 179864
,
"184710" : 179860
,
"184712" : 179859
,
"184711" : 179865
,
"184714" : 179862
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
