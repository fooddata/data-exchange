var viewData = {"id":178842,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178842" : {
"id":178842,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Codelijst",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"182965":142312,"182969":142629,"182967":142626,"182973":142468,"182971":142083};
var objectReferences = {
"182965" : 142312
,
"189975" : 189975
,
"182969" : 142629
,
"182967" : 142626
,
"182973" : 142468
,
"182971" : 142083
,
"189976" : 189976
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
