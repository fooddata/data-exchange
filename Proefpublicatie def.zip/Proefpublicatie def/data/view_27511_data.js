var viewData = {"id":27511,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27511" : {
"id":27511,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_Zorgvorm",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"186443" : 186444
,
"186445" : 107950
,
"186462" : 186463
,
"186484" : 186485
,
"186486" : 186487
,
"186446" : 186447
,
"186458" : 186459
,
"186478" : 186479
,
"186448" : 186449
,
"186460" : 186461
,
"186470" : 186471
,
"186468" : 186469
,
"186452" : 186453
,
"186466" : 186467
,
"186454" : 186455
,
"186450" : 186451
,
"186464" : 186465
,
"186474" : 186475
,
"186476" : 186477
,
"186456" : 186457
,
"186472" : 186473
,
"186480" : 186481
,
"186482" : 186483
,
"186490" : 186491
,
"186488" : 186489
,
"186492" : 186493
,
"186494" : 186495
,
"186496" : 186497
,
"186500" : 103540
,
"186501" : 178595
,
"186498" : 186499
,
"186505" : 186505
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
