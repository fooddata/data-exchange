var viewData = {"id":178964,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178964" : {
"id":178964,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Zorgaanbieder",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"179723" : 179724
,
"179727" : 179728
,
"179737" : 179738
,
"179739" : 179740
,
"179733" : 179734
,
"179735" : 179736
,
"179743" : 179744
,
"179745" : 179746
,
"179747" : 179748
,
"179731" : 179732
,
"179741" : 179742
,
"179719" : 179720
,
"179721" : 179722
,
"179729" : 179730
,
"179725" : 179726
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
