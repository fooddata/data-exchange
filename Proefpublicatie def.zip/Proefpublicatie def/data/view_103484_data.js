var viewData = {"id":103484,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"103484" : {
"id":103484,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"CDT_VerkorteNaam",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183802" : 108317
,
"183805" : 183806
,
"183803" : 183804
,
"183807" : 183808
,
"190521" : 190521
,
"190523" : 190523
};
var viewpointsData = 
[
{"id":"viewpoint189139","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
,{"id":"viewpoint189133","name":"Datatype details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint189139": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint189133": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint189139.labels[0] = "Labelview";
vp_legends.viewpoint189139.content[0] = new Array();
vp_legends.viewpoint189139.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
vp_legends.viewpoint189133.labels[0] = "Labelview";
vp_legends.viewpoint189133.content[0] = new Array();
vp_legends.viewpoint189133.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
