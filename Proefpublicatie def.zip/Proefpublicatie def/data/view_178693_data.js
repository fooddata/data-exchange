var viewData = {"id":178693,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178693" : {
"id":178693,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces GD aanwijzen",
"type":"Collaboration",
"categories":[{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"artikel 5:4, eerste lid, van de Wet verplichte geestelijke gezondheidszorg","location":"http://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=5&paragraaf=2&artikel=5:4&lid=1"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"180935" : 180936
,
"180933" : 179724
,
"180932" : 179728
,
"180937" : 179738
,
"180943" : 179732
,
"180944" : 179740
,
"180945" : 179742
,
"180946" : 179736
,
"180941" : 179734
,
"180947" : 179726
,
"180948" : 179720
,
"180938" : 179722
,
"180939" : 179746
,
"180940" : 179744
,
"180934" : 179748
,
"180942" : 179730
,
"180949" : 180950
,
"180951" : 180952
,
"180953" : 180954
,
"180929" : 180930
,
"180926" : 180927
,
"180962" : 180963
,
"180965" : 180966
,
"180959" : 180960
,
"180956" : 180957
,
"180977" : 180978
,
"180980" : 180981
,
"180971" : 180972
,
"180974" : 180975
,
"180968" : 180969
,
"180983" : 180984
,
"180986" : 180987
,
"189407" : 189407
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
