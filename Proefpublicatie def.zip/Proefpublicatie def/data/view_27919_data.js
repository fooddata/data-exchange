var viewData = {"id":27919,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27919" : {
"id":27919,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG107",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"179540" : 178593
,
"28570" : 186714
,
"186721" : 178541
,
"186726" : 186727
,
"186722" : 186723
,
"179563" : 186731
,
"179543" : 186751
,
"179541" : 186730
,
"179534" : 178492
,
"179535" : 178510
,
"179538" : 178740
,
"179539" : 178394
,
"179553" : 186736
,
"179533" : 178252
,
"179542" : 186739
,
"186747" : 186748
,
"186742" : 186743
,
"186744" : 186745
,
"179554" : 178458
,
"179556" : 178514
,
"179562" : 185752
,
"179555" : 185750
,
"179558" : 178582
,
"179561" : 185751
,
"179557" : 185749
,
"186725" : 185754
,
"186737" : 186738
,
"186757" : 186758
,
"186759" : 186760
,
"186763" : 185768
,
"186746" : 178553
,
"186720" : 185762
,
"186713" : 185766
,
"186764" : 185764
,
"186752" : 186753
,
"186761" : 186762
,
"186740" : 186741
,
"186724" : 178688
,
"186728" : 186729
,
"186706" : 186707
,
"186711" : 186712
,
"186754" : 186755
,
"186756" : 178734
,
"186749" : 186750
,
"186785" : 178320
,
"186791" : 178589
,
"186792" : 178259
,
"186789" : 186603
,
"186793" : 178744
,
"186794" : 178749
,
"186790" : 186598
,
"179514" : 179514
,
"179515" : 179515
,
"179516" : 179516
,
"179517" : 179517
,
"179518" : 179518
,
"179513" : 179513
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
