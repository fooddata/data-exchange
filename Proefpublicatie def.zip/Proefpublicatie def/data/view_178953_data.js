var viewData = {"id":178953,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178953" : {
"id":178953,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"OM",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182715" : 182716
,
"182719" : 182720
,
"182723" : 182724
,
"182727" : 182728
,
"182733" : 182734
,
"182721" : 182722
,
"182725" : 182726
,
"182735" : 182736
,
"182717" : 182718
,
"182729" : 182730
,
"182740" : 182741
,
"182731" : 182732
,
"182737" : 182738
,
"182711" : 182712
,
"182713" : 182714
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
