var viewData = {"id":178938,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178938" : {
"id":178938,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"iWvGGZ-rollen",
"type":"Resources",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"181892" : 181893
,
"181894" : 181895
,
"181896" : 181897
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
