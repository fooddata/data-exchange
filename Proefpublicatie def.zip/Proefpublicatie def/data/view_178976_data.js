var viewData = {"id":178976,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178976" : {
"id":178976,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces ZM aanragen",
"type":"Collaboration",
"categories":[{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"Artikel 5:3 Wet verplichte geestelijke gezondheidszorg","location":"https://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=5&paragraaf=1&artikel=5:3&z=2020-01-01&g=2020-01-01"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183723" : 180590
,
"183719" : 180594
,
"183720" : 183721
,
"183724" : 183725
,
"183735" : 180597
,
"183737" : 183738
,
"183740" : 183741
,
"183748" : 183749
,
"183732" : 183733
,
"183743" : 183744
,
"183751" : 183752
,
"183729" : 183730
,
"183746" : 180592
,
"183754" : 180596
,
"183755" : 180588
,
"183758" : 183759
,
"183761" : 183762
,
"183727" : 182799
,
"183717" : 182796
,
"183768" : 182794
,
"183764" : 182793
,
"183776" : 182791
,
"183780" : 182797
,
"183766" : 180591
,
"183772" : 182800
,
"183782" : 182798
,
"183756" : 182792
,
"183774" : 182795
,
"183770" : 180598
,
"183778" : 182801
,
"189385" : 189385
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
