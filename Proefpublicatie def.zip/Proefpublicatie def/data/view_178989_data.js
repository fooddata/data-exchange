var viewData = {"id":178989,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178989" : {
"id":178989,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Datatypen",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"184458":142312,"184465":142083,"184467":142468,"184459":142629,"184461":142626};
var objectReferences = {
"184458" : 142312
,
"189979" : 189979
,
"189977" : 189977
,
"184465" : 142083
,
"184467" : 142468
,
"184459" : 142629
,
"184461" : 142626
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
