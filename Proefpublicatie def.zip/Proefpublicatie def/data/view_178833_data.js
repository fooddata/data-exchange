var viewData = {"id":178833,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178833" : {
"id":178833,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182213" : 181119
,
"182207" : 181127
,
"182209" : 181126
,
"182214" : 181128
,
"182206" : 181120
,
"182216" : 181135
,
"182210" : 181131
,
"182217" : 181124
,
"182220" : 181130
,
"182211" : 181129
,
"182212" : 181134
,
"182208" : 181123
,
"182218" : 181121
,
"182221" : 181133
,
"182222" : 181118
,
"182224" : 181117
,
"182223" : 181132
,
"182219" : 181125
,
"182215" : 181122
,
"189634" : 189634
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
