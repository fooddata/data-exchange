var viewData = {"id":178973,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178973" : {
"id":178973,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces medisch onderzoeken",
"type":"Collaboration",
"categories":[{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"artikel 5:8, eerste lid, van de Wet verplichte geestelijke gezondheidszorg","location":"http://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=5&paragraaf=3&artikel=5:8&lid=1"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"183546" : 182065
,
"183543" : 182716
,
"183551" : 182720
,
"183544" : 182726
,
"183562" : 182718
,
"183545" : 182736
,
"183560" : 182722
,
"183555" : 182732
,
"183558" : 182741
,
"183563" : 182734
,
"183553" : 182728
,
"183561" : 182712
,
"183554" : 182730
,
"183550" : 182714
,
"183564" : 182724
,
"183556" : 182738
,
"183548" : 182067
,
"183559" : 182068
,
"183565" : 182066
,
"183552" : 182657
,
"183567" : 182655
,
"183549" : 182663
,
"183570" : 182653
,
"183572" : 182667
,
"183571" : 182659
,
"183569" : 182651
,
"183566" : 182661
,
"183557" : 182671
,
"183568" : 182665
,
"183542" : 182669
,
"189368" : 189368
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
