var viewData = {"id":27907,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27907" : {
"id":27907,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_AanleidingBevindingen",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182114" : 182115
,
"182112" : 182113
,
"182111" : 107067
,
"182120" : 182121
,
"182116" : 182117
,
"182118" : 103794
,
"182119" : 178595
,
"189928" : 189928
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
