var viewData = {"id":141950,"isExpandedObject":false};
var objectRelations = {
"141950" : [{"via": "geassocieerd met","to": ["142312"]}]
};
var objectData = {
"141950" : {
"id":141950,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Processen",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142312" : {
"id":142312,
"typeIconPath":"data/icons/ArchiMate/AllExtendedView.png",
"data" : [
{
"lang":"nl",
"name":"iWvggz",
"type":"Totaalview uitgebreid",
"categories":[]
}
]
}
};
var viewReferences = {"185534":142626,"185535":142312,"185532":142083,"185527":141950,"185533":142629,"185531":142312};
var objectReferences = {
"185534" : 142626
,
"185535" : 142312
,
"187927" : 187927
,
"185532" : 142083
,
"185527" : 141950
,
"185533" : 142629
,
"187921" : 187921
,
"185531" : 142312
,
"187928" : 187928
,
"187905" : 187905
,
"187906" : 187906
,
"187919" : 187919
,
"187907" : 187907
,
"187913" : 187913
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
