var viewData = {"id":179000,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179000" : {
"id":179000,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"OM",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"181499" : 181500
,
"181501" : 181502
,
"181511" : 181512
,
"181531" : 181532
,
"181521" : 181522
,
"181523" : 181524
,
"181517" : 181518
,
"181529" : 181530
,
"181527" : 181528
,
"181534" : 181535
,
"181507" : 181508
,
"181497" : 181498
,
"181515" : 181516
,
"181519" : 181520
,
"181503" : 181504
,
"181509" : 181510
,
"181513" : 181514
,
"181525" : 181526
,
"181505" : 181506
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
