var viewData = {"id":178913,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178913" : {
"id":178913,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Stichting PVP",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184371" : 184370
,
"184383" : 184382
,
"184342" : 184341
,
"184345" : 184344
,
"184377" : 184376
,
"184401" : 184400
,
"184380" : 184379
,
"184355" : 184354
,
"184359" : 184358
,
"184386" : 184385
,
"184374" : 184373
,
"184395" : 184394
,
"184389" : 184388
,
"184392" : 184391
,
"184398" : 184397
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
