var viewData = {"id":27881,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27881" : {
"id":27881,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_ZorgvormCategorie",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"186843" : 103818
,
"186838" : 186839
,
"186846" : 178595
,
"186840" : 107951
,
"34198" : 112568
,
"34216" : 34217
,
"34229" : 112569
,
"34200" : 112570
,
"34220" : 112571
,
"34204" : 112572
,
"34222" : 112573
,
"34196" : 112574
,
"34210" : 112575
,
"34202" : 112576
,
"186841" : 112578
,
"186842" : 112580
,
"186844" : 186845
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
