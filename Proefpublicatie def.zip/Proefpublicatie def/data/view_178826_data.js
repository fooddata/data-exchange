var viewData = {"id":178826,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178826" : {
"id":178826,
"typeIconPath":"data/icons/BPMN/BPMN_ResourceSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"iWvGGZ-rollen",
"type":"Resources",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184453" : 184454
,
"184455" : 184456
,
"184451" : 184452
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
