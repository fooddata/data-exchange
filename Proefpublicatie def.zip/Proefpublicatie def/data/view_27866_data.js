var viewData = {"id":27866,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27866" : {
"id":27866,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"LDT_RetourCode",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"186408" : 112310
,
"186416" : 178467
,
"186418" : 178508
,
"186420" : 178893
,
"186410" : 178329
,
"186412" : 186562
,
"186414" : 186563
,
"186424" : 178701
,
"186426" : 178305
,
"186422" : 178695
,
"186565" : 186566
,
"186564" : 178918
,
"186434" : 186560
,
"186430" : 186561
,
"186428" : 103349
,
"186432" : 178595
};
var viewpointsData = 
[
{"id":"viewpoint188686","name":"Datatype details view","presentationType":"FmtLabelView"}
,{"id":"viewpoint188683","name":"Retourcode is gekoppeld aan regel","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188686": {
    "labels" : new Array(),
    "content" : new Array()
  }
,
  "viewpoint188683": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188686.labels[0] = "Labelview";
vp_legends.viewpoint188686.content[0] = new Array();
vp_legends.viewpoint188686.content[0][0] = {value1: "1) ", value2: "Datatype details view"};
vp_legends.viewpoint188683.labels[0] = "Labelview";
vp_legends.viewpoint188683.content[0] = new Array();
vp_legends.viewpoint188683.content[0][0] = {value1: "1) ", value2: "Retourcode is gekoppeld aan regel"};
