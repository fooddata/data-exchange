var viewData = {"id":179075,"isExpandedObject":false};
var objectRelations = {
"179075" : [{"via": "geassocieerd met","to": ["142626"]}]
};
var objectData = {
"179075" : {
"id":179075,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Condities",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142626" : {
"id":142626,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Regels",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"185199":142626,"185215":142468,"185210":142312,"185211":142629,"185207":142083};
var objectReferences = {
"185199" : 142626
,
"185215" : 142468
,
"185210" : 142312
,
"185211" : 142629
,
"185207" : 142083
,
"189972" : 189972
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
