var viewData = {"id":178607,"isExpandedObject":false};
var objectRelations = {
"178607" : [{"via": "geassocieerd met","to": ["142626"]}]
};
var objectData = {
"178607" : {
"id":178607,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Constraints",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142626" : {
"id":142626,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Regels",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"181458":142083,"181450":142629,"181449":142312,"181454":142626,"181456":142468};
var objectReferences = {
"181458" : 142083
,
"181450" : 142629
,
"181449" : 142312
,
"181454" : 142626
,
"181456" : 142468
,
"189969" : 189969
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
