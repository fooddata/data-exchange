var viewData = {"id":142083,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"142083" : {
"id":142083,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Berichten",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"184402":142312,"184405":142626,"184404":142083,"184409":141950,"184407":142629,"184403":142312};
var objectReferences = {
"184402" : 142312
,
"184408" : 146321
,
"184405" : 142626
,
"187936" : 187936
,
"187937" : 187937
,
"187933" : 187933
,
"187942" : 187942
,
"187944" : 187944
,
"187947" : 187947
,
"187932" : 187932
,
"187941" : 187941
,
"187954" : 187954
,
"184404" : 142083
,
"184409" : 141950
,
"184407" : 142629
,
"187935" : 187935
,
"184403" : 142312
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
