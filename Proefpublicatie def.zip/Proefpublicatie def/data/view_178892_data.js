var viewData = {"id":178892,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178892" : {
"id":178892,
"typeIconPath":"data/icons/BPMN/BPMN_ProcessSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Aanvrager",
"type":"Process",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185117" : 185116
,
"185120" : 185119
,
"185092" : 185091
,
"185072" : 185071
,
"185056" : 185055
,
"185052" : 185051
,
"185049" : 185048
,
"185075" : 185074
,
"185078" : 185077
,
"185069" : 185068
,
"185059" : 185058
,
"185066" : 185065
,
"185085" : 185084
,
"185063" : 185062
,
"185113" : 185112
,
"185103" : 185102
,
"185126" : 185125
,
"185129" : 185128
,
"185132" : 185131
,
"185098" : 185097
,
"185123" : 185122
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
