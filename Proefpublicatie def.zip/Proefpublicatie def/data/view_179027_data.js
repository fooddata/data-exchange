var viewData = {"id":179027,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179027" : {
"id":179027,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Voorbereiden ZM (choreografie)",
"type":"Choreography",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"182333" : 181470
,
"182337" : 181471
,
"182340" : 181473
,
"182342" : 181494
,
"182343" : 181488
,
"182344" : 181476
,
"182341" : 181483
,
"182336" : 181475
,
"182345" : 181485
,
"182346" : 181474
,
"182348" : 181495
,
"182339" : 181489
,
"182349" : 181477
,
"182350" : 181487
,
"182351" : 181491
,
"182352" : 181479
,
"182353" : 181482
,
"182338" : 181493
,
"182354" : 181480
,
"182355" : 181492
,
"182335" : 181486
,
"182356" : 181469
,
"182357" : 181472
,
"182334" : 181481
,
"182347" : 181490
,
"182359" : 181478
,
"182358" : 181484
,
"189704" : 189704
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
