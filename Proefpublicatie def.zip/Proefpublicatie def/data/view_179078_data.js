var viewData = {"id":179078,"isExpandedObject":false};
var objectRelations = {
"179078" : [{"via": "geassocieerd met","to": ["142626"]}]
};
var objectData = {
"179078" : {
"id":179078,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Uitgangspunten",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142626" : {
"id":142626,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Regels",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"183651":142083,"183638":142626,"183644":142312,"183643":142468,"183645":142629};
var objectReferences = {
"183651" : 142083
,
"183638" : 142626
,
"183644" : 142312
,
"183643" : 142468
,
"183645" : 142629
,
"189971" : 189971
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
