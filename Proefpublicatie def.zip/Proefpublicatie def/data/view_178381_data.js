var viewData = {"id":178381,"isExpandedObject":false};
var objectRelations = {
"178381" : [{"via": "geassocieerd met","to": ["142626"]}]
};
var objectData = {
"178381" : {
"id":178381,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Invulinstructies",
"type":"Totaalview",
"categories":[]
}
]
}
,
"142626" : {
"id":142626,
"typeIconPath":"data/icons/ArchiMate/AllView.png",
"data" : [
{
"lang":"nl",
"name":"Regels",
"type":"Totaalview",
"categories":[]
}
]
}
};
var viewReferences = {"184480":142629,"184476":142312,"184475":142083,"184478":142626,"184469":142468};
var objectReferences = {
"184480" : 142629
,
"184476" : 142312
,
"184475" : 142083
,
"184478" : 142626
,
"184469" : 142468
,
"189968" : 189968
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
