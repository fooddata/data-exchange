var viewData = {"id":27743,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"27743" : {
"id":27743,
"typeIconPath":"data/icons/UML/UML_ClassDiagram.png",
"data" : [
{
"lang":"nl",
"name":"WVG115",
"type":"Klassendiagram",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185835" : 185768
,
"185844" : 185845
,
"185838" : 178265
,
"185839" : 185840
,
"185841" : 178671
,
"185842" : 185843
,
"185846" : 185847
,
"185848" : 185849
,
"185852" : 185853
,
"185855" : 178763
,
"185850" : 185851
,
"185856" : 185857
,
"185858" : 185859
,
"185854" : 178710
,
"185830" : 178686
,
"185820" : 185821
,
"185831" : 178553
,
"185832" : 185764
,
"185834" : 185766
,
"185833" : 185762
,
"185836" : 185837
,
"185822" : 178458
,
"185825" : 185752
,
"185826" : 178582
,
"185828" : 178514
,
"185823" : 185749
,
"185827" : 185750
,
"185829" : 185754
,
"185824" : 185751
,
"187039" : 187039
,
"187042" : 187042
,
"187044" : 187044
,
"187046" : 187046
,
"187048" : 187048
,
"187050" : 187050
};
var viewpointsData = 
[
{"id":"viewpoint188803","name":"Bericht details view","presentationType":"FmtLabelView"}
];
var vp_legends = 
{
  "viewpoint188803": {
    "labels" : new Array(),
    "content" : new Array()
  }
};
vp_legends.viewpoint188803.labels[0] = "Labelview";
vp_legends.viewpoint188803.content[0] = new Array();
vp_legends.viewpoint188803.content[0][0] = {value1: "1) ", value2: "Getoond worden informatie over het bericht en de regels die op dit niveau gekoppeld zijn"};
