var viewData = {"id":178906,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"178906" : {
"id":178906,
"typeIconPath":"data/icons/BPMN/BPMN_ChoreographySchemeView.png",
"data" : [
{
"lang":"nl",
"name":"Toezicht houden",
"type":"Choreography",
"categories":[]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"184726" : 184727
,
"184728" : 184729
,
"184730" : 184731
,
"184733" : 184734
,
"184735" : 184736
,
"189467" : 189467
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
