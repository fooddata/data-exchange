var viewData = {"id":179003,"isExpandedObject":false};
var objectRelations = {
};
var objectData = {
"179003" : {
"id":179003,
"typeIconPath":"data/icons/BPMN/BPMN_CollaborationSchemeView.png",
"data" : [
{
"lang":"nl",
"name":"proces bevindingen beoordelen",
"type":"Collaboration",
"categories":[{"type":"documentation","title":"documentatie","content":{"type":"rtf","value":""}},{"type":"table","title":"__is_translate_properties_title__","content":{"":{"verwijzingen":{"type":"collection","value":[{"type":"link","value":{"title":"Artikel 5:15 Wet verplichte geestelijke gezondheidszorg","location":"https://wetten.overheid.nl/jci1.3:c:BWBR0040635&hoofdstuk=5&paragraaf=4&artikel=5:15&z=2020-01-01&g=2020-01-01"}}]}}}}]
}
]
}
};
var viewReferences = {};
var objectReferences = {
"185023" : 182085
,
"185024" : 185025
,
"185027" : 185028
,
"184975" : 183527
,
"184982" : 183534
,
"185003" : 183532
,
"185013" : 183528
,
"184987" : 183533
,
"185019" : 183535
,
"185042" : 183537
,
"185032" : 183526
,
"185034" : 183536
,
"185030" : 183530
,
"185036" : 183531
,
"185040" : 183525
,
"185044" : 183529
,
"184979" : 182087
,
"184980" : 182088
,
"184981" : 182086
,
"184972" : 184973
,
"184984" : 184985
,
"185009" : 184319
,
"184977" : 184322
,
"185005" : 184318
,
"185017" : 184321
,
"185021" : 184325
,
"184995" : 184315
,
"184991" : 184320
,
"184993" : 184314
,
"184997" : 184324
,
"184999" : 184316
,
"185001" : 184328
,
"185007" : 184317
,
"184989" : 184326
,
"185011" : 184327
,
"185015" : 184323
,
"189319" : 189319
};
var viewpointsData = 
[
];
var vp_legends = 
{
};
